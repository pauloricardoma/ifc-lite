"""Independent inspection/raster of a real downloaded PDF; no simulated document."""
import hashlib
import json
from pathlib import Path
import sys
import pymupdf

source = Path(sys.argv[1])
result = {'reader': 'PyMuPDF', 'readerVersion': pymupdf.VersionBind,
          'path': str(source), 'sha256': hashlib.sha256(source.read_bytes()).hexdigest(), 'pages': []}
with pymupdf.open(source) as document:
    result['pageCount'] = len(document)
    for index, page in enumerate(document):
        spans = [span for block in page.get_text('dict')['blocks']
                 for line in block.get('lines', []) for span in line['spans']]
        record = {'number': index + 1, 'width': page.rect.width, 'height': page.rect.height,
                  'spans': [{key: span[key] for key in ('text', 'font', 'size', 'color', 'origin', 'bbox')}
                            for span in spans]}
        if index in (0, len(document) - 1):
            png = source.with_name(f'{source.stem}-pdf-page-{index + 1}.png')
            page.get_pixmap(matrix=pymupdf.Matrix(1.5, 1.5)).save(png)
            record['png'] = str(png)
        result['pages'].append(record)
target = source.with_name(f'{source.stem}-independent-pdf.json')
target.write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps({'inspection': str(target), 'pageCount': result['pageCount'], 'sha256': result['sha256']}))
