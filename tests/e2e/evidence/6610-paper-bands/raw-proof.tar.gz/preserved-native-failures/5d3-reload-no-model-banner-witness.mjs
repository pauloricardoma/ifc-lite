/** Source-only finite native correctness plan. Launch only after the root grants Chrome lease. */
import assert from 'node:assert/strict';
import { createHash } from 'node:crypto';
import { execFileSync } from 'node:child_process';
import { mkdir, mkdtemp, readFile, writeFile, rm } from 'node:fs/promises';
import { createRequire } from 'node:module';
import { basename, dirname, join, win32 } from 'node:path';
import { pathToFileURL } from 'node:url';

const ROOT = '/home/louistrue/wt/6610-d-native-evidence-session6503';
const OUT = '/tmp/6232-takeover/6610-main002-source-union';
const HEAD = '325593c90bc85af810f7df6b09eef21222ee7fc4';
const RUN = join(OUT, `native-paper-bands-${new Date().toISOString().replace(/[:.]/g, '-')}`);
assert.deepEqual(process.argv.slice(2), ['--root-allocated-native-slot', HEAD]);
const git = (...args) => execFileSync('git', args, { cwd: ROOT, encoding: 'utf8' }).trim();
assert.equal(git('rev-parse', 'HEAD'), HEAD);
assert.equal(git('status', '--porcelain'), '');
const lease = JSON.parse(await readFile(join(OUT, 'D-current-viewer-build-lease.json'), 'utf8'));
assert.equal(lease.head, HEAD); assert.equal(lease.exit, 0);
for (const [file, hash] of Object.entries(lease.distSha256)) {
  assert.equal(createHash('sha256').update(await readFile(join(ROOT, file))).digest('hex'), hash, file);
}
const requireViewer = createRequire(join(ROOT, 'apps/viewer/package.json'));
const { chromium } = requireViewer('playwright-core');
const { expect } = createRequire(join(ROOT, 'package.json'))('@playwright/test');
const { preview } = await import(pathToFileURL(requireViewer.resolve('vite')).href);
const pdfjs = await import(pathToFileURL(requireViewer.resolve('pdfjs-dist/legacy/build/pdf.mjs')).href);
await mkdir(RUN);
const receipt = { head: HEAD, startedUTC: new Date().toISOString(), scope: 'Native correctness only. Automation file changes record isTrusted; no trusted gesture or performance claim.', cases: [], console: [], uploads: [] };
let server, browser, context, page, deadline, browserSession, pageSession, ownContextId, ownFrameId, windowsFolder, mappedFolder;
const ownedDownloads = new Map();
const panel = () => page.locator('[data-document-panel]').first();
const papers = () => panel().locator('[data-preview-section]');
const bytes = await readFile(join(ROOT, 'apps/viewer/public/samples/building-architecture.ifc'));
receipt.model = { name: 'building-architecture.ifc', bytes: bytes.length, sha256: createHash('sha256').update(bytes).digest('hex'),
  source: `https://raw.githubusercontent.com/LTplus-AG/ifc-lite/baa7d34db1be4bc8bf0b3479df33275da3130fc6/apps/viewer/public/samples/building-architecture.ifc`,
  fileNameHeader: bytes.toString().match(/FILE_NAME\([^;]+;/)?.[0] };
assert.match(receipt.model.fileNameHeader, /SketchUp 2024/);
const png = await readFile(join(ROOT, 'apps/viewer/public/favicon-16x16-cropped.png'));
async function upload(input, name, buffer, mimeType) {
  const before = await page.evaluate(() => globalThis.__6610_uploads.length);
  await input.setInputFiles({ name, mimeType, buffer });
  await page.waitForFunction(count => globalThis.__6610_uploads.length > count, before);
  const observed = await page.evaluate(() => globalThis.__6610_uploads.at(-1));
  assert.deepEqual(observed.files, [{ name, size: buffer.length, type: mimeType }]);
  receipt.uploads.push({ name, bytes: buffer.length, sha256: createHash('sha256').update(buffer).digest('hex'), observed });
}
async function ready() {
  await expect(panel().locator('[data-document-preview]')).toHaveAttribute('aria-busy', 'false');
  await expect(papers().first()).toBeVisible();
  await expect(panel().locator('[data-document-export]')).toBeEnabled();
}
async function importTemplate(name, blocks, pageSetup = { size: 'A4', orientation: 'portrait' }) {
  // An actual saved template is input through the product's import control; no store injection.
  const template = { version: 12, id: `native-${name}`, name, page: pageSetup, blocks };
  await upload(panel().locator('[data-document-import]'), `${name}.ifclite-document.json`, Buffer.from(JSON.stringify(template)), 'application/json');
  await ready();
}
async function authorBands() {
  for (const [kind, text, font, size, height] of [
    ['heading', 'Issued for coordination', 'times', '12', '60'],
    ['footer', 'Controlled report copy', 'courier', '10', '40'],
  ]) {
    const editor = panel().locator(`[data-page-${kind}-editor]`);
    if (!(await editor.evaluate(element => element.open))) await editor.locator('summary').click();
    await panel().getByLabel(`Page ${kind} text`, { exact: true }).fill(text);
    await panel().getByLabel(`Page ${kind} font`, { exact: true }).selectOption(font);
    await panel().getByLabel(`Page ${kind} size`, { exact: true }).fill(size);
    await panel().getByLabel(`Page ${kind} size`, { exact: true }).press('Tab');
    await panel().getByLabel(`Page ${kind} date`, { exact: true }).check();
    await panel().getByLabel(`Page ${kind} page numbers`, { exact: true }).check();
    await upload(panel().getByLabel(`Page ${kind} logo`, { exact: true }), `${kind}.png`, png, 'image/png');
    await panel().getByLabel(`Page ${kind} logo height`, { exact: true }).fill(height);
    await panel().getByLabel(`Page ${kind} logo height`, { exact: true }).press('Tab');
  }
  await ready();
}
async function witness(name, expectedLines, { authored = true, count, landscape = false, documentName = name } = {}) {
  await ready();
  const maximize = page.getByRole('button', { name: 'Maximize', exact: true });
  if (await maximize.count()) await maximize.click();
  const actual = await papers().evaluateAll(nodes => nodes.map(paper => {
    const sheet = paper.getBoundingClientRect(), scale = sheet.width;
    const rect = el => { const box = el.getBoundingClientRect(); return { text: el.textContent, x: (box.x - sheet.x) / scale,
      top: (box.y - sheet.y) / scale, bottom: (box.bottom - sheet.y) / scale, fontSize: parseFloat(getComputedStyle(el).fontSize) / scale,
      color: getComputedStyle(el).color, font: getComputedStyle(el).fontFamily }; };
    return { width: sheet.width, height: sheet.height, paperColor: getComputedStyle(paper).backgroundColor,
      heading: [...paper.querySelectorAll('[data-page-heading]')].map(rect), footer: [...paper.querySelectorAll('[data-page-footer]')].map(rect),
      dates: [...paper.querySelectorAll('[data-page-date]')].map(rect), counters: [...paper.querySelectorAll('[data-page-counter]')].map(rect),
      logos: [...paper.querySelectorAll('img[data-page-logo]')].map(el => ({ ...rect(el), complete: el.complete, naturalWidth: el.naturalWidth })),
      body: [...paper.querySelectorAll('[data-block-text] > span')].map(rect) };
  }));
  if (count !== undefined) assert.equal(actual.length, count);
  else assert.ok(actual.length >= 2, 'real authored body overflows the canonical paper frame');
  for (const [index, sheet] of actual.entries()) {
    assert.equal(sheet.paperColor, 'rgb(255, 255, 255)');
    assert.equal(sheet.width > sheet.height, landscape);
    assert.equal(sheet.heading[0].text, authored ? 'Issued for coordination' : documentName);
    if (authored) {
      assert.equal(sheet.footer[0].text, 'Controlled report copy');
      assert.equal(sheet.logos.length, 2); assert.ok(sheet.logos.every(logo => logo.complete && logo.naturalWidth > 0));
      assert.equal(sheet.dates.length, 2); assert.equal(sheet.dates[0].text, sheet.dates[1].text);
      assert.deepEqual(sheet.counters.map(counter => counter.text), Array(2).fill(`Page ${index + 1} / ${actual.length}`));
      const headingBottom = Math.max(...sheet.heading.map(item => item.bottom), ...sheet.logos.slice(0, 1).map(item => item.bottom));
      const footerTop = Math.min(...sheet.footer.map(item => item.top), ...sheet.logos.slice(1).map(item => item.top));
      assert.ok(sheet.body.every(item => item.top > headingBottom && item.bottom < footerTop), 'every mounted body glyph clears the actual authored bands/logos');
    } else { assert.equal(sheet.logos.length, 0); assert.equal(sheet.dates.length, 0); assert.equal(sheet.counters[0].text, `Page ${index + 1} / ${actual.length}`); }
  }
  const viewport = panel().locator('[data-document-preview]').locator('..');
  // Whole-window captures are labelled partial; only the target band/body must be visibly contained.
  // Reach them using real native wheel events. Never write scrollTop or alter layout CSS.
  for (const [which, paper] of [['first', papers().first()], ['last', papers().last()]]) {
    for (const part of ['heading', 'footer']) {
      const target = paper.locator(`[data-page-${part}]`).first();
      const measureBand = () => target.evaluate((band, part) => {
        const rect = element => { const b = element.getBoundingClientRect(); return { x: b.x, y: b.y, right: b.right, bottom: b.bottom }; };
        const paper = band.closest('[data-preview-section]'), clips = [];
        for (let parent = band.parentElement; parent; parent = parent.parentElement) {
          const style = getComputedStyle(parent);
          if (/(auto|scroll|hidden|clip)/.test(style.overflow + style.overflowX + style.overflowY)) clips.push({ ...rect(parent), movingPaper: parent === paper });
        }
        return { band: rect(band), bandText: band.textContent, paper: rect(paper), clips, viewport: { width: innerWidth, height: innerHeight },
          bandParts: [...paper.querySelectorAll(`[data-page-${part}], [data-page-date="${part}"], [data-page-counter="${part}"], [data-page-logo="${part}"]`)].map(element => ({ text: element.textContent, ...rect(element) })),
          toasts: [...document.querySelectorAll('[data-toast-seq]')].map(element => ({ text: element.textContent, ...rect(element) })),
          body: [...paper.querySelectorAll('[data-block-text] > span')].map(element => ({ text: element.textContent, ...rect(element) })) };
      }, part);
      for (let attempt = 0; attempt < 8; attempt++) {
        const port = await viewport.boundingBox(), geometry = await measureBand(); assert.ok(port);
        // The paper moves together with its contents. Other actual clipping ancestors bound the scroll port.
        const fixedClips = geometry.clips.filter(clip => !clip.movingPaper);
        const top = Math.max(0, ...fixedClips.map(clip => clip.y)), bottom = Math.min(geometry.viewport.height, ...fixedClips.map(clip => clip.bottom));
        const bandTop = Math.min(...geometry.bandParts.map(box => box.y)), bandBottom = Math.max(...geometry.bandParts.map(box => box.bottom));
        const feasible = geometry.body.filter(box => box.text.trim()).map(box => {
          const lower = Math.max(bandBottom, box.bottom) - bottom + 2;
          const upper = Math.min(bandTop, box.y) - top - 2;
          return { lower, upper, delta: lower > 0 ? lower : upper < 0 ? upper : 0, body: box };
        }).filter(interval => interval.lower <= interval.upper).sort((a, b) => Math.abs(a.delta) - Math.abs(b.delta));
        (receipt.nativeScrollMeasurements ??= []).push({ name, which, part, attempt, top, bottom, bandTop, bandBottom, feasible, geometry });
        assert.ok(feasible.length, 'actual full band (text/date/counter/logo) and a body line fit together in the real native scroll port');
        if (Math.abs(feasible[0].delta) < 1) break;
        await page.mouse.move(port.x + port.width / 2, port.y + port.height / 2);
        await page.mouse.wheel(0, feasible[0].delta); await page.waitForTimeout(180);
      }
      // Let actual transient non-error notices expire naturally; errors are never dismissed or suppressed.
      const transientNotices = page.getByRole('status').locator('[data-toast-seq]').filter({ hasNot: page.getByRole('button', { name: 'Privacy settings', exact: true }) });
      (receipt.nativeTransientNotices ??= []).push({ name, which, part, messages: await transientNotices.allTextContents() });
      await expect(transientNotices).toHaveCount(0, { timeout: 5000 });
      // The asynchronous disclosure can arrive after authoring; dismiss it immediately before each capture.
      const privacyNotice = page.locator('[data-toast-seq]').filter({ has: page.getByRole('button', { name: 'Privacy settings', exact: true }) });
      assert.ok(await privacyNotice.count() <= 1, 'privacy disclosure identifies at most one actual toast');
      if (await privacyNotice.count()) {
        (receipt.dismissedPrivacyNotices ??= []).push({ name, which, part, text: await privacyNotice.innerText() });
        await privacyNotice.getByRole('button', { name: 'Dismiss notification', exact: true }).click();
        await expect(privacyNotice).toHaveCount(0);
      }
      const visible = await measureBand();
      const contained = box => box.x >= 0 && box.y >= 0 && box.right <= visible.viewport.width && box.bottom <= visible.viewport.height
        && visible.clips.every(clip => box.x >= clip.x - 1 && box.y >= clip.y - 1 && box.right <= clip.right + 1 && box.bottom <= clip.bottom + 1);
      const clearOfToasts = box => visible.toasts.every(toast => !(box.x < toast.right && box.right > toast.x && box.y < toast.bottom && box.bottom > toast.y));
      // Preserve actual geometry and image even if a finite visibility assertion fails.
      (receipt.visibleBands ??= []).push({ name, which, part, scope: 'Visible native band and body portion; not a complete-paper screenshot', visible });
      await page.screenshot({ path: join(RUN, `${name}-${which}-${part}-visible-viewport.png`) });
      assert.ok(contained(visible.band), 'labelled native band is genuinely visible inside every clipping ancestor');
      assert.ok(clearOfToasts(visible.band), 'no actual toast rectangle covers the captured band');
      assert.ok(visible.bandParts.every(box => contained(box) && clearOfToasts(box)), 'all actual band text/date/counter/logo rectangles are fully visible and clear of every toast');
      assert.ok(visible.body.some(box => contained(box) && clearOfToasts(box)), 'some actual body text is visible beside the captured band and clear of all toasts');
    }
  }
  const exportBefore = await page.evaluate(() => Date.now());
  const downloadPromise = page.waitForEvent('download', { timeout: 60000 });
  await panel().locator('[data-document-export]').click();
  const download = await downloadPromise, pdfPath = join(RUN, `${name}.pdf`);
  await expect.poll(() => [...ownedDownloads.values()].filter(row => row.url === download.url() && row.progress?.at(-1)?.state === 'completed').length).toBe(1);
  const completed = [...ownedDownloads.values()].find(row => row.url === download.url() && row.progress?.at(-1)?.state === 'completed');
  assert.match(completed.guid, /^[a-zA-Z0-9-]+$/); assert.equal(completed.frameId, ownFrameId);
  const nativeBytes = await readFile(join(mappedFolder, completed.guid));
  assert.equal(nativeBytes.subarray(0, 5).toString(), '%PDF-');
  assert.equal(nativeBytes.length, completed.progress.at(-1).receivedBytes, 'completed native download byte count matches the actual GUID file');
  await writeFile(pdfPath, nativeBytes); assert.equal(await download.failure(), null);
  (receipt.completedNativeDownloads ??= []).push({ ...completed, nativeFile: win32.join(windowsFolder, completed.guid), mappedFile: join(mappedFolder, completed.guid), copiedArtifact: pdfPath });
  const exportAfter = await page.evaluate(() => Date.now());
  const generatedFooters = [];
  const pdfBytes = await readFile(pdfPath);
  const independent = JSON.parse(execFileSync('/tmp/6232-takeover/6610-native-pdf-reader-venv/bin/python', [join(OUT, 'inspect-native-paper-pdfs.py'), pdfPath], { encoding: 'utf8', timeout: 30000 }));
  assert.equal(independent.pageCount, actual.length);
  assert.equal(independent.sha256, createHash('sha256').update(pdfBytes).digest('hex'));
  const capturedDates = actual[0].dates.map(date => date.text);
  const task = pdfjs.getDocument({ data: new Uint8Array(pdfBytes), stopAtErrors: true,
    standardFontDataUrl: `${join(dirname(requireViewer.resolve('pdfjs-dist/package.json')), 'standard_fonts')}/` });
  const parsedPages = [];
  try {
    const pdf = await task.promise; assert.equal(pdf.numPages, actual.length);
    for (let number = 1; number <= pdf.numPages; number++) {
      const pdfPage = await pdf.getPage(number), text = await pdfPage.getTextContent(), operators = await pdfPage.getOperatorList();
      const items = text.items.filter(item => 'str' in item), sheet = actual[number - 1];
      const imagePaints = operators.fnArray.filter(op => [pdfjs.OPS.paintImageXObject, pdfjs.OPS.paintInlineImageXObject].includes(op)).length;
      assert.equal(imagePaints, authored ? 2 : 0, 'real downloaded PDF paints both logos');
      for (const dom of [...sheet.heading, ...sheet.footer, ...sheet.dates, ...sheet.counters, ...sheet.body]) {
        const generatedFooter = !authored && sheet.footer.includes(dom);
        const candidates = items.filter(item => generatedFooter
          ? /^Generated (.+) · ifc-lite$/.test(item.str) : item.str === dom.text.trim());
        if (generatedFooter) {
          assert.equal(candidates.length, 1, 'exactly one complete generated footer per PDF page');
          const stamp = candidates[0].str.match(/^Generated (.+) · ifc-lite$/)[1];
          const clock = await page.evaluate(value => { const instant = Date.parse(value); return { instant, formatted: new Date(instant).toLocaleString(), locale: Intl.DateTimeFormat().resolvedOptions() }; }, stamp);
          assert.equal(clock.formatted, stamp, 'generated stamp uses the actual browser locale and time zone');
          const instant = clock.instant;
          assert.ok(Number.isFinite(instant) && instant >= exportBefore - 1000 && instant <= exportAfter + 1000, 'default PDF timestamp is the real export clock, to second precision');
          generatedFooters.push({ page: number, preview: dom.text, exported: candidates[0].str, instant, locale: clock.locale });
        }
        assert.ok(candidates.length, `actual PDF preserves mounted glyph text ${JSON.stringify(dom.text)}`);
        assert.ok(candidates.some(item => Math.abs(item.transform[4] - dom.x * pdfPage.view[2]) < 1
          && Math.abs((pdfPage.view[3] - item.transform[5]) - (dom.top + dom.fontSize) * pdfPage.view[2]) < 1), 'PDF glyph placement matches measured canonical DOM anchors; this does not measure browser glyph ink');
      }
      parsedPages.push({ number, width: pdfPage.view[2], height: pdfPage.view[3], items, imagePaints });
      pdfPage.cleanup();
    }
  } finally { await task.destroy(); }
  const allText = parsedPages.flatMap(p => p.items.map(item => item.str));
  for (const line of expectedLines) assert.ok(allText.includes(line), `actual PDF contains all authored lines: ${line}`);
  receipt.cases.push({ name, capturedDates, generatedFooters, exportClock: { before: exportBefore, after: exportAfter }, independent, pdf: { path: pdfPath, bytes: pdfBytes.length, sha256: createHash('sha256').update(pdfBytes).digest('hex') }, actual, parsedPages });
  await writeFile(join(RUN, `${name}-witness.json`), JSON.stringify(receipt.cases.at(-1), null, 2));
}
try {
  deadline = setTimeout(async () => {
    receipt.deadlineExceeded = true;
    try { await context?.close(); } catch (error) { receipt.deadlineContextCloseFailure = error.message; }
    try { await browser?.close(); } catch (error) { receipt.deadlineDisconnectFailure = error.message; }
  }, 300000);
  server = await preview({ root: join(ROOT, 'apps/viewer'), configFile: false, logLevel: 'error', preview: { host: '127.0.0.1', port: 0 } });
  const address = server.httpServer.address(); assert.ok(address && typeof address !== 'string');
  receipt.url = `http://127.0.0.1:${address.port}`;
  browser = await chromium.connectOverCDP('http://127.0.0.1:9343', { timeout: 15000 });
  receipt.chrome = browser.version(); assert.match(receipt.chrome, /^154\./);
  browserSession = await browser.newBrowserCDPSession();
  browserSession.on('Browser.downloadWillBegin', event => { if (event.frameId === ownFrameId) ownedDownloads.set(event.guid, { ...event, progress: [] }); });
  browserSession.on('Browser.downloadProgress', event => { const row = ownedDownloads.get(event.guid); if (row) row.progress.push(event); });
  context = await browser.newContext({ viewport: { width: 1600, height: 1000 }, locale: 'en-US', colorScheme: 'dark', acceptDownloads: true });
  page = await context.newPage(); page.setDefaultTimeout(30000);
  page.on('console', message => receipt.console.push({ type: message.type(), text: message.text() }));
  page.on('pageerror', error => receipt.console.push({ type: 'pageerror', text: error.message }));
  await page.goto(receipt.url); await page.bringToFront();
  pageSession = await context.newCDPSession(page);
  const target = (await pageSession.send('Target.getTargetInfo')).targetInfo;
  ownContextId = target.browserContextId; ownFrameId = (await pageSession.send('Page.getFrameTree')).frameTree.frame.id;
  assert.ok(ownContextId && ownFrameId); receipt.ownedTarget = { targetId: target.targetId, browserContextId: ownContextId, frameId: ownFrameId };
  mappedFolder = await mkdtemp('/mnt/c/Users/louistrue/AppData/Local/Temp/ifc-lite-6610-download-');
  windowsFolder = win32.join('C:/Users/louistrue/AppData/Local/Temp', basename(mappedFolder));
  assert.ok(win32.isAbsolute(windowsFolder));
  assert.ok(ownContextId && ownFrameId, 'override requires the actual owned context and page frame');
  const override = { behavior: 'allowAndName', browserContextId: ownContextId, downloadPath: windowsFolder, eventsEnabled: true };
  receipt.ownedDownloadOverride = { command: override, response: await browserSession.send('Browser.setDownloadBehavior', override), mappedFolder };
  const observeUploads = () => { globalThis.__6610_uploads = []; document.addEventListener('change', event => {
    const input = event.target; if (!(input instanceof HTMLInputElement) || input.type !== 'file') return;
    globalThis.__6610_uploads.push({ isTrusted: event.isTrusted, accept: input.accept, files: [...(input.files ?? [])].map(file => ({ name: file.name, size: file.size, type: file.type })) });
  }, { capture: true }); };
  await page.addInitScript(observeUploads);
  await page.evaluate(observeUploads);
  receipt.adapter = await page.evaluate(async () => { const adapter = await navigator.gpu?.requestAdapter(); if (!adapter) throw new Error('Native adapter unavailable'); return { vendor: adapter.info.vendor, architecture: adapter.info.architecture, device: adapter.info.device, description: adapter.info.description, fallback: adapter.info.isFallbackAdapter }; });
  assert.equal(receipt.adapter.fallback, false); assert.ok(!/swiftshader|llvmpipe|lavapipe|software/i.test(JSON.stringify(receipt.adapter)));
  await upload(page.locator('#file-input-add'), receipt.model.name, bytes, 'application/x-step');
  await page.waitForFunction(() => { const s = globalThis.__ifc_lite_viewer_store__?.getState(); const rendered = globalThis.__ifc_lite_render_stats__?.(); return s?.models.size === 1 && !s.loading && !s.geometryStreamingActive && s.error === null && [...s.models.values()].every(model => (model.loadState === undefined || model.loadState === 'complete') && model.ifcDataStore && model.geometryResult?.meshes.length && model.sourceFingerprint) && rendered?.frame?.drawCalls > 0 && rendered?.gpu?.total > 0; }, null, { timeout: 120000 });
  receipt.model.loaded = await page.evaluate(() => { const s = globalThis.__ifc_lite_viewer_store__.getState(); return { meshes: s.geometryResult.meshes.length, models: [...s.models.values()].map(m => ({ name: m.name, schema: m.ifcDataStore?.schema })), render: globalThis.__ifc_lite_render_stats__?.() }; });
  const frame = await page.evaluate(() => globalThis.__ifc_lite_capture_color_frame__?.());
  assert.match(frame ?? '', /^data:image\/png;base64,/);
  await writeFile(join(RUN, 'native-public-ifc-renderer.png'), Buffer.from(frame.split(',')[1], 'base64'));
  await page.screenshot({ path: join(RUN, 'native-public-ifc-whole-viewer.png') });
  await page.getByRole('tab', { name: /Analyze/i }).first().click();
  await page.getByRole('button', { name: /^Document/ }).first().click(); await expect(panel()).toBeVisible();
  const lines = Array.from({ length: 100 }, (_, i) => `Evidence line ${String(i + 1).padStart(3, '0')}`);
  await importTemplate('Native overflow', [{ kind: 'text', id: 'model-binding', style: 'body', text: 'Model {Model.Name}' }, { kind: 'text', id: 'evidence', style: 'body', text: lines.join('\n') }]);
  await expect(panel().locator('[data-block-text]').first()).toContainText('Model building-architecture.ifc');
  await authorBands(); await witness('Native overflow', lines);
  await page.reload(); await page.getByRole('tab', { name: /Analyze/i }).first().click();
  await page.getByRole('button', { name: /^Document/ }).first().click(); await ready();
  // Active selection is session-only; reopen the actual durably saved document through its UI.
  await panel().getByLabel('Document', { exact: true }).selectOption({ label: 'Native overflow' });
  await ready();
  await expect(panel().getByLabel('Page heading text', { exact: true })).toHaveValue('Issued for coordination');
  await expect(panel().getByLabel('Page footer text', { exact: true })).toHaveValue('Controlled report copy');
  receipt.persistenceReload = true;
  for (const kind of ['heading', 'footer']) { const editor = panel().locator(`[data-page-${kind}-editor]`); if (!(await editor.evaluate(el => el.open))) await editor.locator('summary').click(); await panel().getByRole('button', { name: `Reset page ${kind}`, exact: true }).click(); }
  await witness('Native defaults after reset', lines, { authored: false, documentName: 'Native overflow' });
  const explicit = Array.from({ length: 11 }, (_, i) => `Explicit evidence ${i + 1}`);
  await importTemplate('Native eleven pages', explicit.flatMap((text, i) => [...(i ? [{ kind: 'page-break', id: `break-${i}` }] : []), { kind: 'text', id: `body-${i}`, style: 'body', text }]));
  await authorBands(); await witness('Native eleven pages', explicit, { count: 11 });
  await panel().getByLabel('Page size', { exact: true }).selectOption('A3');
  await panel().getByLabel('Orientation', { exact: true }).selectOption('landscape');
  await witness('Native A3 landscape', explicit, { count: 11, landscape: true });
  assert.equal(receipt.console.filter(message => message.type === 'pageerror').length, 0, 'unhandled errors are retained and block qualification');
  receipt.success = true;
} catch (error) { receipt.failure = { message: error.message, stack: error.stack }; throw error; }
finally {
  clearTimeout(deadline);
  try { await context?.close(); receipt.ownedContextClosed = true; } catch (error) { receipt.contextCloseFailure = error.message; }
  try { await browser?.close(); receipt.cdpDisconnected = true; } catch (error) { receipt.disconnectFailure = error.message; }
  try { if (server) await new Promise((resolve, reject) => server.httpServer.close(error => error ? reject(error) : resolve())); receipt.serverClosed = true; } catch (error) { receipt.serverCloseFailure = error.message; }
  receipt.allOwnedDownloadEvents = [...ownedDownloads.values()];
  if (mappedFolder) { try { await rm(mappedFolder, { recursive: true }); receipt.ownedDownloadFolderRemoved = true; } catch (error) { receipt.downloadFolderCleanupFailure = error.message; } }
  receipt.endedUTC = new Date().toISOString(); await writeFile(join(RUN, 'receipt.json'), JSON.stringify(receipt, null, 2));
  console.log(JSON.stringify({ head: HEAD, directory: RUN, success: receipt.success ?? false, failure: receipt.failure, endedUTC: receipt.endedUTC }));
}
