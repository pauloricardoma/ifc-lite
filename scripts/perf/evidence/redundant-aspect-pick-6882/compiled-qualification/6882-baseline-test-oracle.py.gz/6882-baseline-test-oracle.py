from pathlib import Path
import subprocess,json
wt=Path('/home/louistrue/wt/6882-aspect-pick-session6503');out=Path('/tmp/6232-takeover/perf-reset-20261004')
files=['packages/renderer/src/camera.ts','packages/renderer/src/picking-manager.ts'];saved={f:(wt/f).read_bytes() for f in files}
try:
 for f in files:(wt/f).write_bytes(subprocess.check_output(['git','show','HEAD:'+f],cwd=wt))
 with (out/'6882-renderer-tests-unfixed-oracle.log').open('w') as log:r=subprocess.run(['pnpm','test','--filter=@ifc-lite/renderer'],cwd=wt,stdout=log,stderr=subprocess.STDOUT)
 (out/'6882-unfixed-oracle-result.json').write_text(json.dumps({'command':'pnpm test --filter=@ifc-lite/renderer','unfixedProduction':'HEAD 804627743','newTestsRetained':True,'exitCode':r.returncode,'restoration':'finally restores exact fixed source bytes'},indent=2))
finally:
 for f,data in saved.items():(wt/f).write_bytes(data)
