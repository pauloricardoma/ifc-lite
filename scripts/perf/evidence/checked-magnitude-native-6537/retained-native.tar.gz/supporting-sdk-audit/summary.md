# Independent SDK cohort audit — run 37139268390

All 56 samples and 28 pairs satisfy the retained hosted protocol; 1,045 independent artifact/receipt/source checks passed. Two A/A pairs preceded five alternating A/B pairs per family. No samples were removed, replaced or pooled with earlier refused runs.

BASE `0a16f532ceb8f177d02ee29f4645e6f048fbace5`; CANDIDATE `07bdf45b5d470413d3796b3189d588a91a09a0d6`. Actual fresh serial root builds each executed six uncached tasks. Producing log hashes, transform pre/post bytes, emitted endpoint assets and WASM pins match. Browser Chrome 154.0.8037.57 reported four cores, SAB/isolation enabled, no overrides and two default workers [0,1] for every sample.

Candidate minus baseline; positive is slower. Arm elapsed medians below use the five A/B samples only; the JSON also retains all nine baseline samples, raw values and both spread definitions.

| Family | Five paired deltas (%) | Median (%) | Range (%) | BASE / CAND median ms | BASE / CAND spread % |
|---|---|---:|---|---|---|
| house | -11.726, -2.858, +8.226, +0.959, +0.917 | +0.917 | -11.726 to +8.226 | 577.340 / 581.670 | 12.399 / 9.157 |
| csg | +0.269, -8.323, -1.573, -1.520, -1.053 | -1.520 | -8.323 to +0.269 | 4510.310 / 4437.610 | 8.260 / 2.591 |
| heavy-csg | +2.078, -0.145, +1.986, +1.724, -0.618 | +1.724 | -0.618 to +2.078 | 5364.965 / 5420.790 | 2.454 / 2.450 |
| architecture | +0.867, +1.406, +0.721, -0.302, +0.397 | +0.721 | -0.302 to +1.406 | 4259.370 / 4298.310 | 1.039 / 1.458 |

Spread = (maximum − minimum) / median. The largest A/A absolute change was 8.362%, within the declared 10% control bound. Three family paired medians are slower; ISSUE_129 is modestly faster with appreciable baseline spread. This cohort establishes no consistent SDK speed benefit.

All 168 independently recomputed CPU intervals lasted at least 1.000072789 seconds and stayed at or below 1.995013% busy, with empty pre/post graph scans. Initial available memory was 15,540,928,512 bytes; minimum sampled live availability 12,567,777,280 bytes; maximum sampled owned RSS 3,751,907,328 bytes. All satisfy the declared 8/4/5 GiB bounds. The largest retained CPU payload was 108,394,892 bytes. All 56 stream completions, generator drains, processor disposals, browser/process cleanups, log flushes and pre-teardown hashes passed. Final cleanup reports 602 witnessed processes, zero remnants/zombies and zero server sockets; final frozen-input verification is complete.

CPU-channel SHA/flat-instance/triangle identities and entire unnormalized diagnostic objects match across all 14 samples of each family. ISSUE_129 retains 44 CSG diagnostics (30 bounded-halfspace fallback, 13 KernelError, one NoBoundsOverlap); semantic warning records remain present. These are existing approximation/omission disclosures, not faithful-IFC proof.

Limits: this is the public default SDK worker stream timed from initialization through drain, retention and disposal; hashes run afterward. It excludes viewer metadata/readiness, annotation/GPU/pixel identity, native attribution and universal performance. Raw geometry arrays are not archived, so the audit compares observed CPU output hashes rather than independently rehashing arrays. Remote source/tool final equality is an actual retained runtime receipt, not a new post-teardown filesystem measurement. RSS and graph/CPU observations are sampled, not physical peaks or continuous host proof.
