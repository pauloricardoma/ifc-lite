import gzip,hashlib,io,json,pathlib,subprocess,tarfile
R=pathlib.Path('/tmp/6232-takeover'); O=R/'6537-checked-magnitude-evidence-source-v2'
W=pathlib.Path('/home/louistrue/wt/6537-checked-magnitude-products-session6503')
HEAD='07bdf45b5d470413d3796b3189d588a91a09a0d6'; BASE='0a16f532ceb8f177d02ee29f4645e6f048fbace5'
sha=lambda b:hashlib.sha256(b).hexdigest(); entries={}
def put(member,b,origin,kind):
 assert not member.startswith('/') and '..' not in pathlib.PurePosixPath(member).parts
 assert member not in entries and not b.startswith(b'\x7fELF')
 assert not member.lower().endswith(('.ifc','.wasm','.deb','.exe','.dll','.so')) and 'node_modules' not in pathlib.PurePosixPath(member).parts and '.capture.' not in member
 entries[member]={'bytes':b,'originalPath':origin,'kind':kind}
def add(p,member,kind):
 p=pathlib.Path(p);assert p.is_file() and not p.is_symlink(),p
 put(member,p.read_bytes(),str(p),kind)
def folder(name,kind):
 for f in sorted((R/name).rglob('*')):
  if f.is_file():
   assert not f.is_symlink()
   add(f,name+'/'+str(f.relative_to(R/name)),kind)
# Frozen V1 packet is a lossless dependency, not a new clean-head claim.
V=R/'6537-checked-magnitude-evidence-source-v1'; vi=json.loads((V/'artifact-index.json').read_text())
vb=(V/'retained-v1.tar.gz').read_bytes();assert sha(vb)==vi['archiveSha256'] and len(vb)==vi['archiveBytes']
with tarfile.open(V/'retained-v1.tar.gz','r:gz') as t:
 vm=json.loads(t.extractfile('member-manifest.json').read())
 assert len(t.getmembers())==vi['archiveMemberCount']
 for row in vm['members']:
  b=t.extractfile(row['path']).read();assert len(b)==row['storedMemberBytes'] and sha(b)==row['sha256']
for n in ['retained-v1.tar.gz','artifact-index.json','member-manifest.json','README.md']:
 add(V/n,'dependency-v1/'+n,'immutable-native-output-and-instruction-dependency')
# Final sources come from literal Git objects, not the mutable working tree.
bp=json.loads((R/'6537-checked-magnitude-build-provenance-v1/build-post.json').read_text())
assert bp['actualBuiltHead']==HEAD and bp['allRustCompilerInputsUnchanged']
changed=subprocess.check_output(['git','-C',str(W),'diff','--name-only',BASE,HEAD],text=True).splitlines()
assert changed==['rust/geometry/src/kernel/fixed_int/magnitude_mul_tests.rs','rust/geometry/src/kernel/fixed_int/mod.rs','rust/geometry/src/kernel/fixed_int/mul.rs']
for n in changed+['Cargo.toml','Cargo.lock','rust-toolchain.toml','rust/geometry/Cargo.toml','rust/processing/Cargo.toml']:
 b=subprocess.check_output(['git','-C',str(W),'show',HEAD+':'+n])
 if n in bp['inputSHA256After']:assert sha(b)==bp['inputSHA256After'][n],n
 put('final-source/'+n,b,'git:'+HEAD+':'+n,'immutable-final-source')
put('final-source/base-to-final.diff',subprocess.check_output(['git','-C',str(W),'diff','--binary',BASE,HEAD]),'git:'+BASE+'..'+HEAD,'immutable-review-patch')
for n in ['6537-checked-magnitude-carry-controls-v2-fit-first','6537-checked-magnitude-build-provenance-v1','6537-checked-magnitude-endpoint-producer-source-v1','6537-checked-magnitude-timing-prospective-v1','6537-checked-magnitude-runtime-window-v1','6537-checked-magnitude-remote-comparison-v1']:
 folder(n,'actual-v2-correctness-or-source-runtime-receipt')
for stem in ['6537-checked-magnitude-workspace-tests-v2-compact-debug','6537-checked-magnitude-strict-clippy-v2-final','6537-checked-magnitude-install-v1','6537-checked-magnitude-wasm-v1','6537-checked-magnitude-wasm-contract-v1','6537-checked-magnitude-wasm-contract-fixtures-v1','6537-checked-magnitude-root-build-v1','6537-checked-magnitude-endpoint-build-v1']:
 for suffix in ['.json','.log']:
  p=R/(stem+suffix)
  if suffix=='.json':
   d=json.loads(p.read_text());assert 'endedUTC' in d and 'childExit' in d,p
  add(p,'terminal-receipts/'+p.name,'actual-terminal-receipt')
for n in ['6537-checked-magnitude-workspace-tests-v2-summary.json','6537-checked-magnitude-tests-v2-change.json']:
 add(R/n,'terminal-receipts/'+n,'actual-v2-summary')
# Freeze BASE producer/adapter referenced by actual runtime lease, not transitive
# package source files named in those hash maps.
l=json.loads((R/'6537-checked-magnitude-runtime-window-v1/runtime-lease-root-actual-v2-house.json').read_text())
bqpath=pathlib.Path(l['roles']['BASE']['qualificationPath']);bq=json.loads(bqpath.read_text())
assert sha(bqpath.read_bytes())==l['roles']['BASE']['qualificationSha256']
add(bqpath,'base-endpoint/base-root-adapter-qualification.json','historical-base-endpoint-qualification')
pr=pathlib.Path(bq['producer']['path']);assert sha(pr.read_bytes())==bq['producer']['sha256']
add(pr,'base-endpoint/base-original-producer.json','historical-base-original-producer')
# Exact dispatched harness source is context only; dispatch receipt has no result.
hr='68e2f9ee5a369d7fa4c3793acf6b6f06585b306d'
for n in ['.github/workflows/benchmark.yml','.github/workflows/perf-interleaved.yml','scripts/perf/INTERLEAVED.md']:
 put('remote-dispatch-source/'+n,subprocess.check_output(['git','-C',str(W),'show',hr+':'+n]),'git:'+hr+':'+n,'exact-dispatched-harness-context')
manifest={'scope':'V2 final-source correctness and unaccepted local runtime/remote dispatch retention; no accepted timing or performance verdict. Input maps are JSON only, no referenced packages/model/binary payloads copied.','members':[]}
for n,v in sorted(entries.items()):
 b=v['bytes']; row={'path':n,'originalPath':v['originalPath'],'kind':v['kind'],'originalInputBytes':len(b),'storedMemberBytes':len(b),'sha256':sha(b)}
 if n.endswith('.gz'):
  dec=gzip.decompress(b);row.update(precompressedPayloadBytes=len(dec),precompressedPayloadSha256=sha(dec))
 manifest['members'].append(row)
mb=(json.dumps(manifest,indent=2)+'\n').encode();a=O/'retained-v2.tar.gz'
with a.open('xb') as raw:
 with gzip.GzipFile(filename='',fileobj=raw,mode='wb',mtime=0,compresslevel=9) as g:
  with tarfile.open(fileobj=g,mode='w|',format=tarfile.PAX_FORMAT) as t:
   for n,b in [(n,v['bytes']) for n,v in sorted(entries.items())]+[('member-manifest.json',mb)]:
    ti=tarfile.TarInfo(n);ti.size=len(b);ti.mode=0o644;ti.mtime=0;ti.uid=ti.gid=0;ti.uname=ti.gname='';t.addfile(ti,io.BytesIO(b))
with tarfile.open(a,'r:gz') as t:
 assert len(t.getmembers())==len(entries)+1
 for m in t.getmembers():
  assert m.isfile() and not m.name.startswith('/') and '..' not in pathlib.PurePosixPath(m.name).parts
  b=t.extractfile(m).read();exp=mb if m.name=='member-manifest.json' else entries[m.name]['bytes'];assert b==exp and sha(b)==sha(exp)
 assert t.extractfile('member-manifest.json').read()==mb
(O/'member-manifest.json').write_bytes(mb)
idx={'archive':'retained-v2.tar.gz','archiveBytes':a.stat().st_size,'archiveSha256':sha(a.read_bytes()),'originalArtifactCount':len(entries),'archiveMemberCount':len(entries)+1,'originalInputBytes':sum(len(v['bytes']) for v in entries.values()),'storedArtifactMemberBytes':sum(len(v['bytes']) for v in entries.values()),'manifestBytes':len(mb),'memberManifestSha256':sha(mb),'roundtripAllBytesAndHashes':True,'gzipMtime':0,'head':HEAD,'V1DependencySha256':vi['archiveSha256'],'V1All133ArtifactsVerified':True,'sourceFilesMatchFinalBuildInputMap':True,'scope':'Archive-only operations. No accepted timing, compiler/browser/model run or publication.'}
(O/'artifact-index.json').write_text(json.dumps(idx,indent=2)+'\n');print(json.dumps(idx,indent=2))
