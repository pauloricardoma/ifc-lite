# Checked-magnitude products: retained V2 evidence

This archive freezes final optimizer source `07bdf45b5d470413d3796b3189d588a91a09a0d6`, completed correctness/build receipts, terminal unaccepted local SDK timing attempts, and the actual hosted-viewer dispatch receipt. **No accepted elapsed-time or browser performance verdict exists in this packet.** No IFC files, model capture payloads, executable/WASM binaries, node_modules or generated package files are included. Frozen input maps and asset inventories remain JSON; their referenced payloads were not recursively copied.

## Final source and correctness

The three changed Rust files are read from literal Git objects, with the base-to-final patch and compiler/Cargo source context. All three match the actual final build input map. Production mod.rs/mul.rs remain byte-identical to the V1 proposal; V2 tests add a provably-fitting carry-first case and direct boundary comparisons.

Full terminal logs and guardian receipts retain: native workspace: 4,432 passed, 0 failed, 39 ignored, final workspace/all-target strict Clippy exit 0, official WASM contracts: 140 passed, 0 failed, 5 skipped, fresh 62/62 root build tasks, actual frozen install/sourceWASM/endpoint build and complete pre/post compiler-input provenance. Debug information and incremental caches were disabled for repeated native correctness after the V1 disk-space interruption. These are correctness/build observations, not performance measurements.

V2 carry controls retain all original source patches, runner, phase logs and terminal guards. Zeroing native row-end carry first fails the real fitting CheckedMul oracle on `(u64::MAX)^2` for every supported K. Zeroing u32 row-end carry first fails the eligible bounded-digit product oracle for all four K. Both mutated phases compile and produce four genuine runtime assertion failures; restored source passes all four selected tests and exactly matches the initial production hash. Native-host u32 execution is distinguished from the separately retained official WASM boundary tests.

## Endpoint and refused local window

Candidate producer/adapter qualifications, source equivalence, helper/endpoint source and asset/compiler/tool identities are retained verbatim, including earlier prospective UNRUN labels as historical source status. Completed producer status is not a runtime lease. Original BASE producer/adapter identities are pinned separately; no historical BASE artifact is relabelled as a fresh build or different commit.

The first local cohort refused before any sample because foreign build/test graphs were active. The second captured two baseline samples but failed Windows postflight CPU admission; its A/A pair is unaccepted and no A/B pair qualified. Raw diagnostic/error/semantic-warning fields and all final source/asset audits and owned cleanup receipts remain intact. Both timing values stay excluded. The early window-release receipt records owned browsers drained and timing verdict NONE.

## Immutable V1 dependency

The original V1 archive, index, manifest and README are copied unchanged. Its archive SHA256 is `88c319df82d03de11234ed42eca0d98004c190002977f0e63bbfeea780199032`; all 133 original artifact members were independently reverified. It retains full native controls/instruction profiles, source/function groups and tool identities. Those support native output identity and selected instruction-cost attribution only. Historical V1 workspace interruption has no verdict. Baseline source verification is postcapture and its symbol build lacks a full prebuild input freeze; adapter serialization differs outside the selected processor collection boundary. V2 does not repair or conceal those limits.

## Distinct remote dispatch

Run [37127288740](https://github.com/LTplus-AG/ifc-lite/actions/runs/37127288740) was actually accepted for harness `68e2f9ee5a369d7fa4c3793acf6b6f06585b306d`, BASE `0a16f532ceb8f177d02ee29f4645e6f048fbace5`, CAND `07bdf45b5d470413d3796b3189d588a91a09a0d6`. The frozen receipt says IN_PROGRESS_NO_TIMING_VERDICT. Exact workflow/protocol source accompanies it. This is the distinct 48-sample hosted full-viewer protocol: actual default worker count, SwiftShader, 5 GiB owned sampled RSS, one A/A plus five alternating A/B pairs for each fixed public family. It is not the refused local 8-worker SDK contract, Windows/native GPU performance or universal benefit. Later run status/results are not inferred here.

## Lossless verification

`retained-v2.tar.gz` uses gzip mtime 0 and fixed tar metadata. Every original artifact has a relative regular-file member, source identifier, stored/original byte counts and SHA256 in `member-manifest.json`; compressed dependency decoded byte counts/hashes are also retained. The archive was fully decompressed and every member compared byte-for-byte, including its embedded manifest. `artifact-index.json` records counts and archive identity; `archive.py` records selection and verification. This task performed only source/file reads and TEMP archival writes: no repo edits, builds, tests, browser/model execution, dispatch or publication.
