Native attribution: complete-native-attribution. 

Canonical phases are from the best-total iteration. Five raw total/wall times and ordered mesh FNVs are retained per process. No browser or full-output identity claim.
