import json, pathlib, hashlib, re, math, statistics, subprocess, datetime
root=pathlib.Path('/tmp/6232-takeover/6537-native-hosted-remote-v4'); artifact=root/'artifacts/native-phase-37149940166-1'; wt=pathlib.Path('/home/louistrue/wt/6537-native-phase-hosted-session6503')
read=lambda p:json.loads(p.read_text()); sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
report=read(artifact/'report.json'); provenance=read(artifact/'provenance.json'); protocol=read(artifact/'protocol.json'); run=read(root/'run.json')
errors=[]; checks=[]
def check(ok,name):
 checks.append({'name':name,'pass':bool(ok)})
 if not ok: errors.append(name)
controller='c32830300ebbfe919a9d69df94197dc2ae8cceb0'; refs={'base':'0a16f532ceb8f177d02ee29f4645e6f048fbace5','candidate':'07bdf45b5d470413d3796b3189d588a91a09a0d6'}
check(run['status']=='completed' and run['conclusion']=='success' and run['headSha']==controller,'terminal workflow exact controller SUCCESS')
check(report['status']=='complete-native-attribution' and report.get('finalFrozenVerification')=='complete' and not report.get('reason'),'cohort terminal qualification')
check(provenance['status']=='qualified-native-builds-not-timing' and provenance['finalFrozenVerification']=='complete' and provenance['revisions']==refs,'exact frozen source builds')
check(protocol['revisions']==refs and protocol['limits']['initialBytes']==8*1024**3 and protocol['limits']['liveBytes']==4*1024**3 and protocol['limits']['rssBytes']==5*1024**3 and protocol['limits']['drainMs']==3000,'unchanged native resource contract')
schedule=[{'family':'house','kind':'AA','order':['base','base']} for _ in range(2)]+[{'family':f,'kind':'AB','order':['base','candidate'] if i%2==0 else ['candidate','base']} for f in ['house','csg','heavy-csg'] for i in range(5)]
check(len(report['pairs'])==17 and protocol['schedule']==schedule,'exact 17-pair schedule')
startup=read(artifact/'startup-control/control.json')
check(startup['status']=='complete-real-startup-control' and startup['frozenRustupFinalVerification']['status']=='complete' and startup['ownedTemporaryCrateRemoved'] and startup['lockHolderExit']=={'code':0,'signal':None,'stderr':''},'actual startup admission control qualified')
for phase in ['warm','sample']:
 control=startup[phase];check(control['status']=='complete' and control['exit']==0 and control['signal'] is None and control['cleanup']['status']=='complete' and control['cleanup']['remaining']==[] and control['cleanup']['zombies']==0,'startup '+phase+' success/cleanup')
check(bool(startup['sample']['cargoExceptions']),'startup actual freshness Cargo witnessed')
rows=[]; familyIdentities={}; maxCPU=0; maxRSS=0; cleanupWitnesses=0; rawHashes=[]; summaries={}
phases=['indexBuildMs','parseMs','entityScanMs','lookupMs','preprocessMs','geometryMs','facetedBrepMs','totalMs'];numeric=phases+['fileMb','entities','meshes','vertices','triangles','pointCacheHits','pointCacheMisses','csgFailures','degenerateDropped'];fields=set(numeric+['path','allTotalsMs','allWallMs','meshFingerprintsFnv1a64'])
identity=lambda r:[*[r[k] for k in ['entities','meshes','vertices','triangles','csgFailures','degenerateDropped']],r['meshFingerprintsFnv1a64']]
for i,pair in enumerate(report['pairs']):
 expected=schedule[i];check(all(pair.get(k)==v for k,v in expected.items()) and pair['index']==i and pair['status']=='complete' and len(pair['runs'])==2,f'pair{i} exact role/status')
 check(read(artifact/f'pair-{i}.json')==pair,f'pair{i} raw receipt equality')
 for side in ['before','after']:
  cpu=pair[side];check(len(cpu['rows'])==4 and len(cpu['intervals'])==3 and not cpu['before']['active'] and not cpu['after']['active'],f'pair{i} {side} four readings / empty observable graphs')
  for n,(a,b) in enumerate(zip(cpu['rows'],cpu['rows'][1:])):
   def counters(row):
    fields=list(map(int,row['raw'].split()[1:]));assert len(fields)==8
    return sum(fields),fields[3]+fields[4]
   aa=counters(a);bb=counters(b);check(str(aa[0])==a['total'] and str(aa[1])==a['idle'] and str(bb[0])==b['total'] and str(bb[1])==b['idle'],f'pair{i} {side} interval{n} raw tick sums')
   total=bb[0]-aa[0];idle=bb[1]-aa[1];elapsed=int(b['monotonicNs'])-int(a['monotonicNs']);z=cpu['intervals'][n];percent=100*(1-idle/total)
   check(elapsed>=10**9 and total>0 and 0<=idle<=total and idle*10>=total*9 and z['eligible'] and int(z['elapsedNs'])==elapsed and int(z['totalTicks'])==total and int(z['idleTicks'])==idle and math.isclose(percent,z['cpuPercent'],abs_tol=1e-10),f'pair{i} {side} interval{n} independent <=10% fresh CPU')
   maxCPU=max(maxCPU,percent)
 for slot,sample in enumerate(pair['runs']):
  rows.append(sample);arm=expected['order'][slot]; fixture=next(x for x in provenance['fixtures'] if x['family']==pair['family']);directory=provenance['directories'][arm]
  check(sample['arm']==arm and sample['status']=='complete' and sample['exit']==0 and sample['signal'] is None and sample['directory']==directory and sample['compilerSelection']=={k:provenance['tools'][k] for k in ['rustc','rustdoc','toolchain']},f'pair{i}/{slot} actual role/child/compiler')
  check(sample['command']==['bash','scripts/perf/probe.sh',fixture['file'],'--iters','5','--json','--fingerprint'],f'pair{i}/{slot} exact 5-iteration canonical command')
  result=sample['result']; stdout=artifact/pathlib.Path(sample['paths']['stdout']).name;stderr=artifact/pathlib.Path(sample['paths']['stderr']).name
  check(sample['hashes']==[sha(stdout),sha(stderr)] and read(stdout)==[result],f'pair{i}/{slot} raw stdout/stderr SHA and JSON equality');rawHashes.extend([{'path':stdout.name,'sha256':sha(stdout)},{'path':stderr.name,'sha256':sha(stderr)}])
  text=stderr.read_text();check(not re.search(r'\bCompiling\b|\bChecking\b|\bRunning\s+.*(?:rustc|build-script)|error:|warning:|panic|retry|recover|skip ',text,re.I) and len(re.findall(r'^\s*Finished `profiling` profile \[optimized \+ debuginfo\] target\(s\) in [0-9.]+(?:ms|s)$',text,re.M))==1,f'pair{i}/{slot} actual Cargo fresh-only stderr')
  check(set(result)==fields and result['path']==fixture['file'] and all(isinstance(result[k],(int,float)) and math.isfinite(result[k]) and result[k]>=0 for k in numeric),f'pair{i}/{slot} exact result schema')
  check(all(len(result[k])==5 and all(isinstance(v,(int,float)) and math.isfinite(v) and v>0 for v in result[k]) for k in ['allTotalsMs','allWallMs']) and result['totalMs']==min(result['allTotalsMs']) and len(result['meshFingerprintsFnv1a64'])==5 and all(re.fullmatch('[a-f0-9]{16}',v) for v in result['meshFingerprintsFnv1a64']) and len(set(result['meshFingerprintsFnv1a64']))==1,f'pair{i}/{slot} 5 raw iterations and stable ordered FNV')
  familyIdentities.setdefault(pair['family'],identity(result));check(identity(result)==familyIdentities[pair['family']],f'pair{i}/{slot} family-wide counts/FNV identical')
  c=sample['cleanup'];cleanupWitnesses+=c['witnessed'];check(c['status']=='complete' and c['zombies']==0 and not c['remaining'] and all(z['status']=='complete' for z in sample['flush']) and sample.get('pipeTailCertified',True) is not False and sample['samples'],f'pair{i}/{slot} cleanup/logflush/observations')
  rss=max(z['bytes'] for z in sample['samples']);maxRSS=max(maxRSS,rss);check(rss<=5*1024**3,f'pair{i}/{slot} actual sampled own RSS <=5GiB')
  for exc in sample['cargoExceptions']:
   check(exc['executableObserved'] is True and exc['cwd']==directory and exc['executable'] in [provenance['tools']['cargo'],provenance['tools']['rustup']] and pathlib.Path(exc['argv'][0]).name=='cargo' and exc['argv'][1:]==['build','--profile','profiling','-p','ifc-lite-processing','--example','perf_probe'] and exc['admission']=='exact-selected-path',f'pair{i}/{slot} frozen freshness Cargo exception')
 if pair['kind']=='AA':
  for field in ['allTotalsMs','allWallMs']:
   vals=[statistics.median(r['result'][field]) for r in pair['runs']];check(abs(vals[1]/vals[0]-1)<=.1,f'pair{i} independent AA {field} <=10%')
 else:
  base=next(r['result'] for r in pair['runs'] if r['arm']=='base');candidate=next(r['result'] for r in pair['runs'] if r['arm']=='candidate')
  deltas={k:(100*(candidate[k]/base[k]-1) if base[k]>0 else None) for k in phases};deltas.update({k:100*(statistics.median(candidate[k])/statistics.median(base[k])-1) for k in ['allTotalsMs','allWallMs']})
  check(all((v is None and pair['deltasPercent'][k] is None) or (v is not None and math.isclose(v,pair['deltasPercent'][k],abs_tol=1e-10)) for k,v in deltas.items()),f'pair{i} recomputed deltas')
  summaries.setdefault(pair['family'],[]).append(deltas)
check(len(rows)==34,'exact 34 samples / 170 measured processing iterations')
check([json.loads(x) for x in (artifact/'pairs.jsonl').read_text().splitlines()]==report['pairs'],'full append-only pair log equals terminal report')
# Complete path inventory/tree equality and selected causal/method hashes against Git.
sourceVerification=[]
selected=['scripts/perf/probe.sh','rust/processing/examples/perf_probe.rs','rust/processing/examples/perf_probe/measurement.rs','rust/processing/examples/perf_probe/fingerprint.rs','rust-toolchain.toml','Cargo.toml','Cargo.lock','rust/geometry/src/kernel/fixed_int/mul.rs','rust/geometry/src/kernel/fixed_int/mod.rs','rust/geometry/src/kernel/fixed_int/magnitude_mul_tests.rs','scripts/perf/native-hosted-cohort.mjs','scripts/perf/native-hosted-process.mjs','scripts/perf/native-hosted-plan.mjs','scripts/perf/sdk-resources.mjs','scripts/perf/native-hosted-prepare.mjs','scripts/perf/native-startup-control.mjs']
for source in provenance['sources']:
 head=source['head'];tree=subprocess.check_output(['git','rev-parse',head+'^{tree}'],cwd=wt,text=True).strip();check(tree==source['tree'],'source '+head+' Git tree matches')
 raw=subprocess.check_output(['git','ls-tree','-r','-z',head],cwd=wt).split(b'\0');entries={row.split(b'\t',1)[1].decode():row.split(b'\t',1)[0].decode().split() for row in raw if row}
 observed={str(pathlib.PurePosixPath(path).relative_to(source['directory'])):h for path,h in source['files'].items()};check(set(observed)==set(entries),'source '+head+' full tracked path inventory matches Git')
 verified=[]
 for path in selected:
  if path not in entries:continue
  data=subprocess.check_output(['git','show',head+':'+path],cwd=wt);check(hashlib.sha256(data).hexdigest()==observed[path],'source '+head+' causal hash '+path);verified.append(path)
 sourceVerification.append({'head':head,'tree':tree,'trackedPaths':len(entries),'selectedVerified':verified,'limit':'Remaining tracked content hashes rely on retained sourceSnapshot/verifySource receipts; no remote filesystem exists for independent final rehash.'})
for arm,b in provenance['builds'].items():
 check(b['status']=='complete' and b['exit']==0 and b['cleanup']['status']=='complete' and not b['cleanup']['remaining'] and all(z['status']=='complete' for z in b['flush']),'build '+arm+' actual success/cleanup')
 check(sha(artifact/pathlib.Path(b['paths']['stderr']).name)==b['hashes'][1] and re.search(r'^\s*Compiling ifc-lite-processing v',(artifact/pathlib.Path(b['paths']['stderr']).name).read_text(),re.M),'build '+arm+' fresh processing compilation raw evidence')
 check(provenance['files'][b['binary']]==b['binarySha256'],'build '+arm+' binary SHA frozen into provenance')
medians={family:{key:statistics.median([x[key] for x in values if x[key] is not None]) for key in ['allTotalsMs','allWallMs','geometryMs','totalMs']} for family,values in summaries.items()}
audit={'status':'QUALIFIED_SCOPED_NATIVE_ATTRIBUTION' if not errors else 'REFUSED_INDEPENDENT_AUDIT','auditedUTC':datetime.datetime.now(datetime.timezone.utc).isoformat(),'run':37149940166,'controller':controller,'revisions':refs,'artifactRoot':str(artifact),'priorCheckerRefusal':{'path':str(root/'independent-audit-v1-refused-checker-status.json'),'reason':'Incorrect audit startup status literal; corrected against actual producer status complete-real-startup-control, no runtime data change.'},'checks':checks,'errors':errors,'summary':{'pairs':len(report['pairs']),'samples':len(rows),'iterations':sum(len(r['result']['allTotalsMs']) for r in rows),'maxObservedCPUPercent':maxCPU,'maxSampledOwnedRssBytes':maxRSS,'cleanupWitnesses':cleanupWitnesses,'familyIdentities':familyIdentities,'pairedDeltaMedianPercent':medians},'sourceVerification':sourceVerification,'rawLogHashes':rawHashes,'retainedFileHashes':{p.name:sha(p) for p in artifact.iterdir() if p.is_file()},'limitations':['Canonical warm/prepared native process_geometry phase attribution, not browser/worker-pool/cold file-to-presentation time.','Ordered FNV covered mesh fields only; excludes text, UV, texture, material definitions and instancing; not full-result byte identity or fidelity.','RSS is sampled owned-tree sum, not physical peak.','A/A controls cover house only.','Available-memory admission/live reserve guards are enforced by frozen producer source but numeric available-memory readings are not retained; floor values cannot be independently reconstructed.','Full tool/registry/linker/machine closure is explicitly not claimed; retained provenance lists closure limitations.','Runtime binaries/tools/fixtures are not all uploaded; actual remote producer freeze assertions cannot be independently re-executed after runner termination.']}
(root/'independent-audit.json').write_text(json.dumps(audit,indent=2)+'\n');print(json.dumps({'status':audit['status'],'checkCount':len(checks),'errors':errors,'summary':audit['summary']},indent=2))
