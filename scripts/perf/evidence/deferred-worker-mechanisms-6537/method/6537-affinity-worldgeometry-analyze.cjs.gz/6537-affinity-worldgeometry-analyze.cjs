const fs = require('node:fs');
const path = require('node:path');
const crypto = require('node:crypto');
const zlib = require('node:zlib');
const { pathToFileURL } = require('node:url');
const ROOT = process.argv[2];
if (!ROOT) throw Error('Provide a preserved complete geometry diagnostic directory');
const canonical = '/home/louistrue/wt/6537-packing-baseline-main940-session6503';
const sha = bytes => crypto.createHash('sha256').update(bytes).digest('hex');
const typed = (text, Type) => {
  const bytes = Buffer.from(text, 'base64');
  return new Type(bytes.buffer.slice(bytes.byteOffset, bytes.byteOffset + bytes.byteLength));
};
const thresholds = [1e-9, 1e-8, 1e-7, 1e-6, 1e-5, 1e-4, 1e-3];
function bounds(mesh) {
  const b = [Infinity, Infinity, Infinity, -Infinity, -Infinity, -Infinity];
  for (let i = 0; i < mesh.positions.length; i += 3) for (let axis = 0; axis < 3; axis++) {
    const v = mesh.positions[i + axis] + mesh.origin[axis];
    if (!Number.isFinite(v)) throw Error('Nonfinite observed world position');
    b[axis] = Math.min(b[axis], v); b[axis + 3] = Math.max(b[axis + 3], v);
  }
  return b;
}
function worldHash(mesh) {
  const bytes = Buffer.alloc(mesh.positions.length * 8);
  for (let i = 0; i < mesh.positions.length; i++) bytes.writeDoubleLE(mesh.positions[i] + mesh.origin[i % 3], i * 8);
  return sha(bytes);
}
function groupKey(mesh) {
  return JSON.stringify({ entity: mesh.expressId, item: mesh.geometryItemId ?? 0,
    class: mesh.geometryClass ?? 0, material: mesh.materialId ?? 0,
    color: mesh.color, metallic: mesh.material?.metallic ?? null, roughness: mesh.material?.roughness ?? null,
    vertices: mesh.positions.length / 3, triangles: mesh.indices.length / 3,
    indexSHA256: sha(new Uint8Array(mesh.indices.buffer, mesh.indices.byteOffset, mesh.indices.byteLength)) });
}
async function load(side, decode, prepare, materialize, stride) {
  const directory = path.join(ROOT, side + '-geometry');
  const index = JSON.parse(fs.readFileSync(path.join(directory, 'index.json')));
  const groups = new Map(); let flat = 0, instances = 0, shards = 0, logicalTriangles = 0;
  const add = mesh => {
    const entry = { ...mesh, origin: mesh.origin ?? [0, 0, 0] };
    entry.bounds = bounds(entry); entry.worldSHA256 = worldHash(entry);
    const key = groupKey(entry), list = groups.get(key) ?? []; list.push(entry); groups.set(key, list);
    logicalTriangles += mesh.indices.length / 3;
  };
  for (const receipt of index.chunks) {
    const bytes = fs.readFileSync(path.join(directory, receipt.file));
    if (bytes.length !== receipt.bytes || sha(bytes) !== receipt.sha256) throw Error('Diagnostic chunk byte mismatch');
    const chunk = JSON.parse(zlib.gunzipSync(bytes));
    if (chunk.offset !== receipt.offset || chunk.next !== receipt.next || chunk.rows.length !== chunk.next - chunk.offset) throw Error('Diagnostic chunk row mismatch');
    for (const row of chunk.rows) {
      if (receipt.kind === 'flat') {
        add({ ...row, positions: typed(row.positions, Float32Array), normals: typed(row.normals, Float32Array), indices: typed(row.indices, Uint32Array) }); flat++;
      } else {
        const decoded = decode(typed(row.bytes, Uint8Array)); shards++;
        for (const template of prepare(decoded)) {
          const occurrences = decoded.instances.filter(instance => instance.templateIndex === template.templateIndex && instance.color[3] >= 0.99);
          if (occurrences.length !== template.instanceCount) throw Error('Canonical prepared occurrence count mismatch');
          const cpu = { modelIndex: 0, positions: template.positions, normals: template.normals, indices: template.indices,
            instanceData: template.instanceBuffer, canonicalAnchors: template.canonicalAnchors, canonicalMatrixTranslations: template.canonicalMatrixTranslations };
          for (let i = 0; i < occurrences.length; i++) {
            const occurrence = occurrences[i];
            const pieces = materialize(occurrence.entityId, [{ templateIndex: 0, byteOffset: i * stride, originalColor: occurrence.color, itemId: occurrence.itemId }], [cpu]);
            if (pieces?.length !== 1) throw Error('Canonical CPU occurrence materialization refused');
            add({ ...pieces[0], geometryClass: 0, materialId: 0, material: { metallic: occurrence.metallic, roughness: occurrence.roughness } }); instances++;
          }
        }
      }
    }
  }
  if (flat !== index.counts.flat || shards !== index.counts.shards) throw Error('Incomplete geometry diagnostic export');
  return { groups, summary: { source: index.source, flat, instances, shards, logicalTriangles, groupCount: groups.size } };
}
function distance(a, b) { return Math.max(...a.bounds.map((v, i) => Math.abs(v - b.bounds[i]))); }
function area(mesh, i) {
  const p = mesh.positions, ids = mesh.indices;
  const a = ids[i] * 3, b = ids[i + 1] * 3, c = ids[i + 2] * 3;
  const ab = [p[b] - p[a], p[b + 1] - p[a + 1], p[b + 2] - p[a + 2]];
  const ac = [p[c] - p[a], p[c + 1] - p[a + 1], p[c + 2] - p[a + 2]];
  return Math.hypot(ab[1] * ac[2] - ab[2] * ac[1], ab[2] * ac[0] - ab[0] * ac[2], ab[0] * ac[1] - ab[1] * ac[0]);
}
(async () => {
  const { decodeInstancedShard } = await import(pathToFileURL(canonical + '/packages/geometry/dist/packed-instanced-decoder.js'));
  const { prepareInstancedRender, INSTANCE_STRIDE_BYTES } = await import(pathToFileURL(canonical + '/packages/renderer/dist/instanced-render.js'));
  const { materializeInstances } = await import(pathToFileURL(canonical + '/packages/renderer/dist/scene-instance-materialization.js'));
  const base = await load('base', decodeInstancedShard, prepareInstancedRender, materializeInstances, INSTANCE_STRIDE_BYTES);
  const branch = await load('branch', decodeInstancedShard, prepareInstancedRender, materializeInstances, INSTANCE_STRIDE_BYTES);
  let pieces = 0, exactWorldPieces = 0, exactNormalPieces = 0, duplicateGroups = 0, maxPositionDelta = 0, maxNormalDelta = 0, maxBoundsDelta = 0, topologyDegeneracyChanges = 0;
  const positionCounts = thresholds.map(() => 0), normalCounts = thresholds.map(() => 0), largest = [];
  const multiplicityFailures = [];
  for (const [key, left] of base.groups) {
    const right = [...(branch.groups.get(key) ?? [])];
    if (left.length !== right.length) { multiplicityFailures.push({ key, base: left.length, branch: right.length }); continue; }
    if (left.length > 1) duplicateGroups++;
    for (const a of left) {
      // First match exact world coordinates; otherwise retain a deterministic
      // nearest-AABB pairing and disclose that pairing in the result. Bounds
      // alone never count as geometry proof: EVERY vertex/normal is compared.
      let best = right.findIndex(b => a.worldSHA256 === b.worldSHA256);
      if (best < 0) best = right.reduce((chosen, b, i) => distance(a, b) < distance(a, right[chosen]) ? i : chosen, 0);
      const b = right.splice(best, 1)[0]; pieces++;
      exactWorldPieces += Number(a.worldSHA256 === b.worldSHA256);
      exactNormalPieces += Number(Buffer.from(a.normals.buffer, a.normals.byteOffset, a.normals.byteLength).equals(Buffer.from(b.normals.buffer, b.normals.byteOffset, b.normals.byteLength)));
      if (a.normals.length !== b.normals.length) throw Error('Normal shape mismatch');
      let localPosition = 0, localNormal = 0;
      for (let i = 0; i < a.positions.length; i++) {
        const delta = Math.abs((a.positions[i] + a.origin[i % 3]) - (b.positions[i] + b.origin[i % 3]));
        localPosition = Math.max(localPosition, delta);
        for (let t = 0; t < thresholds.length; t++) positionCounts[t] += Number(delta > thresholds[t]);
      }
      for (let i = 0; i < a.normals.length; i++) {
        const delta = Math.abs(a.normals[i] - b.normals[i]); if (!Number.isFinite(delta)) throw Error('Nonfinite observed normal');
        localNormal = Math.max(localNormal, delta);
        for (let t = 0; t < thresholds.length; t++) normalCounts[t] += Number(delta > thresholds[t]);
      }
      for (let i = 0; i < a.indices.length; i += 3) topologyDegeneracyChanges += Number((area(a, i) > 0) !== (area(b, i) > 0));
      maxPositionDelta = Math.max(maxPositionDelta, localPosition); maxNormalDelta = Math.max(maxNormalDelta, localNormal); maxBoundsDelta = Math.max(maxBoundsDelta, distance(a, b));
      if (localPosition || localNormal) largest.push({ entity: a.expressId, item: a.geometryItemId ?? 0, positionDelta: localPosition, normalDelta: localNormal });
    }
  }
  for (const [key, right] of branch.groups) if (!base.groups.has(key)) multiplicityFailures.push({ key, base: 0, branch: right.length });
  largest.sort((a, b) => b.positionDelta - a.positionDelta || b.normalDelta - a.normalDelta);
  const report = { base: base.summary, branch: branch.summary, pieces, exactWorldPieces, exactNormalPieces, duplicateGroups, maxPositionDelta, maxNormalDelta, maxBoundsDelta,
    topologyDegeneracyChanges, multiplicityFailures, thresholds, positionScalarCountsAboveThreshold: positionCounts, normalScalarCountsAboveThreshold: normalCounts, largest: largest.slice(0, 30),
    scope: 'Complete retained canonical flat + IFNS CPU-materialized vertices/normals/topology/materials. Exact full-index SHA256 and occurrence multiplicity. Thresholds are DESCRIPTIVE discrepancy buckets, not a tolerance-based PASS. Duplicate groups paired by exact world digest then nearest AABB; every vertex/normal checked. Native GPU picking/pixels/cache/federation and end-to-end performance remain separate requirements.' };
  fs.writeFileSync(path.join(ROOT, 'worldgeometry-derived.json'), JSON.stringify(report, null, 2) + '\n');
  console.log(JSON.stringify({ ...report, largest: report.largest.slice(0, 3), multiplicityFailures: report.multiplicityFailures.slice(0, 3) }));
  if (multiplicityFailures.length || topologyDegeneracyChanges) process.exitCode = 1;
})().catch(error => { console.error(error); process.exitCode = 1; });
