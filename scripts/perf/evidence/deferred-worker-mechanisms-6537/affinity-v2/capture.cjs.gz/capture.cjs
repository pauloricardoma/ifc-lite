const fs = require('node:fs');
const cp = require('node:child_process');
const { chromium } = require('/home/louistrue/wt/6537-affinity-admission-main940-session6503/node_modules/@playwright/test');
const ROOT = '/tmp/6232-takeover/6537-affinity-main940-native-controls-v2';
fs.mkdirSync(ROOT, { recursive: true });
const names = { ac20: 'AC20-FZK-Haus.ifc', holter: 'ISSUE_053_20181220Holter_Tower_10.ifc', os1: 'O-S1-BWK-BIM architectural - BIM bouwkundig.ifc', snowdon: '01_Snowdon_Towers_Sample_Structural(1).ifc' };
const source = {base:'9400cb6c952ba200e165c1dadbd95f9d28fca927', branch:'982da209b3a07da924d4c0af566aebbe7fe749e9'};
const schedule = [];
for (let i=0;i<5;i++) for (const side of i%2 ? ['A2','A1'] : ['A1','A2']) schedule.push({control:'AA',fixture:'ac20',pair:i,side,build:'base'});
for (const fixture of ['ac20','holter','os1','snowdon']) for (let i=0;i<5;i++) for (const build of i%2 ? ['branch','base'] : ['base','branch']) schedule.push({control:'AB',fixture,pair:i,side:build,build});
function hostPreflight(){const result=cp.spawnSync('python3',['/tmp/6232-takeover/native-perf-host-preflight-session6503.py'],{encoding:'utf8'});if(result.error)throw result.error;return {exitCode:result.status,...JSON.parse(result.stdout)};}
function bounded(p, label, ms=15000) { let timer; return Promise.race([p,new Promise((_,reject)=>{timer=setTimeout(()=>reject(new Error(label+' timed out')),ms)})]).finally(()=>clearTimeout(timer)); }
async function sample(item, index) {
 const row = {...item,index,capturedAt:new Date().toISOString(),source:source[item.build],scope:'Canonical viewer first-file full renderer-finalization and observed GPU frame on native Windows Chrome/NVIDIA; fresh browser context/tab, no full-lifetime/cache verdict.',hostBefore:cp.execFileSync('cat',['/proc/loadavg'],{encoding:'utf8'}).trim()};
 let browser, context;
 try {
  row.hostPreflightBefore=hostPreflight();
  if(row.hostPreflightBefore.exitCode!==0)throw Error('Active local graph at sample preflight; no model loaded');
  browser = await chromium.connectOverCDP('http://127.0.0.1:9343');
  row.chrome = browser.version();
  row.expectedRuntimeSha256='039415545e2448ce8b1e40b14306524ee60cff29dabd97448080ac0d9e170610';
  context=await bounded(browser.newContext({viewport:{width:1280,height:800}}),'newContext');
  const page=await bounded(context.newPage(),'newPage');
  const runtimeResponses=[];
  // Inside load: retain tiny observed URL/status records only; no body reads/copies/hashes.
  page.on('response',response=>{if(response.url().includes('/assets/ifc-lite_bg-')&&response.url().endsWith('.wasm'))runtimeResponses.push({url:response.url(),status:response.status()});});
  row.runtimeCaptureScope='Observed worker request URL/status recorded inside load; after fullReady/timing/heap/geometry snapshot, unique same immutable no-store static WASM URLs are fetched and hashed outside timing as served-resource byte witnesses, not original worker-response body hashes';
  row.heapScope='rAF-sampled Chrome-reported usedJSHeapSize maximum from input to first fully-ready observed frame; no claim of unsampled allocation peak';
  await page.goto('http://localhost:'+(item.build==='base'?5342:5344)+'/',{timeout:30000});
  await page.waitForFunction(()=>globalThis.__ifc_lite_viewer_store__&&[...document.querySelectorAll('input[type=file]')].some(e=>e.accept.startsWith('.ifc')),null,{timeout:30000});
  await page.bringToFront();
  row.environment=await page.evaluate(async()=>{const a=await navigator.gpu.requestAdapter(); return {hardwareConcurrency:navigator.hardwareConcurrency,crossOriginIsolated,visibility:document.visibilityState,focused:document.hasFocus(),adapter:a?{vendor:a.info.vendor,architecture:a.info.architecture,fallback:a.info.isFallbackAdapter}:null};});
  row.fixtureInfo=await page.evaluate(async ({fixture,name})=>{
   const bytes=await(await fetch('/__fixture/'+fixture)).arrayBuffer();
   const sha=[...new Uint8Array(await crypto.subtle.digest('SHA-256',bytes))].map(b=>b.toString(16).padStart(2,'0')).join('');
   const dt=new DataTransfer(); dt.items.add(new File([bytes],name));
   const input=[...document.querySelectorAll('input[type=file]')].find(e=>e.accept.startsWith('.ifc'));
   __perfCapture.startLoad=performance.now();
   __perfCapture.frames=[]; __perfCapture.heapPeak=0;
   const frame=now=>{__perfCapture.frames.push(now);__perfCapture.heapPeak=Math.max(__perfCapture.heapPeak,performance.memory?.usedJSHeapSize??0);
    const state=globalThis.__ifc_lite_viewer_store__?.getState();
    const final=__perfCapture.logs.find(r=>r.text.startsWith('[GeomSync] finalize complete'));
    if(final && state && !state.loading && !state.geometryStreamingActive && __perfCapture.logs.some(r=>r.text.startsWith('[useIfc] Stream complete')) && __perfCapture.logs.some(r=>r.text.startsWith('[useIfc] Data model parsing complete')) && !__perfCapture.firstReadyFrame){__perfCapture.firstReadyFrame=performance.now(); __perfCapture.readyRafTimestamp=now; __perfCapture.stopFrames=true;}
    if(!__perfCapture.stopFrames)__perfCapture.frameRequest=requestAnimationFrame(frame);};
   __perfCapture.frameRequest=requestAnimationFrame(frame);
   __perfCapture.visibility=[];
   addEventListener('visibilitychange',()=>__perfCapture.visibility.push({t:performance.now(),state:document.visibilityState}));
   input.files=dt.files; input.dispatchEvent(new Event('change',{bubbles:true}));
   return {bytes:bytes.byteLength,sha256:sha,name};
  },{fixture:item.fixture,name:names[item.fixture]});
  await page.waitForFunction(()=>__perfCapture.firstReadyFrame&&globalThis.__ifc_lite_render_stats__?.().gpu.total>0,null,{timeout:90000});
  row.afterCadence=await page.evaluate(()=>new Promise(resolve=>{const samples=[];const frame=t=>{samples.push(t);if(samples.length===31){const dt=samples.slice(1).map((x,i)=>x-samples[i]).sort((a,b)=>a-b);resolve({medianMs:dt[15],maxMs:dt.at(-1),visibility:document.visibilityState,focused:document.hasFocus()});}else requestAnimationFrame(frame);};requestAnimationFrame(frame);}));
  const color=await bounded(page.evaluate(()=>globalThis.__ifc_lite_capture_color_frame__?.()),'GPU color frame',15000);
  if(!color?.startsWith('data:image/png;base64,'))throw Error('No actual GPU color frame readback');
  const png=Buffer.from(color.split(',')[1],'base64');
  row.colorFrame={bytes:png.length,sha256:require('node:crypto').createHash('sha256').update(png).digest('hex')};
  const imageName=String(index).padStart(2,'0')+'-'+item.control+'-'+item.fixture+'-'+item.side+'.png';
  fs.writeFileSync(ROOT+'/'+imageName,png);row.colorFrame.file=imageName;

  row.observation=await page.evaluate(()=>{
   const state=__ifc_lite_viewer_store__.getState();
   let hash=2166136261;
   const add=arr=>{const bytes=arr instanceof Uint8Array?arr:new Uint8Array(arr.buffer,arr.byteOffset,arr.byteLength);for(let i=0;i<bytes.length;i++)hash=Math.imul(hash^bytes[i],16777619);};
   const meshes=[...(state.geometryResult?.meshes??[])].sort((a,b)=>a.expressId-b.expressId||Number(a.geometryItemId??0)-Number(b.geometryItemId??0));
   let vertices=0,triangles=0;
   for(const m of meshes){for(const key of ['positions','normals','indices'])if(m[key])add(m[key]);vertices+=(m.positions?.length??0)/3;triangles+=(m.indices?.length??0)/3;add(new TextEncoder().encode(JSON.stringify({expressId:m.expressId,geometryItemId:m.geometryItemId,color:m.color,origin:m.origin,localToWorld:m.localToWorld,geometryHash:m.geometryHash,appearanceSource:m.appearanceSource},(_,v)=>typeof v==='bigint'?v.toString():v)));}
   const stream=__perfCapture.logs.find(r=>r.text.startsWith('[useIfc] Stream complete'));
   const metadata=__perfCapture.logs.find(r=>r.text.startsWith('[useIfc] Data model parsing complete'));
   const start=__perfCapture.logs.find(r=>r.text.startsWith('[stream] processParallel start'));
   const afterInput=r=>r.t-__perfCapture.startLoad;
   __perfCapture.stopFrames=true; if(__perfCapture.frameRequest)cancelAnimationFrame(__perfCapture.frameRequest); const final=__perfCapture.logs.find(r=>r.text.startsWith('[GeomSync] finalize complete'));
   return {fullReadyAfterInputMs:__perfCapture.firstReadyFrame-__perfCapture.startLoad,readyRafTimestamp:__perfCapture.readyRafTimestamp,finalizeAfterInputMs:afterInput(final),frames:__perfCapture.frames,heapPeak:__perfCapture.heapPeak,streamAfterInputMs:afterInput(stream),metadataAfterInputMs:afterInput(metadata),workerStreamWallMs:stream.t-start.t,geometry:{meshes:meshes.length,retainedVertices:vertices,retainedTriangles:triangles,totalVertices:state.geometryResult?.totalVertices,totalTriangles:state.geometryResult?.totalTriangles,fullPositionsNormalsIndicesAppearanceFNV32:(hash>>>0).toString(16)},models:[...state.models.values()].map(m=>({name:m.name,loadState:m.loadState,geometryLoadState:m.geometryLoadState,metadataLoadState:m.metadataLoadState})),loading:state.loading,streaming:state.geometryStreamingActive,logs:__perfCapture.logs,errors:__perfCapture.errors,visibilityChanges:__perfCapture.visibility,observedAt:performance.now(),renderStats:globalThis.__ifc_lite_render_stats__?.()};
  });
  // Timing/heap/geometry were snapshotted above; completed workers may have
  // discarded their response bodies. Fetch the same immutable URL separately.
  const observedRuntimeURLs=[...new Map(runtimeResponses.map(response=>[response.url,response])).values()];
  row.observedRuntimeResponses=runtimeResponses.splice(0);
  row.servedRuntimes=[];
  for(const observed of observedRuntimeURLs){
    const witness=await fetch(observed.url,{cache:'no-store'});
    row.servedRuntimes.push({url:observed.url,status:witness.status,originalObservedStatus:observed.status,sha256:require('node:crypto').createHash('sha256').update(Buffer.from(await witness.arrayBuffer())).digest('hex'),scope:'post-timing immutable served-resource byte witness; not original worker response body'});
  }
  row.servedRuntime=row.servedRuntimes[0];
  row.workerStreamValid = row.servedRuntime?.status===200 && row.servedRuntimes.length>0 && row.servedRuntimes.every(runtime=>runtime.sha256===row.expectedRuntimeSha256&&runtime.status===200&&runtime.originalObservedStatus===200) && row.environment.crossOriginIsolated && row.environment.visibility==='visible' && row.observation.visibilityChanges.length===0 && row.observation.geometry.retainedVertices>0 && row.observation.geometry.retainedTriangles>0;
  row.renderReady=row.workerStreamValid && row.environment.adapter && !row.environment.adapter.fallback && row.colorFrame.bytes>0 && row.afterCadence.visibility==='visible' && row.afterCadence.focused && row.afterCadence.medianMs<50;
 } catch(e){row.failure={message:e.message,stack:e.stack};row.workerStreamValid=false;}
 finally { if(context) try{await bounded(context.close(),'ownedContextClose')}catch(e){row.contextTeardownFailure=e.message;row.workerStreamValid=false;} if(browser) try{await bounded(browser.close(),'browserClose')}catch(e){row.teardownFailure=e.message;row.workerStreamValid=false;} }
 row.hostPreflightAfter=hostPreflight();
 if(row.hostPreflightAfter.exitCode!==0){row.hostContamination='Active local graph at sample end; retained sample is unqualified';row.workerStreamValid=false;row.renderReady=false;}
 row.hostAfter=cp.execFileSync('cat',['/proc/loadavg'],{encoding:'utf8'}).trim();
 fs.writeFileSync(ROOT+'/'+String(index).padStart(2,'0')+'-'+item.control+'-'+item.fixture+'-'+item.side+'.json',JSON.stringify(row,null,2)+'\n');
 fs.appendFileSync(ROOT+'/runs.jsonl',JSON.stringify(row)+'\n');
 console.log(JSON.stringify({index,control:item.control,fixture:item.fixture,pair:item.pair,side:item.side,workerStreamValid:row.workerStreamValid,renderReady:row.renderReady,fullReadyMs:row.observation?.fullReadyAfterInputMs,streamMs:row.observation?.streamAfterInputMs,workerStreamWallMs:row.observation?.workerStreamWallMs,metadataMs:row.observation?.metadataAfterInputMs,geometry:row.observation?.geometry,failure:row.failure?.message,teardownFailure:row.teardownFailure}));
 return row;
}
(async()=>{if(fs.existsSync(ROOT+'/runs.jsonl'))throw Error('Existing immutable output; select a new output directory before repeating');fs.writeFileSync(ROOT+'/schedule.json',JSON.stringify({schedule,source,scope:'Native Windows Chrome/NVIDIA full-render-finalization control; five interleaved matched pairs; fresh browser context and tab per sample; no full-lifetime/cache claim'},null,2)+'\n');for(let i=0;i<schedule.length;i++){const row=await sample(schedule[i],i);if(!row.workerStreamValid||!row.renderReady){console.error('Stopping after preserved invalid sample; no substitution');process.exitCode=1;break;}}})().catch(e=>{console.error(e);process.exitCode=1});
