// This Source Code Form is subject to the terms of the Mozilla Public
// License, v. 2.0. If a copy of the MPL was not distributed with this
// file, You can obtain one at https://mozilla.org/MPL/2.0/.

//! Unshipped #6537 source-packet feasibility diagnostic. Counts the complete
//! syntactic forward-reference closure of actual dispatched geometry roots.
//! This is NOT a complete observed access union: inverse/type scans, prepass,
//! recovery and header reads remain separate requirements. No packet is emitted.

use ifc_lite_core::{parse_entity, ColumnarEntityIndex, EntityScanner};
use ifc_lite_core::parser::Token;
use rustc_hash::{FxHashMap, FxHashSet};
use serde::Deserialize;
use sha2::{Digest, Sha256};
use std::{error::Error, time::Instant};

#[derive(Deserialize)]
#[serde(rename_all = "camelCase")]
struct Roots {
    source_bytes: usize,
    source_sha256: String,
    workers: Vec<WorkerRoots>,
}

#[derive(Deserialize)]
#[serde(rename_all = "camelCase")]
struct WorkerRoots {
    label: String,
    root_ids: Vec<u32>,
}

struct Record {
    start: usize,
    end: usize,
    references: Vec<u32>,
}

fn references(tokens: &[Token<'_>]) -> Vec<u32> {
    let mut pending: Vec<_> = tokens.iter().collect();
    let mut ids = Vec::new();
    while let Some(token) = pending.pop() {
        match token {
            Token::EntityRef(id) => ids.push(*id),
            Token::List(items) | Token::TypedValue(_, items) => pending.extend(items),
            _ => {}
        }
    }
    ids.sort_unstable();
    ids.dedup();
    ids
}

fn main() -> Result<(), Box<dyn Error>> {
    let args: Vec<_> = std::env::args().skip(1).collect();
    if args.len() != 2 { return Err("Provide real IFC path and preserved worker-root manifest".into()); }
    let data = std::fs::read(&args[0])?;
    let roots: Roots = serde_json::from_slice(&std::fs::read(&args[1])?)?;
    if data.len() != roots.source_bytes || format!("{:x}", Sha256::digest(&data)) != roots.source_sha256 {
        return Err("Source does not match actual dispatched-root fixture receipt".into());
    }
    if data.len() > u32::MAX as usize || roots.workers.len() > 32 {
        return Err("Diagnostic supports u32 source offsets and at most 32 root sets".into());
    }
    let begin = Instant::now();
    let mut scanner = EntityScanner::new(&data);
    let (mut ids, mut starts, mut lengths) = (Vec::new(), Vec::new(), Vec::new());
    while let Some((id, _, start, end)) = scanner.next_entity() {
        ids.push(id); starts.push(start as u32); lengths.push((end - start) as u32);
    }
    let oversized = scanner.skipped_oversized_ids();
    let malformed = scanner.malformed_record_starts().len();
    ifc_lite_core::report_scan_diagnostics(oversized, malformed > 0);
    if oversized != 0 || malformed != 0 {
        return Err(format!("Diagnostic refuses incomplete index: {oversized} oversized, {malformed} malformed records").into());
    }
    let index = ColumnarEntityIndex::from_owned_columns(ids, starts, lengths)?;
    let scan_ms = begin.elapsed().as_secs_f64() * 1000.0;
    let mut records: FxHashMap<u32, Record> = FxHashMap::default();
    let mut owners: FxHashMap<u32, u32> = FxHashMap::default();
    let mut reports = Vec::new();
    let walk = Instant::now();
    for (worker, root) in roots.workers.iter().enumerate() {
        // Closure is a pure id-set: global visitation is correct, iterative
        // traversal consumes no recursive stack, and edge work is bounded.
        let mut visited = FxHashSet::default();
        let mut pending = root.root_ids.clone();
        let (mut bytes, mut edges, mut maximum_end) = (0usize, 0usize, 0usize);
        while let Some(id) = pending.pop() {
            if !visited.insert(id) { continue; }
            if visited.len() > index.len() { return Err("Diagnostic entity work budget exceeded".into()); }
            if !records.contains_key(&id) {
                let (start, end) = index.lookup(id).ok_or_else(|| format!("Diagnostic unresolved forward reference #{id}"))?;
                let (parsed_id, _, tokens) = parse_entity(&data[start..end])?;
                if parsed_id != id { return Err(format!("Index/parsed identity mismatch at #{id}").into()); }
                records.insert(id, Record { start, end, references: references(&tokens) });
            }
            let record = &records[&id];
            bytes += record.end - record.start;
            maximum_end = maximum_end.max(record.end);
            edges = edges.checked_add(record.references.len()).ok_or("Diagnostic edge budget overflow")?;
            // Each distinct canonical record is parsed once per source and
            // visited once per root set. Source length is a conservative cap
            // on the number of syntactically encoded distinct reference edges.
            if edges > data.len() { return Err("Diagnostic reference edge work budget exceeded".into()); }
            pending.extend(record.references.iter().filter(|id| !visited.contains(id)));
            *owners.entry(id).or_default() |= 1u32 << worker;
        }
        reports.push(serde_json::json!({ "label": root.label, "rootIds": root.root_ids.len(),
            "forwardClosureRecords": visited.len(), "forwardClosureRecordBytes": bytes,
            "forwardReferenceEdges": edges, "maximumOriginalEnd": maximum_end,
            "emptyRootSetIsNotAProcessingWorker": root.root_ids.is_empty() }));
    }
    let mut union_bytes = 0usize;
    let mut repeated_bytes = 0usize;
    let mut by_multiplicity = std::collections::BTreeMap::<u32, usize>::new();
    for (id, mask) in &owners {
        let record = &records[id];
        let bytes = record.end - record.start;
        let count = mask.count_ones();
        union_bytes += bytes;
        repeated_bytes += bytes * count as usize;
        *by_multiplicity.entry(count).or_default() += bytes;
    }
    println!("{}", serde_json::to_string_pretty(&serde_json::json!({
        "sourceBytes": data.len(), "sourceSha256": roots.source_sha256,
        "indexedRecords": index.len(), "canonicalScanAndIndexMs": scan_ms,
        "diagnosticClosureWalkMs": walk.elapsed().as_secs_f64() * 1000.0,
        "workers": reports, "allRootSetsUnionRecords": owners.len(),
        "allRootSetsUnionRecordBytes": union_bytes, "summedRootSetRecordBytes": repeated_bytes,
        "recordBytesByRootSetMultiplicity": by_multiplicity,
        "scope": "Complete syntactic FORWARD closure of actual dispatched roots using canonical scanner/parser/index. Not an observed runtime access union or complete dependency closure: inverse/type scans, setup, cached contexts, recovery and header reads excluded. All referenced records and their original offsets retained in accounting, not remapped. Extra parsing/caches and native timing are diagnostic only; no safe packet, WASM memory saving or end-to-end speed claim."
    }))?);
    Ok(())
}
