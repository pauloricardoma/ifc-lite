import hashlib,json,pathlib,subprocess,sys
out=pathlib.Path(__file__).parent
role=sys.argv[1]
assert role in ('instrumented','ordinary')
old=pathlib.Path('/tmp/6232-takeover/6537-ring-work-public-diagnostic-v2-output-guard')
base=pathlib.Path('/home/louistrue/wt/6537-initial-reserve-base-baa-session6503/tests/models/ara3d')
fixtures=[('994',pathlib.Path('/tmp/6516-ring-work-counter-diagnostic-public-v1/994--slab--segfault--augmented.ifc')),('house',base/'AC20-FZK-Haus.ifc'),('csg',base/'ISSUE_129_N1540_17_EXE_MOD_448200_02_09_11SMC_IGC_V17.ifc'),('holter',base/'ISSUE_053_20181220Holter_Tower_10.ifc')]
def sha(path):
 h=hashlib.sha256()
 with path.open('rb') as f:
  for block in iter(lambda:f.read(1024*1024),b''):h.update(block)
 return h.hexdigest()
def equal(a,b):
 with a.open('rb') as x,b.open('rb') as y:
  while True:
   first=x.read(1024*1024);second=y.read(1024*1024)
   if first!=second:return False
   if not first:return True
receipt=json.loads((out/(role+'-build-receipt-v3.json')).read_text())
assert sha(out/(role+'-native'))==receipt['binarySha256']
rows=[]
for name,fixture in fixtures:
 expected=json.loads((old/(name+'-'+role+'.json')).read_text())
 input_sha=sha(fixture);assert input_sha==expected['inputSha256']
 prefix=out/(name+'-'+role)
 with prefix.with_suffix('.json').open('w') as stdout,prefix.with_suffix('.stderr').open('w') as stderr:
  subprocess.run([str(out/(role+'-native')),str(fixture),str(prefix.with_suffix('.capture.json'))],stdout=stdout,stderr=stderr,timeout=60,check=True)
 report=json.loads(prefix.with_suffix('.json').read_text())
 assert report['inputSha256']==input_sha==sha(fixture)
 assert report['instrumented']==(role=='instrumented')
 assert report==expected
 assert report['captureSha256']==sha(prefix.with_suffix('.capture.json'))
 assert equal(prefix.with_suffix('.capture.json'),old/(name+'-'+role+'.capture.json'))
 assert equal(prefix.with_suffix('.json'),old/(name+'-'+role+'.json'))
 rows.append({'name':name,'role':role,'inputSha256':input_sha,'captureSha256':report['captureSha256'],'orderedFnv':report['geometryPayloadFnv1a64'],'reportAndCaptureBytesEqualToV2':True})
 print(json.dumps(rows[-1]),flush=True)
assert sha(out/(role+'-native'))==receipt['binarySha256']
root=pathlib.Path('/home/louistrue/wt/6516-ring-work-counters-session6503')
assert all(sha(root/p)==v for p,v in receipt['sourceFiles'].items())
(out/(role+'-comparison-v3.json')).write_text(json.dumps({'scope':'Correctness and output identity only; no timing or memory verdict','sourceInputsUnchanged':True,'binaryUnchanged':True,'rows':rows},indent=2)+'\n')
