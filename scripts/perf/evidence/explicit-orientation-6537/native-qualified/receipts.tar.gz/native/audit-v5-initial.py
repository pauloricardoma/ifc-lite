import json,pathlib,hashlib,re,math,statistics,subprocess,datetime
root=pathlib.Path('/tmp/6232-takeover/6537-native-canonical-summary-hosted-remote-v1');a=root/'artifacts/native-phase-37182263516-1';wt=pathlib.Path('/home/louistrue/wt/6537-native-canonical-stderr-session6503')
read=lambda p:json.loads(p.read_text());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
r=read(a/'report.json');v=read(a/'provenance.json');p=read(a/'protocol.json');run=read(root/'run.json');proposal=read(pathlib.Path('/tmp/6232-takeover/6537-native-canonical-summary-dispatch-prospective-v2/packet.json'))
checks=[];errors=[]
def check(ok,name):
 checks.append({'name':name,'pass':bool(ok)})
 if not ok:errors.append(name)
head='200a7eed8eb3170225a5e7c5d78eb135f1bddf6a';refs={'base':'187a72e3302447fc49f2264111501223238a24a7','candidate':'672f1e09c06ce777507244d2f2c4403d7b38c098'}
check(run['head_sha']==head and run['status']=='completed' and run['conclusion']=='success','actual literal controller terminalSUCCESS')
check(read(root/'ref-terminal.json')['object']['sha']==head,'remote branch terminal fence')
check(r['status']=='complete-native-attribution' and r.get('reason') is None and r['finalFrozenVerification']=='complete','terminal exact cohort qualification')
check(v['status']=='qualified-native-builds-not-timing' and v['finalFrozenVerification']=='complete' and v['revisions']==refs and v['runtimeProtocol']=='native-fd-prebuilt-v1','actual subject and FD source build provenance')
check(p['revisions']==refs and p['schedule']==proposal['schedule'] and len(r['pairs'])==17,'exact declared17pair schedule')
check(p['limits']['initialBytes']==8*1024**3 and p['limits']['liveBytes']==4*1024**3 and p['limits']['rssBytes']==5*1024**3 and p['limits']['drainMs']==3000,'unchanged declared resource thresholds')
log=(root/'complete-job.log').read_text();check(all(re.search(r'# '+key+r' '+str(n)+r'\s*$',log,re.M) for key,n in [('tests',58),('pass',58),('fail',0),('skipped',0)]),'actual required58controls58PASS0FAIL0SKIP')
check('BASE_REF: '+refs['base'] in log and 'CANDIDATE_REF: '+refs['candidate'] in log,'actual job inputs match approved subjects')
s=read(a/'fd-startup-control/control.json');check(s['status']=='qualified-real-FD-startup-only' and s['ownedTempRemoved'] and s['finalFilesVerified']=='complete','required actual FDstartupqualified/cleanup/freeze')
rows=[];families={};diag={};aa=[];deltas={};maxcpu=0;maxrss=0;witnesses=0;procobserved=0
phases=['indexBuildMs','parseMs','entityScanMs','lookupMs','preprocessMs','geometryMs','facetedBrepMs','totalMs']; nums=phases+['fileMb','entities','meshes','vertices','triangles','pointCacheHits','pointCacheMisses','csgFailures','degenerateDropped'];fields=set(nums+['path','allTotalsMs','allWallMs','meshFingerprintsFnv1a64'])
identity=lambda z:{k:z[k] for k in ['entities','meshes','vertices','triangles','csgFailures','degenerateDropped','meshFingerprintsFnv1a64']}
def cpuaudit(q,label):
 global maxcpu
 check(len(q['rows'])==4 and len(q['intervals'])==3 and not q['before']['active'] and not q['after']['active'],label+' actual census/4readings/3intervals')
 for j,(x,y) in enumerate(zip(q['rows'],q['rows'][1:])):
  def ticks(x):
   z=list(map(int,x['raw'].split()[1:]));return sum(z),z[3]+z[4]
  xx,yy=ticks(x),ticks(y);dt=yy[0]-xx[0];di=yy[1]-xx[1];ns=int(y['monotonicNs'])-int(x['monotonicNs']);z=q['intervals'][j];pc=100*(1-di/dt)
  check(xx==(int(x['total']),int(x['idle'])) and yy==(int(y['total']),int(y['idle'])) and dt>0 and 0<=di<=dt and ns>=10**9 and di*10>=dt*9 and z['eligible'] and int(z['elapsedNs'])==ns and int(z['totalTicks'])==dt and int(z['idleTicks'])==di and math.isclose(pc,z['cpuPercent'],abs_tol=1e-10),label+f' interval{j} independently <=10%')
  maxcpu=max(maxcpu,pc)
for i,pair in enumerate(r['pairs']):
 expected=p['schedule'][i];check(pair['index']==i and all(pair[k]==z for k,z in expected.items()) and pair['status']=='complete' and len(pair['runs'])==2,f'pair{i} exact order/complete')
 check(read(a/f'pair-{i}.json')==pair,f'pair{i} full raw receipt equality')
 for side in ['before','after']:cpuaudit(pair[side],f'pair{i}/{side}')
 for j,x in enumerate(pair['runs']):
  rows.append(x);label=f'pair{i}/{j}';arm=expected['order'][j];f=next(q for q in v['fixtures']if q['family']==pair['family']);b=v['builds'][arm];receipt=v['prebuiltReceipts'][arm]
  check(x['arm']==arm and x['status']=='complete' and x['exit']==0 and x['signal'] is None and x['directory']==v['directories'][arm],label+' role/exit/sourcecwd')
  check(x['command']==['bash',str(pathlib.PurePosixPath(v['sources'][0]['directory'])/'scripts/perf/probe.sh'),'--verified-prebuilt',receipt['path'],receipt['sha256'],x['fdIntent']['path'],v['tools']['python'],f['file'],'--iters','5','--json','--fingerprint'],label+' exact canonical FDcommand')
  check(x['observationPolicy']=={'scope':'normal-native-execution','intervalMs':250} and x['prebuilt'] and not x['cargoExceptions'] and not x['versionProbeExceptions'] and not x['permissionFallbacks'],label+' fixed250ms/noCargo/compilerexceptions/fallbacks')
  z=x['result'];stdout=a/pathlib.PurePosixPath(x['paths']['stdout']).name;stderr=a/pathlib.PurePosixPath(x['paths']['stderr']).name;text=stderr.read_text()
  check(x['hashes']==[sha(stdout),sha(stderr)] and read(stdout)==[z],label+' raw stdout/stderr hashes and JSON')
  check(set(z)==fields and z['path']==f['file'] and all(isinstance(z[k],(int,float)) and not isinstance(z[k],bool) and math.isfinite(z[k]) and z[k]>=0 for k in nums),label+' exact nonnegative numeric/schema')
  check(all(len(z[k])==5 and all(isinstance(n,(int,float)) and n>0 and math.isfinite(n)for n in z[k])for k in ['allTotalsMs','allWallMs']) and z['totalMs']==min(z['allTotalsMs']) and len(z['meshFingerprintsFnv1a64'])==5 and len(set(z['meshFingerprintsFnv1a64']))==1 and all(re.fullmatch('[a-f0-9]{16}',h)for h in z['meshFingerprintsFnv1a64']),label+'5iterations/stableFNV/best-total selection')
  families.setdefault(pair['family'],identity(z));check(identity(z)==families[pair['family']],label+' family-wide full count/FNV/diagnostic identity')
  summary=x['summary'];diag.setdefault(pair['family'],summary['diagnostics']);check(summary['status']=='complete-canonical-summary' and summary['diagnostics']==diag[pair['family']] and summary['diagnostics']['csgFailures']==z['csgFailures'] and summary['diagnostics']['degenerateDropped']==z['degenerateDropped'],label+' retained strict summary/family diagnostic identity')
  check(text.startswith('perf_probe: 1 fixture(s), best-of-5\n\n=== '+f['file']+' ===\n') and not re.search(r'Compiling|Checking|warning:|error:|panic|Finished `|Running ',text),label+' actual canonical preamble/no unknown compiler/error lines')
  counts=re.search(r'\| (\d+) entities \| (\d+) meshes \| (\d+) verts \| (\d+) tris \|',text);check(counts and list(map(int,counts.groups()))==[z[k]for k in ['entities','meshes','vertices','triangles']],label+' independently parsed human counts')
  totals=re.search(r'best total (\d+) ms  \(runs: (\[[^\n]*\]) ms\)',text);fnv=re.search(r'ordered mesh FNV-1a64 \(per run\): (\[[^\n]*\])',text);walls=re.search(r'full pipeline wall: (\[[^\n]*\]) ms',text)
  check(totals and int(totals[1])==z['totalMs'] and json.loads(totals[2])==z['allTotalsMs'] and fnv and json.loads(fnv[1])==z['meshFingerprintsFnv1a64'] and walls and json.loads(walls[1])==z['allWallMs'],label+' independently parsed five totals/walls/FNV')
  cleanup=x['cleanup'];witnesses+=cleanup['witnessed'];check(cleanup['status']=='complete' and cleanup['zombies']==0 and not cleanup['remaining'] and all(q['status']=='complete'for q in x['flush']) and x['samples'],label+' owned cleanup/tailflush/samplecensus')
  rss=max(q['bytes']for q in x['samples']);maxrss=max(maxrss,rss);check(rss<=5*1024**3,label+'sampled owned RSSwithin5GiB')
  fd=x['fdIntent'];file=a/pathlib.PurePosixPath(fd['path']).name;intent=read(file);br=read(a/pathlib.PurePosixPath(receipt['path']).name)
  check(sha(file)==fd['sha256'] and fd['validation']['status']=='verified-fd-intent-owned-binding' and intent['status']=='verified-fd-before-exec' and intent['execApi']=='os.execve(numeric-fd)',label+' actual FDintent hash/validator/API')
  check(intent['held']==br['binary'] and intent['held']['sha256']==b['binarySha256'] and intent['argv']==[b['binary'],f['file'],'--iters','5','--json','--fingerprint'] and intent['environment']==br['environment'],label+' held binary/argv/environment binding')
  processExpected={k:x['initialProcessWitness'][k] for k in ['pid','ppid','pgrp','startTime']};check(all(intent['process'][k]==q for k,q in processExpected.items()) and intent['process']['cwd']==x['directory'] and fd['validation']['process']==intent['process'],label+' initial owned PID/start/group/cwd matches held intent')
  for ob in x['nativeExecutableObservations']:
   procobserved+=1;check(ob['executableObserved'] and ob['executable']==b['binary'] and ob['argv']==intent['argv'] and ob['cwd']==x['directory'] and all(ob[k]==q for k,q in processExpected.items()) and ob['executableFileIdentity']=={k:intent['held'][k]for k in ['dev','ino']},label+' optional actual native proc-exe identity')
 if pair['kind']=='AA':
  q={k:100*(statistics.median(pair['runs'][1]['result'][k])/statistics.median(pair['runs'][0]['result'][k])-1)for k in ['allTotalsMs','allWallMs']};aa.append(q);check(all(abs(t)<=10 for t in q.values()),f'pair{i} independently AA<=10%')
 else:
  l=next(x['result']for x in pair['runs']if x['arm']=='base');z=next(x['result']for x in pair['runs']if x['arm']=='candidate');ds={k:100*(z[k]/l[k]-1)if l[k]>0 else None for k in phases};ds.update({k:100*(statistics.median(z[k])/statistics.median(l[k])-1)for k in ['allTotalsMs','allWallMs']});check(all(t is None and pair['deltasPercent'][k]is None or t is not None and math.isclose(t,pair['deltasPercent'][k],abs_tol=1e-10)for k,t in ds.items()),f'pair{i} independently exact paired deltas');deltas.setdefault(pair['family'],[]).append(ds)
check(len(rows)==34 and [json.loads(x)for x in (a/'pairs.jsonl').read_text().splitlines()]==r['pairs'],'exact34processes/170iterations/append-onlypair log')
sourceChecks=[]
for source in v['sources']:
 h=source['head'];raw=subprocess.check_output(['git','ls-tree','-r','-z',h],cwd=wt);entries={q.split(b'\t',1)[1].decode():q.split(b'\t',1)[0].decode().split()for q in raw.split(b'\0')if q};observed={str(pathlib.PurePosixPath(path).relative_to(source['directory'])):value for path,value in source['files'].items()};check(set(entries)==set(observed) and subprocess.check_output(['git','rev-parse',h+'^{tree}'],cwd=wt,text=True).strip()==source['tree'],'full tracked source inventory/tree '+h)
 selected=[q['path']for q in proposal['sourcePins']]if h==head else [q for q in ['scripts/perf/probe.sh','rust/processing/examples/perf_probe.rs','rust/processing/examples/perf_probe/measurement.rs','rust/processing/examples/perf_probe/fingerprint.rs','Cargo.toml','Cargo.lock','rust-toolchain.toml','rust/geometry/src/kernel/exact.rs']if q in entries]
 for path in selected:check(hashlib.sha256(subprocess.check_output(['git','show',h+':'+path],cwd=wt)).hexdigest()==observed[path],'actual controller/method source SHA '+h+':'+path)
 sourceChecks.append({'head':h,'trackedPaths':len(entries),'causalHashesIndependentlyVerified':len(selected),'remainingHashScope':'producer recorded full tracked hashes; terminal remote source files unavailable independently'})
for arm,b in v['builds'].items():
 check(b['status']=='complete' and b['exit']==0 and b['command']==['cargo','build','--profile','profiling','-p','ifc-lite-processing','--example','perf_probe','--locked'] and b['cleanup']['status']=='complete' and not b['cleanup']['remaining'] and all(z['status']=='complete'for z in b['flush']),'fresh serial build '+arm)
 check(b['hashes']==[sha(a/pathlib.PurePosixPath(b['paths'][key]).name)for key in ['stdout','stderr']] and 'Compiling ifc-lite-processing' in (a/pathlib.PurePosixPath(b['paths']['stderr']).name).read_text() and v['files'][b['binary']]==b['binarySha256'],'fresh raw build/output closure '+arm)
 q=v['canonicalQualifications'][arm];check(q['status']=='complete' and q['exit']==0 and q['command']==['bash','scripts/perf/probe.sh',v['fixtures'][0]['file'],'--iters','5','--json','--fingerprint'] and identity(q['result'])==families['house'],'separate literal original-arm canonical compatibility '+arm)
medians={f:{k:(statistics.median([z[k]for z in ds if z[k]is not None]) if any(z[k]is not None for z in ds) else None)for k in phases+['allTotalsMs','allWallMs']}for f,ds in deltas.items()}
result={'status':'QUALIFIED_SCOPED_NATIVE_PHASE_ATTRIBUTION'if not errors else 'REFUSED_INDEPENDENT_AUDIT','run':37182263516,'controller':head,'subjects':refs,'checks':checks,'errors':errors,'pairs':17,'processes':len(rows),'iterations':170,'AA':aa,'familyIdentity':families,'diagnostics':diag,'pairedDeltaMediansPercent':medians,'allPairedDeltasPercent':deltas,'resourceEvidence':{'maxIndependentlyVerifiedCPUPercent':maxcpu,'maxSampledOwnedRssBytes':maxrss,'cleanupWitnesses':witnesses,'actualNativeProcExeObservations':procobserved,'availableMemory':'gate present and source-frozen, raw available-memory numeric readings not archived; cannot reconstruct observed floor','RSSScope':'sampled process-tree sum, not physical peak'},'sourceChecks':sourceChecks,'limitations':['Native warm/prepared canonical phase attribution under explicit compile-once/held-FD protocol, not end-to-end worker pool or browser load.','FNV excludes appearance/text/UV/material/texture/instances; not complete IFC fidelity.','Controller decimal-summary correctness uses actual retained source-frozen validator; independently parsed human integer/list identity only here.','Only HausAA; keep every paired phase/outlier, no statistical universal-win claim.','Tools/native binaries/fixtures absent from uploaded artifacts; original producer closure claims cannot be rerun remotely after machine teardown.','No whole-machine/adversarial in-place-file immunity claim.','Per-sample FD witness hashes persisted in sample receipts; additions to in-memory provenance.files are verified during cohort but not written back to provenance.json.'],'rawManifest':[{'path':str(q.relative_to(root)),'bytes':q.stat().st_size,'sha256':sha(q)}for q in sorted(root.rglob('*'))if q.is_file() and q.name not in ['independent-audit.json']]}
(root/'independent-audit.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({k:result[k]for k in ['status','errors','pairs','processes','AA','pairedDeltaMediansPercent','resourceEvidence']},indent=2))
