#!/usr/bin/env python3
"""Read/hash-only producer schema adapters; no bundle, browser or fixture load."""
import datetime
import hashlib
import json
from pathlib import Path
import subprocess

ROOT = Path(__file__).resolve().parent
BASE = 'baa7d34db1be4bc8bf0b3479df33275da3130fc6'
CAND = '7776e5b2f04b071b6e5aae7f4f5d1a158320f36d'
PINS = {
    'BASE': ('BASE_ENDPOINT_BUNDLE_COMPLETE_NOT_RUNTIME_LEASE', BASE,
             '/tmp/6232-takeover/6537-canonical-pool-endpoint-source-v5-empty-normals/base-bundle-qualification.json',
             '/home/louistrue/wt/6537-initial-reserve-base-baa-session6503',
             '/tmp/6232-takeover/6537-canonical-pool-base-bundle-v5-empty-normals'),
    'CAND777': ('CANDIDATE777_ENDPOINT_BUNDLE_COMPLETE_NOT_RUNTIME_LEASE', CAND,
               '/tmp/6232-takeover/6537-canonical-pool-candidate777-reuse-source-v3/candidate-bundle-qualification.json',
               '/home/louistrue/wt/6537-initial-reserve-main04e-session6503',
               '/tmp/6232-takeover/6537-canonical-pool-candidate777-bundle-v5-empty-normals'),
}


def require(condition, reason):
    if not condition:
        raise RuntimeError(reason)


def digest(path):
    h = hashlib.sha256()
    with Path(path).open('rb') as stream:
        for chunk in iter(lambda: stream.read(4 * 1024 * 1024), b''):
            h.update(chunk)
    return h.hexdigest()


def read(path):
    return json.loads(Path(path).read_text())


def normalize(rows, field):
    out = []
    for row in rows:
        require(set(row) == {'path',field,'sha256'}, 'unknown asset shape')
        require(isinstance(row[field],int) and row[field] >= 0, 'invalid size')
        out.append({'path':row['path'],'size':row[field],'sha256':row['sha256']})
    return out


roles = {}
for role, (status, head, producer_path, source, dist) in PINS.items():
    producer_file = Path(producer_path)
    producer = read(producer_file)
    require(producer['status'] == status and producer['head'] == head, 'status/head/role mismatch')
    require(subprocess.check_output(['git','-C',source,'rev-parse','HEAD']).decode().strip() == head, 'source HEAD changed')
    require(not subprocess.check_output(['git','-C',source,'status','--porcelain','--untracked-files=no']).strip(), 'source dirty')
    if role == 'BASE':
        require(producer['sourceRoot'] == source and producer['dist'] == dist, 'BASE path schema mismatch')
        field = 'size'
        inputs = dict(producer['inputSHA256'])
        adapted = dict(producer)
    else:
        require(producer['exit'] == 0 and producer['postbuildAuditError'] is None and producer['changedFrozenInputs'] == [],
                'candidate producer actual build did not pass')
        reuse = read(producer['rootBuildReuseReceipt'])
        require(reuse['head'] == head and reuse['sourceRoot'] == source and reuse['outputRoot'] == dist, 'candidate reuse paths mismatch')
        require(producer['command'] == ['node', '/tmp/6232-takeover/6537-canonical-pool-endpoint-source-v5-empty-normals/build-endpoint.mjs',source,head,dist],
                'candidate actual build command mismatch')
        require(digest(producer['log']) == producer['logSHA256'], 'actual candidate build log changed')
        require(producer['sourceBuiltWasmSHA256'] == 'e8a1240354b57cc0d6f80fa360d37270a7ecdf537e424f89c91bddda2e22098a', 'candidate WASM mismatch')
        field = 'bytes'
        inputs = dict(producer['frozenInputs'])
        adapted = {'status':status,'head':head,'sourceRoot':source,'dist':dist,'inputSHA256':inputs}
        guard_path = Path('/tmp/6232-takeover/6537-canonical-pool-candidate777-endpoint-build-root-actual-v1.json')
        guard = read(guard_path)
        require(guard['exit'] == guard['childExit'] == 0 and guard['cwd'] == source, 'root actual build guard failed')
        inputs[str(guard_path)] = digest(guard_path)
        adapted['rootActualBuildGuard'] = {'path':str(guard_path),'sha256':digest(guard_path),'exit':guard['exit']}
    for name, expected in inputs.items():
        require(digest(name) == expected, 'producer frozen input changed: '+name)
    assets = normalize(producer['assets'],field)
    actual_paths = sorted(str(p.relative_to(dist)) for p in Path(dist).rglob('*') if p.is_file())
    require(actual_paths == [row['path'] for row in assets], 'asset inventory changed')
    for row in assets:
        p = Path(dist) / row['path']
        require(p.stat().st_size == row['size'] and digest(p) == row['sha256'], 'frozen asset changed')
    require(normalize(producer['geometryWorkers'],field) == [row for row in assets if 'geometry.worker' in row['path'] and row['path'].endswith('.js')],
            'worker inventory mismatch')
    require(normalize(producer['wasmAssets'],field) == [row for row in assets if row['path'].endswith('.wasm')], 'WASM inventory mismatch')
    inputs[str(producer_file)] = digest(producer_file)
    adapted.update(role=role,adapterKind='ROOT_PRODUCER_SCHEMA_ADAPTER_NOT_RUNTIME_LEASE',
                   producer={'path':str(producer_file),'sha256':digest(producer_file),'status':status,'head':head,
                             'originalSizeField':field,'normalizedSizeField':'size'},
                   assets=assets,wasmAssets=normalize(producer['wasmAssets'],field),geometryWorkers=normalize(producer['geometryWorkers'],field),
                   inputSHA256=inputs)
    if role == 'BASE':
        require(adapted['assets'] == producer['assets'] and adapted['geometryWorkers'] == producer['geometryWorkers'], 'BASE shape changed')
        require(all(adapted['inputSHA256'][k] == v for k,v in producer['inputSHA256'].items()), 'BASE original input map changed')
    path = ROOT / f'{role.lower()}-root-adapter-qualification.json'
    require(not path.exists(), 'preserve existing adapter receipt')
    path.write_text(json.dumps(adapted,indent=2)+'\n')
    roles[role] = {'status':status,'head':head,'qualificationPath':str(path),'qualificationSHA256':digest(path),
                   'producerPath':producer_path,'producerSHA256':digest(producer_file),'producerSizeField':field,
                   'normalizedSizeField':'size','sourceRoot':source,'dist':dist,'frozenInputsVerified':len(inputs),'assetsVerified':len(assets)}

old = ROOT.parent / '6537-canonical-pool-admission-source-v11-canonical-semantic-class'
proposal = read(old/'runtime-source-freeze-proposal.json')
modules = ['runner.mjs','contracts.ts','vendor/interleaved-assets.mjs','vendor/interleaved-cleanup.mjs','vendor/interleaved-server.mjs','semantic-warnings.mjs']
for name in modules[1:]:
    require((ROOT/name).read_bytes() == (old/name).read_bytes(), 'inspection policy module changed: '+name)
proposal.pop('bundleQualificationPath')
proposal.pop('bundleQualificationSha256')
proposal.update(status='SOURCE_ONLY_TWO_ROLE_ROOT_REVIEW_PENDING_NO_RUNTIME_LEASE',
                roles=roles,leaseSubjectField='subjectHead',
                runtimeSourceSHA256={str(ROOT/name):digest(ROOT/name) for name in modules},
                runtime='Only node--check syntax, producer/schema and hash verification ran. No build/test/browser/native/model load. Select exactly one explicit role per future lease; fixed four-fixture untimed inspection only, no A/B timing verdict.',
                adapterScope='Original producer status/head/hash retained; candidate bytes→size is explicit schema normalization only. BASE required original schema/assets/input entries verified unchanged. Runner verifies original producer hash/status/head and frozen inputs pre/post.',
                preservedPreviousPacket=str(old),capturedUTC=datetime.datetime.now(datetime.timezone.utc).isoformat())
(ROOT/'runtime-source-freeze-proposal.json').write_text(json.dumps(proposal,indent=2)+'\n')
print(json.dumps({'roles':roles,'runtimeModules':len(modules)},indent=2))
