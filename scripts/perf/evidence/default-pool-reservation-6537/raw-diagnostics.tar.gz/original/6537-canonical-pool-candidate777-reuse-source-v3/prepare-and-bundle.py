#!/usr/bin/env python3
"""SOURCE-ONLY preparation by default. --build needs a future root runtime allocation."""
import argparse
import datetime
import gzip
import hashlib
import json
import sys
from pathlib import Path
import subprocess

ROOT = Path('/home/louistrue/wt/6537-initial-reserve-main04e-session6503')
BASE = Path('/home/louistrue/wt/6537-initial-reserve-base-baa-session6503')
SCRATCH = Path(__file__).resolve().parent
SHARED = Path('/tmp/6232-takeover/6537-canonical-pool-endpoint-source-v5-empty-normals')
RECORDS = Path('/tmp/6232-takeover')
HEAD = '7776e5b2f04b071b6e5aae7f4f5d1a158320f36d'
BUILT = '9f130aeae021443daabb01dd9872cc23a351beca'
BASEHEAD = 'baa7d34db1be4bc8bf0b3479df33275da3130fc6'
OUTPUT = Path('/tmp/6232-takeover/6537-canonical-pool-candidate777-bundle-v5-empty-normals')
PACKAGES = ('geometry', 'data', 'encoding', 'wasm-lifecycle')
ENDPOINT = ('contracts.ts', 'retention.ts', 'identity.ts', 'identity.test.ts',
            'consumer.ts', 'entry.ts', 'index.html', 'vite-config.mts', 'build-endpoint.mjs')
WASM = 'e8a1240354b57cc0d6f80fa360d37270a7ecdf537e424f89c91bddda2e22098a'


def require(condition, reason):
    if not condition:
        raise RuntimeError(reason)


def digest(path):
    h = hashlib.sha256()
    with Path(path).open('rb') as stream:
        for block in iter(lambda: stream.read(4 * 1024 * 1024), b''):
            h.update(block)
    return h.hexdigest()


def git(root, *args):
    return subprocess.check_output(['git', '-C', str(root), *args])


def load(path):
    return json.loads(Path(path).read_text())


def pin_source():
    for root, head in [(ROOT, HEAD), (BASE, BASEHEAD)]:
        require(git(root, 'rev-parse', 'HEAD').decode().strip() == head, 'HEAD changed')
        require(not git(root, 'status', '--porcelain', '--untracked-files=no').strip(), 'tracked source dirty')


# Resolution only: package exports are never imported or executed here.
RESOLVER = r'''
const fs = require('node:fs'), path = require('node:path');
const {createRequire} = require('node:module');
const root = process.argv[1];
const seeds = ['vite','vite-plugin-wasm','vite-plugin-top-level-await','typescript','tsx','@tauri-apps/api'];
const entries = [], absentOptional = [], queue = seeds.map(name => ({name, from:path.join(root,name==='@tauri-apps/api'?'packages/geometry/package.json':'apps/viewer/package.json'), optional:false}));
const seen = new Set();
while (queue.length) {
 const job = queue.shift(), req = createRequire(job.from);
 let directory;
 try {
  for (const search of req.resolve.paths(job.name) ?? []) {
   const candidate = path.join(search,job.name,'package.json');
   if (fs.existsSync(candidate)) {directory=fs.realpathSync(path.dirname(candidate)); break;}
  }
  if (!directory) throw new Error('installed package not found: '+job.name+' from '+job.from);
 } catch (error) {
  if (!job.optional) throw error;
  absentOptional.push({name:job.name,from:job.from,reason:String(error)}); continue;
 }
 if (seen.has(directory)) continue;
 seen.add(directory);
 const manifestPath = path.join(directory,'package.json');
 const manifest = JSON.parse(fs.readFileSync(manifestPath,'utf8'));
 entries.push({name:manifest.name,version:manifest.version,directory,manifestPath});
 const optional = manifest.optionalDependencies ?? {};
 for (const name of new Set([...Object.keys(manifest.dependencies ?? {}),...Object.keys(optional)])) {
  queue.push({name,from:manifestPath,optional:Object.hasOwn(optional,name)});
 }
}
process.stdout.write(JSON.stringify({entries,absentOptional}));
'''


def tooling(root):
    result = json.loads(subprocess.check_output(['node', '-e', RESOLVER, str(root)]))
    frozen, normalized = {}, {}
    for row in result['entries']:
        directory = Path(row['directory'])
        label = directory.parent.parent.name + '/' + row['name'] + '@' + row['version']
        for path in sorted(directory.rglob('*')):
            if path.is_file() and 'node_modules' not in path.relative_to(directory).parts:
                frozen[str(path)] = digest(path)
                key = label + '/' + path.relative_to(directory).as_posix()
                require(key not in normalized or normalized[key] == frozen[str(path)], 'tool identity collision')
                normalized[key] = frozen[str(path)]
    return frozen, normalized, result


def prepare():
    pin_source()
    start_path = RECORDS / '6730-mainbaa-current-root-build-start.json'
    build_path = RECORDS / '6730-mainbaa-current-root-build-v1.json'
    log_path = RECORDS / '6730-mainbaa-current-root-build-v1.log'
    provenance_path = RECORDS / '6730-mainbaa-current-wasm-build-provenance.json'
    install_path = RECORDS / '6730-mainbaa-current-install-v1.json'
    start, build, provenance, install = map(load, (start_path, build_path, provenance_path, install_path))
    require(start['head'] == BUILT and provenance['head'] == BUILT, 'recorded build source mismatch')
    require(start['command'] == ['pnpm','build','--concurrency=1'], 'noncanonical recorded build')
    require(build['exit'] == build['childExit'] == 0 and build['cwd'] == str(ROOT), 'root build unsuccessful')
    require(provenance['actualBuild'] == build, 'build/provenance disagreement')
    require(install['command'] == ['pnpm','install','--frozen-lockfile'] and install['exit'] == install['childExit'] == 0,
            'frozen installation missing')
    log = log_path.read_text()
    require('62 successful, 62 total' in log, '62 task root build witness missing')
    for package in PACKAGES:
        require(f'@ifc-lite/{package}:build: cache miss, executing' in log, 'required package was not freshly built')
    require(digest(log_path) == provenance['freshCompilationLogSHA256'], 'recorded root log changed')
    archived = ROOT / 'scripts/perf/evidence/index-reservation-6537/6730-mainbaa-current-root-build-v1.log.gz'
    require(gzip.decompress(archived.read_bytes()) == log_path.read_bytes(), 'published raw archive differs')
    changed = git(ROOT, 'diff', '--name-status', BUILT, HEAD).decode().splitlines()
    allowed = 'scripts/perf/evidence/index-reservation-6537/'
    require(len(changed) == 8 and all(line.split('\t',1)[1].startswith(allowed) for line in changed),
            'successor changes outside exact evidence-only scope')
    frozen = {str(path): digest(path) for path in (start_path, build_path, log_path, provenance_path, install_path, archived)}
    for name, expected in start['inputSHA256'].items():
        path = ROOT / name
        require(digest(path) == expected, 'Rust/toolchain input changed: ' + name)
        frozen[str(path)] = expected
    require(len(start['inputSHA256']) == 1413, 'unexpected Rust input inventory')
    tracked = git(ROOT, 'ls-files', '-z').decode().split('\0')
    source_rows = {}
    def tree(head):
        rows = git(ROOT, 'ls-tree', '-r', '-z', head).split(b'\0')
        return {row.split(b'\t',1)[1].decode():row.split(b'\t',1)[0].split()[2].decode() for row in rows if row}
    built_tree, current_tree = tree(BUILT), tree(HEAD)
    for name in tracked:
        if not name:
            continue
        required = (name.startswith(tuple(f'packages/{p}/src/' for p in PACKAGES))
                    or name in ('package.json','pnpm-lock.yaml','pnpm-workspace.yaml','turbo.json','.npmrc','tsconfig.json','tsconfig.packages.json')
                    or name == 'apps/viewer/package.json'
                    or any(name.startswith(f'packages/{p}/') and (name.endswith('package.json') or name.endswith('tsconfig.json')) for p in PACKAGES))
        if not required:
            continue
        now = (ROOT / name).read_bytes()
        blob = hashlib.sha1(b'blob '+str(len(now)).encode()+b'\0'+now).hexdigest()
        require(blob == built_tree[name] == current_tree[name], 'required tracked source changed: '+name)
        require(now == (BASE / name).read_bytes(), 'required BASE/candidate source mismatch: '+name)
        value = digest(ROOT / name)
        frozen[str(ROOT / name)] = value
        frozen[str(BASE / name)] = value
        source_rows[name] = {'sha256':value,'builtBlob':built_tree[name],
                             'currentBlob':current_tree[name]}
    declarations = {}
    for package in PACKAGES:
        rows = {}
        candidate_files = sorted((ROOT / 'packages' / package / 'dist').rglob('*.d.ts'))
        base_files = sorted((BASE / 'packages' / package / 'dist').rglob('*.d.ts'))
        require([x.relative_to(ROOT / 'packages' / package / 'dist') for x in candidate_files]
                == [x.relative_to(BASE / 'packages' / package / 'dist') for x in base_files], 'declaration inventory differs')
        require(bool(candidate_files), 'no built declarations')
        for path in candidate_files:
            rel = path.relative_to(ROOT / 'packages' / package / 'dist')
            peer = BASE / 'packages' / package / 'dist' / rel
            require(path.read_bytes() == peer.read_bytes(), 'declaration differs: '+str(path))
            frozen[str(path)] = frozen[str(peer)] = digest(path)
            rows[str(rel)] = digest(path)
        declarations[package] = rows
    for name, item in provenance['artifacts'].items():
        path = ROOT / 'packages/wasm/pkg' / name
        require(path.stat().st_size == item['bytes'] and digest(path) == item['SHA256'], 'source-built WASM artifact changed')
        frozen[str(path)] = item['SHA256']
    require(provenance['artifacts']['ifc-lite_bg.wasm']['SHA256'] == WASM, 'wrong candidate WASM')
    base_qualification_path = SHARED / 'base-bundle-qualification.json'
    base_qualification = load(base_qualification_path)
    require(base_qualification['status'] == 'BASE_ENDPOINT_BUNDLE_COMPLETE_NOT_RUNTIME_LEASE', 'BASE endpoint unqualified')
    require(base_qualification['frozenInputsUnchanged'], 'BASE freeze missing')
    # Validate every prior BASE input, retaining its documented historical scope.
    for path, expected in base_qualification['inputSHA256'].items():
        require(digest(path) == expected, 'qualified BASE input changed: '+path)
        frozen[path] = expected
    frozen[str(base_qualification_path)] = digest(base_qualification_path)
    for row in base_qualification['assets']:
        path = Path(base_qualification['dist']) / row['path']
        require(path.stat().st_size == row['size'] and digest(path) == row['sha256'], 'qualified BASE asset changed: '+str(path))
        frozen[str(path)] = row['sha256']
    for path in sorted(SHARED.rglob('*')):
        if path.is_file():
            frozen[str(path)] = digest(path)
    require(not any(path.name.startswith('.env') for path in SHARED.iterdir()), 'unqualified endpoint environment file')
    candidate_tools, candidate_normalized, candidate_resolution = tooling(ROOT)
    base_tools, base_normalized, base_resolution = tooling(BASE)
    require(candidate_normalized == base_normalized, 'compiler/plugin/runtime dependency closure differs')
    frozen.update(candidate_tools)
    frozen.update(base_tools)
    node = Path(subprocess.check_output(['which','node']).decode().strip()).resolve()
    frozen[str(node)] = digest(node)
    for name in ENDPOINT:
        path = SHARED / name
        require(str(path) in base_qualification['inputSHA256'], 'endpoint source outside qualified inventory')
        frozen[str(path)] = digest(path)
    frozen[str(Path(__file__).resolve())] = digest(Path(__file__).resolve())
    receipt = {'status':'CANDIDATE777_REUSE_PREPARED_UNRUN_NOT_RUNTIME_LEASE',
               'capturedUTC':datetime.datetime.now(datetime.timezone.utc).isoformat(),
               'head':HEAD,'builtHead':BUILT,'sourceRoot':str(ROOT),'baseHead':BASEHEAD,
               'sourceEqualityScope':'four src trees and exact required package/config/lock/compiler inputs; direct src aliases, no dist JavaScript used',
               'actualEvidenceOnlyChangedPaths':changed,'rootBuildReceipt':str(build_path),'rootBuildLogSHA256':digest(log_path),
               'rootBuildActualTasks':62,'sourceBuiltWasmSHA256':WASM,'rustInputCount':1413,
               'requiredSourceRows':source_rows,'declarations':declarations,
               'compilerDependencies':candidate_resolution,'baseCompilerDependencies':base_resolution,
               'compilerDependencyFilesEqual':len(candidate_normalized),'frozen':frozen,
               'endpointRoot':str(SHARED),'outputRoot':str(OUTPUT),
               'nodeVersion':subprocess.check_output([str(node),'--version']).decode().strip(),
               'controlsReuse':'BASE v5 actual21 normal invariants and explicit typecheck; exact source, declarations and tooling equality; no candidate run claimed',
               'scope':'source preparation only; no compiler/test/browser/native/model load or performance measurement'}
    return receipt


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--build', action='store_true', help='future root allocation only; standalone endpoint Vite build')
    args = parser.parse_args()
    receipt = prepare()
    proposal_path = SCRATCH / 'candidate-reuse-source-receipt.json'
    if not args.build:
        require(not proposal_path.exists(), 'preserve existing source proposal')
        proposal_path.write_text(json.dumps(receipt,indent=2)+'\n')
        print(json.dumps({'status':receipt['status'],'receipt':str(proposal_path),'frozenInputs':len(receipt['frozen']),
                          'requiredSources':len(receipt['requiredSourceRows']),'compilerFiles':receipt['compilerDependencyFilesEqual']}))
        return
    require(proposal_path.exists(), 'source proposal missing')
    prior = load(proposal_path)
    require(prior['frozen'] == receipt['frozen'], 'source proposal inputs changed before optional build')
    require(not OUTPUT.exists(), 'new nonexistent output required')
    frozen = dict(receipt['frozen'])
    frozen[str(proposal_path)] = digest(proposal_path)
    pre = SCRATCH / 'candidate-bundle-prebuild-freeze.json'
    require(not pre.exists(), 'preserve prior attempt')
    pre.write_text(json.dumps(receipt,indent=2)+'\n')
    frozen[str(pre)] = digest(pre)
    command = ['node',str(SHARED/'build-endpoint.mjs'),str(ROOT),HEAD,str(OUTPUT)]
    started = datetime.datetime.now(datetime.timezone.utc).isoformat()
    log_path = SCRATCH / 'candidate-endpoint-build-actual.log'
    require(not log_path.exists(), 'preserve prior build log')
    with log_path.open('wb') as log:
        code = subprocess.run(command,cwd=ROOT,stdout=log,stderr=subprocess.STDOUT).returncode
    pin_source()
    post_error = None
    try:
        post = prepare()
        old_map, new_map = receipt['frozen'], post['frozen']
        changed = [name for name in sorted(set(old_map)|set(new_map)) if old_map.get(name)!=new_map.get(name)]
        changed.extend(name for name,expected in frozen.items() if not Path(name).is_file() or digest(name)!=expected)
    except (RuntimeError, OSError, subprocess.CalledProcessError) as error:
        post_error = str(error)
        print('POSTBUILD INPUT AUDIT FAILED: '+post_error,file=sys.stderr)
        changed = ['postbuild audit failed; see postbuildAuditError']
    assets = [{'path':str(p.relative_to(OUTPUT)),'bytes':p.stat().st_size,'sha256':digest(p)}
              for p in sorted(OUTPUT.rglob('*')) if p.is_file()] if OUTPUT.exists() else []
    wasms = [row for row in assets if row['path'].endswith('.wasm')]
    workers = [row for row in assets if 'geometry.worker' in row['path'] and row['path'].endswith('.js')]
    qualified = code == 0 and not changed and len(wasms)==1 and wasms[0]['sha256']==WASM and bool(workers) and any(row['path']=='index.html' for row in assets)
    result = {'status':'CANDIDATE777_ENDPOINT_BUNDLE_COMPLETE_NOT_RUNTIME_LEASE' if qualified else 'CANDIDATE777_ENDPOINT_BUILD_FAILED_PRESERVED',
              'head':HEAD,'rootBuildReuseReceipt':str(proposal_path),'sourceBuiltWasmSHA256':WASM,
              'startedUTC':started,'endedUTC':datetime.datetime.now(datetime.timezone.utc).isoformat(),
              'command':command,'exit':code,'log':str(log_path),'logSHA256':digest(log_path),
              'postbuildAuditError':post_error,'changedFrozenInputs':changed,'frozenInputs':frozen,'assets':assets,'wasmAssets':wasms,'geometryWorkers':workers,
              'scope':'actual minimal endpoint bundling only; no candidate test/typecheck/browser/model load/performance verdict'}
    (SCRATCH/'candidate-bundle-qualification.json').write_text(json.dumps(result,indent=2)+'\n')
    require(qualified, 'candidate endpoint qualification failed; raw result retained')
    print(json.dumps({'status':result['status'],'assets':len(assets),'frozenInputs':len(frozen),'WASM':WASM}))


if __name__ == '__main__':
    main()
