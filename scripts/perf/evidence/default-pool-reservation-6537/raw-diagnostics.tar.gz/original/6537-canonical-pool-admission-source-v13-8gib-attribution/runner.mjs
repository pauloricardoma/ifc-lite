/* This Source Code Form is subject to the terms of the Mozilla Public
 * License, v. 2.0. If a copy of the MPL was not distributed with this
 * file, You can obtain one at https://mozilla.org/MPL/2.0/. */
// PROSPECTIVE, UNRUN: one fixed four-fixture untimed inspection of exactly one immutable role; no perf verdict.
import { createRequire } from 'node:module';
import { createHash } from 'node:crypto';
import { execFileSync } from 'node:child_process';
import { readFileSync, readdirSync, mkdirSync, writeFileSync } from 'node:fs';
import { join, resolve } from 'node:path';
import { fixtures, bounds } from './contracts.ts';
import { canonicalReasons, canonicalSemanticWarning, canonicalConsumerSummary } from './semantic-warnings.mjs';
import { inventory, fileHash } from './vendor/interleaved-assets.mjs';
import { serveFrozen } from './vendor/interleaved-server.mjs';
import { processIdentity, stopWitnessedProcesses } from './vendor/interleaved-cleanup.mjs';

// Separate inspection budget; original 5GiB refusals stay excluded and unchanged.
const inspectionRssCeilingBytes = 8 * 1024 ** 3;
const pins = new Map([
  ['BASE', { status: 'BASE_ENDPOINT_BUNDLE_COMPLETE_NOT_RUNTIME_LEASE',
    head: 'baa7d34db1be4bc8bf0b3479df33275da3130fc6',
    sourceRoot: '/home/louistrue/wt/6537-initial-reserve-base-baa-session6503',
    dist: '/tmp/6232-takeover/6537-canonical-pool-base-bundle-v5-empty-normals' }],
  ['CAND777', { status: 'CANDIDATE777_ENDPOINT_BUNDLE_COMPLETE_NOT_RUNTIME_LEASE',
    head: '7776e5b2f04b071b6e5aae7f4f5d1a158320f36d',
    sourceRoot: '/home/louistrue/wt/6537-initial-reserve-main04e-session6503',
    dist: '/tmp/6232-takeover/6537-canonical-pool-candidate777-bundle-v5-empty-normals' }],
]);
function qualificationRole(value) {
  const pin = pins.get(value.role);
  if (!pin || value.status !== pin.status || value.head !== pin.head
    || value.sourceRoot !== pin.sourceRoot || value.dist !== pin.dist
    || value.adapterKind !== 'ROOT_PRODUCER_SCHEMA_ADAPTER_NOT_RUNTIME_LEASE'
    || value.producer?.status !== pin.status || value.producer?.head !== pin.head
    || typeof value.producer?.path !== 'string' || !/^[a-f0-9]{64}$/.test(value.producer?.sha256 ?? '')) {
    throw new Error('unknown or mismatched qualification role/status/head/provenance');
  }
  return pin;
}
async function producerIdentity() {
  qualificationRole(qualification);
  if (await fileHash(qualification.producer.path) !== qualification.producer.sha256) throw new Error('original producer receipt changed');
  const producer = JSON.parse(readFileSync(qualification.producer.path, 'utf8'));
  if (producer.status !== qualification.status || producer.head !== qualification.head) throw new Error('original producer status/head changed');
}
const [qualificationPath, leasePath, outputArgument] = process.argv.slice(2);
if (!qualificationPath || !leasePath || !outputArgument) throw new Error('qualification.json runtime-lease.json NEW_OUTPUT required');
const output = resolve(outputArgument);
mkdirSync(output, { recursive: true });
if (readdirSync(output).length) throw new Error('new empty result directory required');
const report = { inspectionRssCeilingBytes, resourceScope: 'New fixed8GiB inspection, no original5GiB eligibility waiver. Per-owned-process RSS is sampled and shared pages may count repeatedly; not physical peak or allocation attribution.', status: 'pending-admission', verdict: 'UNTIMED semantic diagnostic capture only; no performance verdict or timing eligibility', samples: [] };
const save = () => writeFileSync(join(output, 'report.json'), JSON.stringify(report, null, 2));
save();
let server, qualification, lease;
function sourceHead() {
  if (execFileSync('git', ['-C', qualification.sourceRoot, 'rev-parse', 'HEAD'], { encoding: 'utf8' }).trim()
    !== qualificationRole(qualification).head) throw new Error('immutable subject head changed');
}
async function bounded(promise, ms, label) {
  let timer;
  try { return await Promise.race([promise, new Promise((_resolve, reject) => {
    timer = setTimeout(() => reject(new Error(`${label} deadline`)), Math.max(1, ms));
  })]); } finally { clearTimeout(timer); }
}
function descendantSnapshot() {
  const identities = [];
  for (const name of readdirSync('/proc')) if (/^\d+$/.test(name)) {
    const identity = processIdentity(Number(name)); if (identity) identities.push(identity);
  }
  const owned = new Set([process.pid]);
  for (let depth = 0; depth < 32; depth++) {
    const before = owned.size;
    for (const identity of identities) if (owned.has(identity.ppid)) owned.add(identity.pid);
    if (owned.size === before) break;
    if (depth === 31) throw new Error('descendant depth bound');
  }
  if (owned.size > 4096) throw new Error('own process count bound');
  let bytes = 0;
  const allocations = [];
  for (const pid of owned) {
    try {
      const expected = identities.find(identity => identity.pid === pid);
      const current = processIdentity(pid);
      if (!expected || !current || current.startTime !== expected.startTime || current.ppid !== expected.ppid) continue;
      const match = readFileSync(`/proc/${pid}/status`, 'utf8').match(/^VmRSS:\s+(\d+) kB$/m);
      if (match) {
        const rssBytes = Number(match[1]) * 1024;
        bytes += rssBytes;
        const args = readFileSync(`/proc/${pid}/cmdline`, 'utf8').split('\0');
        const processType = args.find(value => value.startsWith('--type='))?.slice(7);
        allocations.push({ pid, rssBytes, comm: readFileSync(`/proc/${pid}/comm`, 'utf8').trim(),
          role: pid === process.pid ? 'node-driver' : ['renderer', 'gpu-process', 'utility', 'zygote'].includes(processType) ? processType : 'browser-or-launcher' });
      }
    } catch (error) { if (error.code !== 'ENOENT' && error.code !== 'ESRCH') throw error; }
  }
  return { bytes, allocations, members: identities.filter(identity => owned.has(identity.pid) && identity.pid !== process.pid) };
}

async function oneFixture(family, fixture, chromium) {
  const row = { family, status: 'started', observations: 'coarse 100ms observations, not physical peak or perf evidence',
    startedUTC: new Date().toISOString(), logs: [], errors: [], requests: [], requestFinished: [],
    rss: [], polls: [], responses: [], semanticWarnings: [], timingEligibility: 'NOT_DECIDED_NO_TIMED_COHORT_WAIVER', responseIdentityMethod: 'observed request/status + immutable-origin post-drain refetch; not raw browser/CDP loaded-byte capture' };
  const persist = () => writeFileSync(join(output, `${family}.json`), JSON.stringify(row, null, 2));
  const owned = new Map(), observedModules = new Map(), refetchControllers = new Set();
  let browser, page, monitor, poller, pollBusy = false, bytes = 0, records = 0;
  let abortReason, rejectAbort, workPromise, workSettled = false, pollPromise;
  const abortPromise = new Promise((_resolve, reject) => { rejectAbort = reject; });
  abortPromise.catch(error => { row.abortWitness = String(error); });
  const abort = reason => { abortReason ??= String(reason).slice(0, 8192); rejectAbort(new Error(abortReason)); };
  function append(target, value) {
    const cost = Buffer.byteLength(JSON.stringify(value));
    if (++records > 250000 || bytes + cost > 64 * 1024 ** 2) { abort('record/byte capture bound'); return; }
    bytes += cost; target.push(value);
  }
  persist();
  try {
    monitor = setInterval(() => {
      const began = Date.now();
      try {
        const snapshot = descendantSnapshot();
        for (const identity of snapshot.members) owned.set(`${identity.pid}:${identity.startTime}`, identity);
        append(row.rss, { at: began, bytes: snapshot.bytes, monitorWallMs: Date.now() - began, allocations: snapshot.allocations });
        if (snapshot.bytes > inspectionRssCeilingBytes) abort('8GiB owned RSS inspection ceiling');
        if (server.refusal) abort(server.refusal);
        if (Date.parse(lease.expiresUTC) <= Date.now()) abort('runtime lease expired during fixture');
      } catch (error) { abort(`RSS monitor: ${error}`); }
    }, 100);
    const work = async () => {
      browser = await chromium.launch({ executablePath: lease.chromeExecutable, headless: true, timeout: 30000, args: [] });
      if (abortReason) throw new Error(abortReason);
      const context = await browser.newContext({ viewport: { width: 1280, height: 800 }, deviceScaleFactor: 1 });
      context.on('console', message => {
        const text = message.text(), type = message.type(), location = message.location();
        append(row.logs, { type, text, location });
        const semantic = type === 'warning' ? canonicalSemanticWarning(text) : null;
        const workerSource = qualification.geometryWorkers.some(asset => location.url === `${server.origin}/${asset.path}`);
        if (semantic && workerSource) { append(row.semanticWarnings, { text, location, ...semantic }); return; }
        const aggregate = type === 'warning' ? canonicalConsumerSummary(text) : null;
        const consumerSource = qualification.assets.some(asset => /^assets\/index-[^/]+\.js$/.test(asset.path)
          && location.url === `${server.origin}/${asset.path}`);
        // Counts are captured here; semantic reason admission comes only from complete.diagnostics.
        if (aggregate && consumerSource) { append(row.semanticWarnings, { text, location, ...aggregate }); return; }
        if (type === 'error' || type === 'warning' || /retry|recover|fallback|replac|restart|panic|trap/i.test(text)) {
          abort(`console refusal: ${text}`); return;
        }
        // Capture ordinary progress without treating a new info prefix as a worker failure.
        // This inspection is never a timing admission or semantic correctness waiver.
        if (!['log', 'info', 'debug'].includes(type) || (!workerSource && !consumerSource)) {
          abort(`unqualified console source/type: ${text}`);
        }
      });
      context.on('page', tab => {
        tab.on('pageerror', error => { append(row.errors, { error: String(error), stack: error.stack }); abort(`page error: ${error}`); });
        tab.on('crash', () => abort('page crash'));
      });
      context.on('requestfailed', request => {
        append(row.errors, { url: request.url(), failure: request.failure() }); abort(`request failed: ${request.url()}`);
      });
      context.on('request', request => append(row.requests, { url: request.url(), method: request.method() }));
      context.on('requestfinished', request => append(row.requestFinished, { url: request.url(), method: request.method(), at: Date.now() }));
      context.on('response', response => {
        const assetPath = new URL(response.url()).pathname.slice(1) || 'index.html';
        const asset = qualification.assets.find(item => item.path === assetPath);
        append(row.responses, { url: response.url(), status: response.status(), assetPath });
        if (!asset || response.status() !== 200) abort(`unqualified response: ${response.url()} status ${response.status()}`);
        if (/\.wasm$|geometry\.worker.*\.js$|\/index-[^/]+\.js$/.test(response.url())) {
          const url = response.url();
          if (new URL(url).origin !== server.origin || !asset) abort('module origin/asset mismatch');
          else if (!observedModules.has(url) && observedModules.size >= 16) abort('unique module response bound');
          else observedModules.set(url, { asset, observedCount: (observedModules.get(url)?.observedCount ?? 0) + 1 });
        }
      });
      page = await context.newPage();
      await bounded(page.goto(server.origin, { waitUntil: 'load', timeout: 30000 }), 30000, 'endpoint load');
      await bounded(page.waitForFunction(() => Boolean(window.__canonicalPoolEndpoint), undefined, { timeout: 30000 }), 30000, 'endpoint API');
      row.runtime = await page.evaluate(() => ({ cores: navigator.hardwareConcurrency, deviceMemory: navigator.deviceMemory ?? null,
        sab: typeof SharedArrayBuffer !== 'undefined', crossOriginIsolated, visibility: document.visibilityState,
        overrides: Object.getOwnPropertyNames(globalThis).filter(key => key.startsWith('__IFC_LITE_')) }));
      row.runtime.browserVersion = browser.version();
      if (row.runtime.browserVersion !== lease.browserVersion || !row.runtime.sab || !row.runtime.crossOriginIsolated
        || row.runtime.cores < 2 || row.runtime.overrides.length) throw new Error('default runtime/SAB/Chrome mismatch');
      const file = join(qualification.sourceRoot, 'tests/models', fixture.path);
      if (await fileHash(file) !== fixture.sha256) throw new Error('fixture changed before upload');
      await bounded(page.locator('#fixture').setInputFiles(file), 60000, 'file upload outside geometry timer');
      await bounded(page.evaluate(async name => {
        const input = document.querySelector('#fixture');
        if (!(input instanceof HTMLInputElement) || !input.files?.[0]) throw new Error('uploaded File absent');
        await window.__canonicalPoolEndpoint.prepare(input.files[0], name);
      }, family), 60000, 'fixture prepare outside geometry timer');
      row.preparedUTC = new Date().toISOString();
      poller = setInterval(() => {
        if (pollBusy) return;
        pollBusy = true; const began = Date.now();
        pollPromise = page.evaluate(() => {
          const began = performance.now(), receipt = window.__canonicalPoolEndpoint.receipt;
          return { status: receipt?.status, events: receipt?.events, retainedBytes: receipt?.retainedBytes,
            bufferCount: receipt?.bufferCount, workerMemoryCount: receipt?.workerMemory.length,
            collectMs: receipt?.collectMs, generatorDone: receipt?.generatorDone, pollCpuMs: performance.now() - began };
        }).then(value => append(row.polls, { at: began, wallMs: Date.now() - began, ...value }))
          .catch(error => abort(`receipt poll: ${error}`)).finally(() => { pollBusy = false; });
      }, 100);
      row.receipt = await bounded(page.evaluate(() => window.__canonicalPoolEndpoint.run()), fixture.timeoutMs + bounds.hashMs + bounds.cleanupMs, 'finite pool drain');
      clearInterval(poller);
      if (pollPromise) await bounded(pollPromise, 2000, 'final poll settlement');
      if (row.receipt.status !== 'supported-output' || !row.receipt.generatorDone || !row.receipt.processorDisposed) {
        throw new Error(`endpoint refusal: ${row.receipt.error ?? row.receipt.cleanupError ?? row.receipt.status}`);
      }
      const diagnostics = row.receipt.complete.diagnostics;
      if (!diagnostics || diagnostics.schemaVersion !== 3 || !Array.isArray(diagnostics.failuresByReason)
        || !Number.isSafeInteger(diagnostics.totalCsgFailures) || diagnostics.totalCsgFailures < 0
        || diagnostics.failuresByReason.some(item => !canonicalReasons.has(item.reason)
          || !Number.isSafeInteger(item.count) || item.count < 1)
        || diagnostics.failuresByReason.reduce((sum, item) => sum + item.count, 0) !== diagnostics.totalCsgFailures) {
        throw new Error('complete diagnostics missing/unknown reason or inconsistent total');
      }
      row.semanticDiagnosticsScope = 'Full complete.diagnostics untouched; observed record counts, cache-hit omission and batch upper bounds prevent complete operation/affected-product census claims';
      row.outputFaithfulness = 'NOT_ASSERTED: canonical semantic diagnostics can describe approximate/uncut geometry, unsliced layers, refused references and omitted/invalid items; CPU identity covers produced output only';
      const starts = row.logs.flatMap(entry => [...entry.text.matchAll(/processParallel start, fileSizeMB=[\d.]+ workerCount=(\d+)/g)]);
      if (starts.length !== 1) throw new Error('pool-start log missing/duplicate');
      row.workerCount = Number(starts[0][1]);
      row.workerIds = row.receipt.workerMemory.map(item => item.workerIndex).sort((left, right) => left - right);
      if (row.workerCount < 2 || row.workerIds.length !== row.workerCount
        || row.workerIds.some((id, index) => id !== index)) throw new Error('pool memory/start census mismatch');
      if ((row.receipt.complete.coordinateInfo.boundsRecoveryFallbackCount ?? 0) > 0) throw new Error('coordinate bounds recovery');
      row.responseIdentity = [];
      // All module kinds use this declared method from the start; no body-capture fallback.
      for (const [url, { asset, observedCount }] of observedModules) {
        const controller = new AbortController(); refetchControllers.add(controller);
        const timer = setTimeout(() => controller.abort(new Error('post-drain origin refetch deadline')), 10000);
        const identity = { path: asset.path, url, observedCount, browserRequestFinishedCount:
          row.requestFinished.filter(item => item.url === url).length, status: 'started' };
        append(row.responseIdentity, identity);
        try {
          const response = await fetch(url, { redirect: 'error', cache: 'no-store', signal: controller.signal });
          identity.httpStatus = response.status;
          if (response.status !== 200 || !response.body || response.url !== url
            || response.headers.get('content-length') !== String(asset.size)) throw new Error('origin refetch status/URL/length mismatch');
          const hash = createHash('sha256'); let bytes = 0;
          for await (const chunk of response.body) {
            bytes += chunk.byteLength;
            if (bytes > asset.size) throw new Error('origin refetch byte bound');
            hash.update(chunk);
          }
          identity.bytes = bytes; identity.sha256 = hash.digest('hex');
          if (bytes !== asset.size || identity.sha256 !== asset.sha256) throw new Error('frozen origin refetch bytes mismatch');
          identity.status = 'verified';
        } finally { clearTimeout(timer); controller.abort(); refetchControllers.delete(controller); }
      }
      if (!row.responseIdentity.some(item => item.path.endsWith('.wasm'))
        || !row.responseIdentity.some(item => item.path.includes('geometry.worker'))
        || !row.responseIdentity.some(item => /assets\/index-.*\.js$/.test(item.path))) throw new Error('required WASM/worker/consumer response absent');
      row.status = 'pending-cleanup';
    };
    workPromise = work();
    workPromise.then(() => { workSettled = true; }, () => { workSettled = true; });
    await bounded(Promise.race([workPromise, abortPromise]), fixture.timeoutMs + bounds.hashMs + bounds.cleanupMs + 150000, 'whole fixture');
  } catch (error) { row.status = 'refused'; row.reason = String(error); }
  finally {
    const deadline = Date.now() + bounds.cleanupMs;
    clearInterval(poller);
    for (const controller of refetchControllers) controller.abort(new Error('owned fixture cleanup'));
    if (abortReason) { row.status = 'refused'; row.abortReason = abortReason; }
    if (page && !row.receipt) {
      try { row.partialReceipt = await bounded(page.evaluate(() => window.__canonicalPoolEndpoint?.receipt), 1000, 'partial receipt'); }
      catch (error) { row.partialRetentionError = String(error); }
    }
    persist();
    if (page && row.status === 'refused') {
      try { await bounded(page.evaluate(() => window.__canonicalPoolEndpoint?.abort()), 500, 'endpoint abort'); }
      catch (error) { row.abortError = String(error); }
    }
    if (browser) {
      try { await bounded(browser.close(), deadline - Date.now(), 'browser close'); row.browserCleanup = 'complete'; }
      catch (error) { row.browserCleanup = String(error); row.status = 'refused'; }
    }
    clearInterval(monitor);
    try {
      for (const identity of descendantSnapshot().members) owned.set(`${identity.pid}:${identity.startTime}`, identity);
    } catch (error) { row.finalWitnessError = String(error); row.status = 'refused'; }
    row.ownedCleanup = await stopWitnessedProcesses([...owned.values()], Math.max(1, deadline - Date.now()));
    if (row.ownedCleanup.status !== 'complete') row.status = 'refused';
    if (!workSettled && workPromise) {
      try { await bounded(workPromise.catch(error => String(error)), deadline - Date.now(), 'work settlement'); }
      catch (error) { row.workCleanup = String(error); row.status = 'refused'; }
    }
    if (pollPromise) {
      try { await bounded(pollPromise, deadline - Date.now(), 'poll cleanup'); }
      catch (error) { row.pollCleanup = String(error); row.status = 'refused'; }
    }
    if (!workSettled || !row.rss.length) row.status = 'refused';
    if (abortReason) { row.status = 'refused'; row.abortReason = abortReason; }
    row.workSettled = workSettled;
    if (row.status === 'pending-cleanup') row.status = 'complete-captured-semantic-diagnostics';
    row.finishedUTC = new Date().toISOString(); persist();
  }
  return row;
}

try {
  qualification = JSON.parse(readFileSync(qualificationPath, 'utf8'));
  lease = JSON.parse(readFileSync(leasePath, 'utf8'));
  qualificationRole(qualification);
  report.subjectRole = qualification.role; report.subjectHead = qualification.head;
  report.producer = qualification.producer;
  if (lease.owner !== '/root'
    || lease.graph !== 'graph2' || lease.scope !== 'canonical-pool-untimed-admission' || !lease.modelingGateTerminal
    || lease.subjectHead !== qualification.head || !lease.linuxChromeAuthorized || lease.flags?.length
    || lease.rssCeilingBytes !== inspectionRssCeilingBytes || !Number.isFinite(Date.parse(lease.expiresUTC))
    || Date.parse(lease.expiresUTC) <= Date.now()
    || !lease.browserVersion?.startsWith('153.')) throw new Error('new explicit root runtime lease required');
  if (!lease.runtimeSourceSHA256 || !Object.keys(lease.runtimeSourceSHA256).length) throw new Error('root runtime source freeze required');
  for (const [path, sha256] of Object.entries(lease.runtimeSourceSHA256)) if (await fileHash(path) !== sha256) throw new Error(`runtime source changed: ${path}`);
  const preview = JSON.parse(readFileSync(lease.previewStatusReceiptPath, 'utf8'));
  if (!preview.available || !Number.isFinite(Date.parse(preview.capturedUTC))
    || Date.now() - Date.parse(preview.capturedUTC) < 0 || Date.now() - Date.parse(preview.capturedUTC) > 300000
    || await fileHash(lease.previewStatusReceiptPath) !== lease.previewStatusReceiptSha256) throw new Error('actual fresh preview_status receipt required');
  if (await fileHash(qualificationPath) !== lease.bundleQualificationSha256
    || await fileHash(lease.chromeExecutable) !== lease.chromeExecutableSha256) throw new Error('bundle/Chrome lease pin mismatch');
  await producerIdentity();
  if (JSON.stringify(await inventory(qualification.dist)) !== JSON.stringify(qualification.assets)) throw new Error('bundle assets changed');
  sourceHead();
  for (const [path, sha256] of Object.entries(qualification.inputSHA256)) if (await fileHash(path) !== sha256) throw new Error(`bundle input changed: ${path}`);
  for (const name of Object.keys(process.env)) if (name.startsWith('VIEWER_BENCHMARK_')) throw new Error(`default override: ${name}`);
  const { chromium } = createRequire(join(qualification.sourceRoot, 'package.json'))('@playwright/test');
  server = await serveFrozen(qualification.dist, qualification.assets);
  for (const [family, fixture] of Object.entries(fixtures)) {
    if (Date.parse(lease.expiresUTC) <= Date.now()) throw new Error('runtime lease expired');
    const row = await oneFixture(family, fixture, chromium);
    report.samples.push({ family, status: row.status, path: `${family}.json` }); save();
    if (row.status !== 'complete-captured-semantic-diagnostics') throw new Error(`fixed cohort stops at ${family}; no replacements`);
  }
  report.status = 'pending-server-cleanup';
} catch (error) { report.status = 'refused'; report.reason = String(error); process.exitCode = 1; }
finally {
  save();
  if (server) {
    report.serverRequests = server.requests;
    report.serverCleanup = await server.close(bounds.cleanupMs);
    if (report.serverCleanup.status !== 'complete' || server.refusal) { report.status = 'refused'; process.exitCode = 1; }
  }
  if (qualification) {
    try {
      sourceHead();
      await producerIdentity();
      if (await fileHash(qualificationPath) !== lease.bundleQualificationSha256) throw new Error('root adapter receipt changed at end');
      if (JSON.stringify(await inventory(qualification.dist)) !== JSON.stringify(qualification.assets)) throw new Error('bundle assets changed at end');
      for (const [family, fixture] of Object.entries(fixtures)) {
        if (await fileHash(join(qualification.sourceRoot, 'tests/models', fixture.path)) !== fixture.sha256) throw new Error(`fixture changed: ${family}`);
      }
      for (const [path, sha256] of Object.entries(qualification.inputSHA256)) if (await fileHash(path) !== sha256) throw new Error(`source changed at end: ${path}`);
      for (const [path, sha256] of Object.entries(lease.runtimeSourceSHA256)) if (await fileHash(path) !== sha256) throw new Error(`runtime source changed at end: ${path}`);
      report.finalSourceAssetFixtureVerification = 'complete';
    } catch (error) { report.status = 'refused'; report.finalVerificationError = String(error); process.exitCode = 1; }
  }
  if (report.status === 'pending-server-cleanup') report.status = 'complete-captured-semantic-diagnostics';
  save();
}
