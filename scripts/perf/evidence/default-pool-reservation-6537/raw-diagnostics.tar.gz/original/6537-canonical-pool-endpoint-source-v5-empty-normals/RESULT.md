BASE v5 validator correction qualification

Actual guarded scratch check+bundle 2026-10-03T05:08:58.630967Z–05:09:10.437418Z, exit0, peak owned RSS809172KiB. Explicit tsc includes production and test files. All21 behavioral invariants PASS,0 fail/skip; original17 retained and4 empty/partial normal controls exercised.

11718 frozen input hashes unchanged;6 assets emitted. Worker and source-built WASM bytes exactly equal qualifiedv4. Native bridge full bytes differ: implementation equality after replacing exactly one known old/new consumer import filename, scoped to that comparison only. Consumer intentionally changes CPU validator acceptance to canonical normals length0 or full positions length; real raw empty/zero bytes remain different identities, nonzero partial rejected. No production geometry/defaults changed.

Qualification SHA25686d1825d1ee0a65e60704cebae7c04e4d3ac6979480463ea04984128790383e5. Original source-proof is historical pending-review metadata; root subsequently approved source and actual checks. All v2/v3 shape refusals remain preserved. No browser or native execution performed by this build job; no performance verdict.
