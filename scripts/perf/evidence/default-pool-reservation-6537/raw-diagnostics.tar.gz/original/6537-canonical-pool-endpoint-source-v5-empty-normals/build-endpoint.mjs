/* This Source Code Form is subject to the terms of the Mozilla Public
 * License, v. 2.0. If a copy of the MPL was not distributed with this
 * file, You can obtain one at https://mozilla.org/MPL/2.0/. */
// PROSPECTIVE ONLY. Root must qualify a genuine whole-root build first.
import path from 'node:path';
import { createRequire } from 'node:module';
import { pathToFileURL, fileURLToPath } from 'node:url';
import { execFileSync } from 'node:child_process';
import { mkdir, readdir, writeFile } from 'node:fs/promises';
import { endpointConfig } from './vite-config.mts';

const pins = new Set(['baa7d34db1be4bc8bf0b3479df33275da3130fc6',
  '7776e5b2f04b071b6e5aae7f4f5d1a158320f36d']);
const [sourceArgument, head, outputArgument] = process.argv.slice(2);
if (!sourceArgument || !outputArgument || !pins.has(head)) throw new Error('ROOT IMMUTABLE_HEAD NEW_OUTPUT required');
const sourceRoot = path.resolve(sourceArgument);
const outputRoot = path.resolve(outputArgument);
const endpointRoot = path.dirname(fileURLToPath(import.meta.url));
if (outputRoot === endpointRoot || outputRoot.startsWith(`${sourceRoot}${path.sep}`)) {
  throw new Error('output must be new and outside the source worktree');
}
const git = (...args) => execFileSync('git', ['-C', sourceRoot, ...args], { encoding: 'utf8' }).trim();
function sourceGate() {
  if (git('rev-parse', 'HEAD') !== head || git('status', '--porcelain', '--untracked-files=no')) {
    throw new Error('immutable clean source required');
  }
}
sourceGate();
await mkdir(outputRoot, { recursive: true });
if ((await readdir(outputRoot)).length) throw new Error('new empty output required');
// Resolve consuming-package dependencies from this qualified checkout, never install under /tmp.
const requireFromViewer = createRequire(path.join(sourceRoot, 'apps/viewer/package.json'));
const load = name => import(pathToFileURL(requireFromViewer.resolve(name)).href);
const [{ build }, { default: wasm }, { default: topLevelAwait }] = await Promise.all([
  load('vite'), load('vite-plugin-wasm'), load('vite-plugin-top-level-await'),
]);
await build(endpointConfig(sourceRoot, endpointRoot, outputRoot, wasm, topLevelAwait));
sourceGate();
await writeFile(path.join(outputRoot, 'endpoint-source-receipt.json'), JSON.stringify({
  kind: 'post-endpoint-bundle-receipt-not-runtime-lease', sourceRoot, head, endpointRoot,
  wholeRootBuildQualification: 'MUST_BE_SUPPLIED_AND_VERIFIED_BY_ROOT',
  time: new Date().toISOString(),
}, null, 2));
