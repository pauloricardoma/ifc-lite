#!/usr/bin/env python3
"""Fixed approved BASE endpoint compilation; no browser or candidate work."""
import datetime
import hashlib
import json
from pathlib import Path
import subprocess

root = Path('/home/louistrue/wt/6537-initial-reserve-base-baa-session6503')
scratch = Path(__file__).resolve().parent
output = Path('/tmp/6232-takeover/6537-canonical-pool-base-bundle-v5-empty-normals')
head = 'baa7d34db1be4bc8bf0b3479df33275da3130fc6'

def digest(path):
    hash_value = hashlib.sha256()
    with path.open('rb') as stream:
        for block in iter(lambda: stream.read(4 * 1024 * 1024), b''):
            hash_value.update(block)
    return hash_value.hexdigest()

qualified = json.loads(Path('/tmp/6232-takeover/6537-canonical-pool-endpoint-source-v2/base-reuse-final.json').read_text())
assert qualified['status'] == 'BASE_REUSE_TYPED_INVARIANTS_COMPLETE'
assert all(digest(Path(name)) == row['sha256'] for name, row in qualified['frozen'].items())
snapshot = json.loads(Path(qualified['previousSnapshot']).read_text())
frozen = {str(root / name): value for name, value in snapshot['inputSHA256'].items()}
for name, expected in frozen.items():
    assert digest(Path(name)) == expected
for name, item in qualified['frozen'].items():
    frozen[name] = item['sha256']

for path in scratch.iterdir():
    if path.is_file() and path.suffix in {'.ts', '.mts', '.mjs', '.html', '.py', '.patch', '.json'}:
        frozen[str(path)] = digest(path)
for name in ['ifc-lite_bg.wasm', 'ifc-lite.js', 'ifc-lite.d.ts']:
    path = root / 'packages/wasm/pkg' / name
    frozen[str(path)] = digest(path)
for name in ['vite', 'vite-plugin-wasm', 'vite-plugin-top-level-await']:
    directory = (root / 'apps/viewer/node_modules' / name).resolve()
    for path in directory.rglob('*'):
        if path.is_file() and 'node_modules' not in path.relative_to(directory).parts:
            frozen[str(path)] = digest(path)
receipt = {'status': 'PREBUNDLE_INPUT_FREEZE', 'head': head, 'sourceRoot': str(root),
    'dist': str(output), 'capturedUTC': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'reuseReceipt': '/tmp/6232-takeover/6537-canonical-pool-endpoint-source-v2/base-reuse-final.json',
    'reuseReceiptSha256': digest(Path('/tmp/6232-takeover/6537-canonical-pool-endpoint-source-v2/base-reuse-final.json')), 'inputSHA256': frozen,
    'nodeVersion': subprocess.check_output(['node', '--version']).decode().strip(),
    'pnpmVersion': subprocess.check_output(['pnpm', '--version'], cwd=root).decode().strip(),
    'toolingScope': 'direct compiler/plugin distributions and genuine frozen installation; not a new install'}
(scratch / 'base-bundle-prebuild-freeze.json').write_text(json.dumps(receipt, indent=2) + '\n')
previous_source = Path('/tmp/6232-takeover/6537-canonical-pool-endpoint-source-v4-flat-shape-diagnostic')
for name in ['contracts.ts', 'retention.ts', 'consumer.ts', 'entry.ts', 'index.html', 'vite-config.mts', 'build-endpoint.mjs']:
    assert (scratch / name).read_bytes() == (previous_source / name).read_bytes()
proof = json.loads((scratch / 'source-proof.json').read_text())
for row in proof['files']:
    assert digest(scratch / row['path']) == row['sha256']
source_proof = {'status': 'ROOT_APPROVED_EMPTY_NORMALS_CONTRACT', 'identitySHA256': digest(scratch / 'identity.ts'),
    'normalsContract': 'Float32Array length zero OR exactly positions length; nonzero partial rejected; raw bytes preserved'}
subprocess.run(['pnpm', 'exec', 'tsc', '-p', str(scratch / 'tsconfig.json')], cwd=root, check=True)
print('EMPTY NORMALS EXPLICIT TYPECHECK INCLUDING TEST PASS', flush=True)
subprocess.run(['pnpm', 'exec', 'tsx', '--tsconfig', str(scratch / 'tsconfig.json'), '--test', str(scratch / 'identity.test.ts')], cwd=root, check=True)
print('ALL 21 BEHAVIOR INVARIANTS PASS', flush=True)
subprocess.run(['node', str(scratch / 'build-endpoint.mjs'), str(root), head, str(output)], cwd=root, check=True)
assert all(digest(Path(name)) == expected for name, expected in frozen.items())
assets = [{'path': str(path.relative_to(output)), 'size': path.stat().st_size, 'sha256': digest(path)}
    for path in sorted(output.rglob('*')) if path.is_file()]
assert any(row['path'] == 'index.html' for row in assets)
wasms = [row for row in assets if row['path'].endswith('.wasm')]
assert len(wasms) == 1 and wasms[0]['sha256'] == qualified['wasmSha256']
workers = [row for row in assets if 'geometry.worker' in row['path'] and row['path'].endswith('.js')]
assert workers
previous_path = Path('/tmp/6232-takeover/6537-canonical-pool-endpoint-source-v4-flat-shape-diagnostic/base-bundle-qualification.json')
previous = json.loads(previous_path.read_text())
old_by_path = {row['path']: row for row in previous['assets']}
new_by_path = {row['path']: row for row in assets}
strict = [row for row in assets if row['path'].endswith('.wasm') or 'geometry.worker' in row['path']]
for row in strict:
    assert row == old_by_path[row['path']]
    assert (output / row['path']).read_bytes() == (Path(previous['dist']) / row['path']).read_bytes()
old_consumer = next(row for row in previous['assets'] if row['path'].startswith('assets/index-') and row['path'].endswith('.js'))
new_consumer = next(row for row in assets if row['path'].startswith('assets/index-') and row['path'].endswith('.js'))
old_native = next(row for row in previous['assets'] if row['path'].startswith('assets/native-bridge-'))
new_native = next(row for row in assets if row['path'].startswith('assets/native-bridge-'))
old_text = (Path(previous['dist']) / old_native['path']).read_text()
new_text = (output / new_native['path']).read_text()
old_import = './' + Path(old_consumer['path']).name
new_import = './' + Path(new_consumer['path']).name
assert old_text.count(old_import) == 1 and new_text.count(new_import) == 1
assert old_text.replace(old_import, './EXACT_CONSUMER_IMPORT.js') == new_text.replace(new_import, './EXACT_CONSUMER_IMPORT.js')
receipt['previousBundleQualification'] = str(previous_path)
receipt['strictWorkerWasmByteEquality'] = {'equal': True, 'assets': strict}
receipt['nativeBridgeComparison'] = {'fullAssetByteEqual': old_text == new_text,
    'onlyQualifiedConsumerFilenameNormalized': True, 'normalizedImplementationEqual': True,
    'oldConsumerImport': old_import, 'newConsumerImport': new_import,
    'oldAsset': old_native, 'newAsset': new_native,
    'scope': 'Literal implementation comparison after replacing exactly one known consumer import filename; lazy native branch unused by canonical web pool'}
receipt['intentionalConsumerDiagnosticDifference'] = {'oldAsset': old_consumer, 'newAsset': new_consumer,
    'reason': 'approved CPU validator contract correction: canonical empty normals supported, nonzero partial rejected, raw bytes unchanged'}
receipt['successorSourceEquality'] = source_proof
receipt.update(status='BASE_ENDPOINT_BUNDLE_COMPLETE_NOT_RUNTIME_LEASE', frozenInputsUnchanged=True,
    completedUTC=datetime.datetime.now(datetime.timezone.utc).isoformat(), assets=assets,
    wasmAssets=wasms, geometryWorkers=workers)
(scratch / 'base-bundle-qualification.json').write_text(json.dumps(receipt, indent=2) + '\n')
print('BASE BUNDLE QUALIFIED', len(assets), 'assets;', len(frozen), 'unchanged inputs; WASM', wasms[0]['sha256'])
