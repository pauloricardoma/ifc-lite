#!/usr/bin/env python3
"""Bound our correctness-only process tree; never supplies performance evidence."""
import datetime
import json
import os
from pathlib import Path
import signal
import subprocess
import sys
import time

worktree = Path(sys.argv[1])
prefix = Path(sys.argv[2])
command = sys.argv[3:]
minimum_start_kib = 24 * 1024 * 1024
minimum_live_kib = 8 * 1024 * 1024
maximum_tree_rss_kib = 12 * 1024 * 1024

def available():
    return int(next(line.split()[1] for line in Path('/proc/meminfo').read_text().splitlines()
                    if line.startswith('MemAvailable:')))

def tree_rss(leader):
    rows = {}
    for entry in Path('/proc').iterdir():
        if not entry.name.isdigit():
            continue
        try:
            values = (entry / 'stat').read_text().rsplit(')', 1)[1].split()
            rows[int(entry.name)] = (int(values[1]), max(0, int(values[21])) * os.sysconf('SC_PAGE_SIZE') // 1024)
        except (FileNotFoundError, ProcessLookupError, PermissionError):
            continue
    descendants = {leader}
    while True:
        expanded = descendants | {pid for pid, (parent, _) in rows.items() if parent in descendants}
        if expanded == descendants:
            break
        descendants = expanded
    return sum(rows.get(pid, (0, 0))[1] for pid in descendants), len(descendants)

receipt = {'startedUTC': datetime.datetime.now(datetime.timezone.utc).isoformat(),
           'cwd': str(worktree), 'command': command, 'minimumStartKiB': minimum_start_kib,
           'minimumLiveKiB': minimum_live_kib, 'maximumTreeRssKiB': maximum_tree_rss_kib,
           'initialAvailableKiB': available(), 'scope': 'Correctness-only run under host load; no timing/performance verdict.',
           'peakTreeRssKiB': 0, 'minimumObservedAvailableKiB': available()}
if receipt['initialAvailableKiB'] < minimum_start_kib:
    receipt['exit'] = 75
    receipt['reason'] = 'Insufficient starting memory; no child launched.'
else:
    with prefix.with_suffix('.log').open('w') as output:
        child = subprocess.Popen(command, cwd=worktree,
            env={**os.environ, 'CI': '1', 'CARGO_BUILD_JOBS': '2'},
            stdout=output, stderr=subprocess.STDOUT, start_new_session=True)
        receipt['ownedProcessGroup'] = child.pid
        while child.poll() is None:
            rss, count = tree_rss(child.pid)
            free = available()
            receipt['peakTreeRssKiB'] = max(receipt['peakTreeRssKiB'], rss)
            receipt['minimumObservedAvailableKiB'] = min(receipt['minimumObservedAvailableKiB'], free)
            if rss > maximum_tree_rss_kib or free < minimum_live_kib:
                receipt['reason'] = 'Own process tree exceeded budget or host memory fell below live reserve.'
                receipt['budgetAbort'] = {'rssKiB': rss, 'availableKiB': free, 'processCount': count}
                try:
                    os.killpg(child.pid, signal.SIGTERM)
                    child.wait(timeout=5)
                except subprocess.TimeoutExpired:
                    os.killpg(child.pid, signal.SIGKILL)
                    child.wait()
                except ProcessLookupError:
                    child.wait()
                break
            time.sleep(0.25)
        receipt['childExit'] = child.wait()
        receipt['exit'] = 75 if 'budgetAbort' in receipt else receipt['childExit']
receipt['endedUTC'] = datetime.datetime.now(datetime.timezone.utc).isoformat()
prefix.with_suffix('.json').write_text(json.dumps(receipt, indent=2) + '\n')
print(json.dumps(receipt))
sys.exit(receipt['exit'])
