"""Archival source inspection and lossless packaging only: no load/test/timing."""
from pathlib import Path
import gzip, hashlib, io, json, struct, subprocess, tarfile

TMP = Path('/tmp/6232-takeover')
WT = Path('/home/louistrue/wt/6537-reservation-path-disposition-session6503')
OUT = WT / 'scripts/perf/evidence/default-pool-reservation-6537'
OUT.mkdir(parents=True, exist_ok=True)
BASE = 'baa7d34db1be4bc8bf0b3479df33275da3130fc6'
CAND = '7776e5b2f04b071b6e5aae7f4f5d1a158320f36d'
MEMBERS = {}
ORIGINS = {}

def add(name, data, origin):
    if name in MEMBERS:
        raise ValueError(f'duplicate archive member: {name}')
    MEMBERS[name] = data
    ORIGINS[name] = origin

def original(path):
    if path.is_symlink() or not path.is_file():
        raise ValueError(f'not a regular original file: {path}')
    add('original/' + str(path.relative_to(TMP)), path.read_bytes(), str(path))

def git_bytes(*args):
    return subprocess.check_output(['git', '-C', str(WT), *args])

root_name = '6730-default-pool-source-eligibility-and-CPU-identity-root-v1.json'
original(TMP / root_name)
for version in ('v8-semantic-class', 'v9-base8gib', 'v10-cand8gib'):
    directory = TMP / ('6537-canonical-pool-admission-actual-' + version)
    for name in ('report.json', 'house.json', 'csg.json', 'heavy-csg.json', 'architecture.json'):
        original(directory / name)
    for suffix in ('.json', '.log'):
        original(TMP / ('6537-canonical-pool-admission-root-actual-' + version + suffix))

for directory in (
    '6537-canonical-pool-endpoint-source-v5-empty-normals',
    '6537-canonical-pool-candidate777-reuse-source-v3',
    '6537-canonical-pool-admission-source-v11-canonical-semantic-class',
    '6537-canonical-pool-admission-source-v12-two-role-provenance',
    '6537-canonical-pool-admission-source-v13-8gib-attribution',
):
    for path in sorted((TMP / directory).rglob('*')):
        if path.is_file():
            original(path)
for name in (
    'functional-budget-guardian-v2-session6503.py',
    '6537-canonical-pool-endpoint-source-v2/base-reuse-final.json',
    '6537-canonical-pool-candidate777-endpoint-build-root-actual-v1.json',
    '6537-canonical-pool-candidate777-endpoint-build-root-actual-v1.log',
    '6730-mainbaa-current-root-build-v1.json',
    '6730-mainbaa-current-root-build-v1.log',
):
    original(TMP / name)

paths = (
    'rust/core/src/columnar_index.rs',
    'rust/core/src/decoder.rs',
    'rust/core/src/limits.rs',
    'packages/geometry/src/geometry-parallel.ts',
    'packages/geometry/src/geometry.worker.ts',
    'rust/wasm-bindings/src/api/entity_index.rs',
    'rust/wasm-bindings/src/api/gpu_meshes/batch.rs',
    'rust/wasm-bindings/src/api/gpu_meshes/prepass.rs',
    'rust/wasm-bindings/src/api/gpu_meshes/source_fingerprint_prepass.rs',
)
snapshot_index = []
for role, ref in (('BASE', BASE), ('CAND', CAND)):
    for path in paths:
        data = git_bytes('show', ref + ':' + path)
        name = 'frozen-source/' + role + '/' + path
        add(name, data, 'git:' + ref + ':' + path)
        snapshot_index.append({'role': role, 'commit': ref, 'path': path,
            'blob': git_bytes('rev-parse', ref + ':' + path).decode().strip(),
            'sha256': hashlib.sha256(data).hexdigest(), 'bytes': len(data)})
path = 'rust/core/tests/issue_6537_initial_index_reservation.rs'
add('frozen-source/CAND/' + path, git_bytes('show', CAND + ':' + path), 'git:' + CAND + ':' + path)
add('frozen-source/reservation-candidate.patch', git_bytes('diff', BASE, CAND, '--', 'rust/core', 'rust/wasm-bindings/src/api/gpu_meshes/prepass.rs'), f'git diff {BASE} {CAND} -- rust/core rust/wasm-bindings/src/api/gpu_meshes/prepass.rs')
add('source-inspection/frozen-source-index.json', (json.dumps(snapshot_index, indent=2)+'\n').encode(), 'derived git blob/SHA256 identity; not a behavior test')
add('source-inspection/packaging-and-inspection.py', Path(__file__).read_bytes(), str(Path(__file__)))

# Preserve the original attribution bytes in a separately accessible gzip.
root_raw = (TMP / root_name).read_bytes()
(OUT / 'eligibility.json.gz').write_bytes(gzip.compress(root_raw, mtime=0))

# Normalize only container metadata; every archived original payload stays exact.
tar_buffer = io.BytesIO()
with tarfile.open(fileobj=tar_buffer, mode='w', format=tarfile.PAX_FORMAT) as archive:
    for name in sorted(MEMBERS):
        data = MEMBERS[name]
        entry = tarfile.TarInfo(name)
        entry.size = len(data)
        entry.mode = 0o644
        entry.uid = entry.gid = 0
        entry.mtime = 0
        entry.uname = entry.gname = ''
        archive.addfile(entry, io.BytesIO(data))
(OUT / 'raw-diagnostics.tar.gz').write_bytes(gzip.compress(tar_buffer.getvalue(), mtime=0))
index = [{'path': name, 'sha256': hashlib.sha256(MEMBERS[name]).hexdigest(),
          'bytes': len(MEMBERS[name]), 'origin': ORIGINS[name]} for name in sorted(MEMBERS)]
(OUT / 'artifact-index.json.gz').write_bytes(gzip.compress((json.dumps(index, indent=2)+'\n').encode(), mtime=0))
(OUT / 'SHA256SUMS').write_text(''.join(f"{row['sha256']}  {row['path']}\n" for row in index))

# Independent decompression/readback validation against all retained originals.
with tarfile.open(fileobj=io.BytesIO(gzip.decompress((OUT / 'raw-diagnostics.tar.gz').read_bytes())), mode='r:') as archive:
    observed = {}
    for member in archive.getmembers():
        if not member.isfile():
            raise ValueError('unexpected non-file archive entry')
        data = archive.extractfile(member).read()
        observed[member.name] = data
    if observed != MEMBERS:
        raise ValueError('archive payloads differ from original source bytes')
if gzip.decompress((OUT / 'eligibility.json.gz').read_bytes()) != root_raw:
    raise ValueError('attribution gzip is not lossless')
if json.loads(gzip.decompress((OUT / 'artifact-index.json.gz').read_bytes())) != index:
    raise ValueError('artifact index gzip is not lossless')
for name in ('eligibility.json.gz', 'raw-diagnostics.tar.gz', 'artifact-index.json.gz'):
    if struct.unpack('<I', (OUT/name).read_bytes()[4:8])[0] != 0:
        raise ValueError('nonzero gzip mtime')
original_rows = [row for row in index if row['path'].startswith('original/')]
receipt = {'scope': 'lossless packaging/decompression/hash validation only; no runtime/test/measurement',
    'worktreeHead': git_bytes('rev-parse', 'HEAD').decode().strip(),
    'base': BASE, 'candidate': CAND, 'archiveMembers': len(index),
    'originalFiles': len(original_rows), 'originalBytes': sum(row['bytes'] for row in original_rows),
    'allMemberBytes': sum(row['bytes'] for row in index), 'tarBytes': len(tar_buffer.getvalue()),
    'allPayloadsVerbatim': True, 'gzipMtimeZero': True,
    'files': {name: {'bytes': (OUT/name).stat().st_size, 'sha256': hashlib.sha256((OUT/name).read_bytes()).hexdigest()}
        for name in ('eligibility.json.gz','raw-diagnostics.tar.gz','artifact-index.json.gz','SHA256SUMS')}}
(OUT / 'archive-validation.json').write_text(json.dumps(receipt, indent=2)+'\n')
print(json.dumps(receipt, indent=2))
