export { default as init, initSync, IfcAPI } from '@ifc-lite/wasm';
