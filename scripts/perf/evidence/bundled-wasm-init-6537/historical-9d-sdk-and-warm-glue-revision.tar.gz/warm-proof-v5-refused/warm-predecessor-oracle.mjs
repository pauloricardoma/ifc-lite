import { createRequire } from 'node:module';
import { readFile, writeFile, readdir, stat } from 'node:fs/promises';
import { resolve, join, relative } from 'node:path';
import { pathToFileURL } from 'node:url';
import { createHash } from 'node:crypto';
import vm from 'node:vm';
import assert from 'node:assert/strict';
import { execFileSync } from 'node:child_process';
const root = resolve(process.env.IFC_LITE_PROOF_ROOT ?? '/home/louistrue/wt/6537-browser-init-failure-semantics-session6503');
const packet = import.meta.dirname, dist = '/tmp/6232-takeover/6537-browser-init-vite-vm-proof-v4/dist';
const receipt = { status: 'started', scope: 'Actual Vite/glue/real-WASM correctness only; cached artifacts, no model/worker/browser/performance run',
  command: process.argv, head: execFileSync('git', ['-C', root, 'rev-parse', 'HEAD'], { encoding: 'utf8' }).trim(),
  node: process.version, sourceInputs: {}, outputs: [], cases: [], tools: {} };
const hash = bytes => createHash('sha256').update(bytes).digest('hex');
async function input(path) { receipt.sourceInputs[path] = hash(await readFile(path)); }
async function verifyInputs() {
  for (const [path, expected] of Object.entries(receipt.sourceInputs)) assert.equal(hash(await readFile(path)), expected, `changed input ${path}`);
}
async function files(directory, depth = 0) {
  if (depth > 12) throw new Error('walk depth bound');
  const result = [];
  for (const entry of await readdir(directory, { withFileTypes: true })) {
    if (entry.isDirectory()) result.push(...await files(join(directory, entry.name), depth + 1));
    else if (entry.isFile()) result.push(join(directory, entry.name));
    else throw new Error('unsupported input/output link');
    if (result.length > 10000) throw new Error('walk count bound');
  }
  return result;
}
const origin = 'https://vm-fixture.invalid';
const native = WebAssembly;
function makeContext(label, assets, mode = 'valid') {
  const result = { label, requests: [], calls: [], modules: [], timers: [], cloneCount: 0, namespace: null };
  const transportFailure = new TypeError('Failed to fetch');
  let compileFailure, offlineAfterPublicInit = false;
  const moduleIds = new WeakMap(); let nextId = 0;
  const moduleId = module => { if (!moduleIds.has(module)) moduleIds.set(module, ++nextId); return moduleIds.get(module); };
  const observedWasm = Object.create(native);
  observedWasm.compileStreaming = async response => {
    result.calls.push({ name: 'compileStreaming' });
    try { return await native.compileStreaming(response); }
    catch (error) { compileFailure = error; throw error; }
  };
  observedWasm.compile = async bytes => { result.calls.push({ name: 'compile' }); return native.compile(bytes); };
  observedWasm.instantiate = async (value, imports) => {
    const isModule = value instanceof native.Module;
    result.calls.push({ name: 'instantiate', inputIsModule: isModule, moduleId: isModule ? moduleId(value) : null });
    if (isModule) result.modules.push(value);
    const instantiated = await native.instantiate(value, imports);
    return instantiated;
  };
  observedWasm.instantiateStreaming = async (response, imports) => {
    result.calls.push({ name: 'instantiateStreaming' });
    const instantiated = await native.instantiateStreaming(response, imports);
    return instantiated;
  };
  const context = vm.createContext({ window: {}, URL, Response, Request, TextEncoder, TextDecoder,
    console, Error, TypeError, crypto: globalThis.crypto,
    setTimeout: (callback, delay, ...args) => { result.timers.push(delay); return setTimeout(callback, delay, ...args); },
    clearTimeout, performance, WebAssembly: observedWasm,
    fetch: async value => {
      const url = String(value), parsed = new URL(url);
      assert.equal(parsed.origin, origin); const asset = assets.get(parsed.pathname);
      if (!asset) throw new Error(`unqualified request URL ${url}`);
      assert.ok(url.endsWith('.wasm'));
      const bytes = mode === 'invalid' ? Buffer.from([0, 1, 2]) : asset.bytes;
      result.requests.push({ url, bytes: bytes.length, sha256: hash(bytes), mode });
      if (result.requests.length > 10) throw new Error('request bound');
      if (offlineAfterPublicInit) throw transportFailure;
      if (mode === 'persistent' || (mode === 'transient' && result.requests.length === 1)) throw transportFailure;
      const response = new Response(bytes, { headers: { 'Content-Type': mode === 'mime' ? 'text/plain' : 'application/wasm' } });
      const originalClone = response.clone;
      response.clone = function (...args) { result.cloneCount++; return Reflect.apply(originalClone, this, args); };
      return response;
    } });
  const modules = new Map();
  async function load(url) {
    if (modules.has(url)) return modules.get(url);
    const parsed = new URL(url); assert.equal(parsed.origin, origin);
    const asset = assets.get(parsed.pathname); if (!asset || !url.endsWith('.js')) throw new Error(`unqualified JS ${url}`);
    const module = new vm.SourceTextModule(asset.bytes.toString('utf8'), { context, identifier: url,
      initializeImportMeta(meta) { meta.url = url; },
      importModuleDynamically() { throw new Error('unexpected dynamic import / Node branch'); } });
    modules.set(url, module);
    await module.link((specifier, referencing) => load(new URL(specifier, referencing.identifier).href));
    return module;
  }
  return { result, transportFailure, offline() { offlineAfterPublicInit = true; result.offlineAfterPublicInit = true; }, get compileFailure() { return compileFailure; }, async entry(name) {
    const selected = [...assets.entries()].filter(([path]) => new RegExp(`/${name}-[^/]+\\.js$`).test(path));
    assert.equal(selected.length, 1, 'unique emitted entry');
    const module = await load(origin + selected[0][0]); await module.evaluate({ timeout: 30000 });
    return module.namespace;
  } };
}

const historical = JSON.parse(await readFile('/tmp/6232-takeover/6537-browser-init-vite-vm-proof-v4/receipt.json', 'utf8'));
assert.equal(historical.head, '9d59797fa2dc040c65d34d8f64361465ebda589c');
assert.equal(historical.status, 'complete-vite-glue-vm-correctness');
const assets = new Map();
for (const a of historical.outputs) {
  const bytes = await readFile(join(dist,a.path.slice(1)));
  assert.equal(bytes.length,a.bytes); assert.equal(hash(bytes),a.sha256);
  assets.set(a.path,{bytes,sha256:a.sha256});
}
const rows=[];
for (const mode of ['async']) {
 const warmed=makeContext('historical-'+mode+'-warm-then-offline',assets);
 const glue=await warmed.entry('glue');
 if(mode==='async')await glue.init();
 else glue.initSync({module:await native.compile(assets.get(historical.outputs.find(x=>x.path.endsWith('.wasm')).path).bytes)});
 const initialApi=new glue.IfcAPI();initialApi.free();
 const before=warmed.result.requests.length;warmed.offline();
 const bridgeModule=await warmed.entry('bridge'), bridge=new bridgeModule.IfcLiteBridge();
 let failure;try {await bridge.init();}catch(error){failure=error;}
 assert.equal(bridge.isInitialized(),false);
 assert.equal(failure.cause,warmed.transportFailure);
 assert.equal(warmed.result.requests.length,before+2);
 assert.deepEqual(warmed.result.timers,[300]);
 let assertion;try {assert.equal(warmed.result.requests.length,before,'warm public engine must not acquire an asset');}catch(error){assertion={name:error.name,message:error.message};}
 assert.equal(assertion.name,'AssertionError');bridge.dispose();
 rows.push({mode,before,after:warmed.result.requests.length,realAssertionRed:assertion,originalCauseVerified:true,requests:warmed.result.requests,timers:warmed.result.timers});
}
const result={status:'OBSERVED_REAL_WARM_GLUE_COMPATIBILITY_ASSERTION_RED',head:historical.head,scope:'Actual retained Vite/glue/real cached WASM; historical 9d predecessor only, no browser/model/performance',assetPins:historical.outputs,rows};
await writeFile(join(packet,'warm-predecessor-oracle.json'),JSON.stringify(result,null,2));
console.log(JSON.stringify({status:result.status,head:result.head,rows:rows.map(x=>({mode:x.mode,before:x.before,after:x.after,assertion:x.realAssertionRed.name}))}));
