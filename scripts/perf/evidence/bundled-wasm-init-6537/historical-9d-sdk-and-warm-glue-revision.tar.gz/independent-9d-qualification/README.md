# Independent historical SDK result qualification

Run 37152442255: controller 4d47506a23e304ed4b772f7890e27e37843e8914;
BASE c61932d4a9d85efe1b0f817a5274a115f0571ee3;
CAND 9d59797fa2dc040c65d34d8f64361465ebda589c.

The adapted retained-receipt/asset audit passes 1,506 checks with no findings.
An additional 38 Git-tree/selected-causal-source/normalized-dependency-closure
checks pass. All 56 fresh samples and 28 fixed pairs remain: two A/A controls
and five alternating A/B pairs per fixture family. All CPU output identities,
counts and full unnormalized diagnostics agree within each family. Default
runtime is two workers on four reported cores, with SAB/COI and no overrides.
Both arms genuinely produced six fresh root build tasks, including WASM; all
retained endpoint assets rehash against producing, served and requested bytes.
Remote full source/tool/closure final checks remain producer receipts; tools
and source paths cannot be independently rehashed after runner termination.

Median paired elapsed deltas: house -1.504%; CSG -0.936%; Holter -2.275%;
architecture -0.076%. Every pair and outlier is retained. CSG contains a +0.869%
pair and a -9.793% pair caused numerically by a high baseline elapsed value;
that is not proof of its physical cause. Architecture is mixed. All eight A/A
controls pass, maximum absolute difference 5.294%. These small/mixed historical
observations establish no universal speed improvement.

All 168 fresh CPU intervals independently pass, maximum 2.256% busy. Initial
available memory is 15,543,533,568 bytes; minimum sampled live availability is
12,665,876,480 bytes. Maximum sampled owned RSS is 3,746,439,168 bytes, not a
physical peak. Full cohort cleanup witnesses 614 processes, zero remaining or
zombies; both servers close with zero sockets/faults and final input verification
completes. Sample cleanup/log drains and pre-teardown snapshots pass.

Every baseline sample records two browser WASM requests/responses/finished;
every candidate records one. Counts occur in the SDK geometry-and-posthash phase;
runner-origin refetch is outside those browser records. They do not measure wire
bytes or isolate fetch/compile duration. Source timer includes processor.init,
default processParallel generator drain, retention and processor.dispose; output
hashing follows the frozen timer. Raw geometry arrays are not uploaded, so the
CPU digests are compared observed witnesses, not independently regenerated.

The two emitted engines are not byte-identical. All 1,410 captured Rust source
hashes and Cargo/toolchain/config hashes agree, and dependency closures normalize
to the same 762 entries. Retained binary parsing proves code/data sections differ,
with 2,369 of 7,723 function-body hashes different; other section hashes agree.
Both binaries contain corresponding absolute sdk-base versus sdk-candidate Rust
file paths. This confirms a build-path difference is present, not that it explains
all code/data changes or timing. No disassembly/functional equivalence is inferred.
Same-arm engine hashes also match those in the prior historical run; that prior
run is not pooled. Prospective JS-only attribution should first qualify an
identical engine byte hash across arms (e.g. a validated identical build-root
or path-remapping strategy, or explicitly proven common fresh Rust artifact).

This is historical 9d59797 success-path evidence only. The independently
identified warmed-public-glue/memo-empty compatibility blocker remains outside
this successful cohort; corrected source needs its own controls and qualification.
This audit does not imply merge readiness, full viewer/GPU/pixel/metadata fidelity,
native speed, Windows behavior or an eight-worker result. No builds, browser runs,
model processing, WT changes, retries or threshold changes occurred in this audit.
