Hosted Linux default SDK produced CPU channels only

Status: complete-56-sample-hosted-SDK-cohort; retained 56/56 samples.



No full viewer/GPU/pixel/metadata/faithful IFC, native-speed, physical peak or universal speed claim. Complete raw diagnostics retain cache/upper-bound census limitations.

{
  "house": {
    "status": "complete-14-sample-family",
    "pairedDeltas": [
      -0.04260445064370166,
      -0.05097835583514365,
      -0.0029713488924747455,
      -0.015035989036681019,
      -0.00795768917840578
    ]
  },
  "csg": {
    "status": "complete-14-sample-family",
    "pairedDeltas": [
      0.008685352026095217,
      -0.01186767428359925,
      -0.009356116638399192,
      -0.0979325790786909,
      -0.005990188427290266
    ]
  },
  "heavy-csg": {
    "status": "complete-14-sample-family",
    "pairedDeltas": [
      -0.02186831012333257,
      -0.043165222864384956,
      -0.02275097182579433,
      -0.028885724767409693,
      -0.019355994112832953
    ]
  },
  "architecture": {
    "status": "complete-14-sample-family",
    "pairedDeltas": [
      0.012971069394108081,
      -0.0007583774857979897,
      0.007621348690243224,
      -0.004955702209490931,
      -0.008821575078530541
    ]
  }
}
