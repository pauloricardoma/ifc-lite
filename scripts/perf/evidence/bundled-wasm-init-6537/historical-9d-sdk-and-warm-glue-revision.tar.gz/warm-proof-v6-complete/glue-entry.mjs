import init, { initSync, IfcAPI } from '@ifc-lite/wasm';
export { init, IfcAPI };
export function initActualSync(module) { return initSync({ module }); }
