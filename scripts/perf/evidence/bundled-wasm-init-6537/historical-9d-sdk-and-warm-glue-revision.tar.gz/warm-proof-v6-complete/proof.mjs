import { createRequire } from 'node:module';
import { readFile, writeFile, readdir, stat } from 'node:fs/promises';
import { resolve, join, relative } from 'node:path';
import { pathToFileURL } from 'node:url';
import { createHash } from 'node:crypto';
import vm from 'node:vm';
import assert from 'node:assert/strict';
import { execFileSync } from 'node:child_process';
const root = resolve(process.env.IFC_LITE_PROOF_ROOT ?? '/home/louistrue/wt/6537-browser-init-failure-semantics-session6503');
const packet = import.meta.dirname, dist = join(packet, 'dist');
const receipt = { status: 'started', scope: 'Actual Vite/glue/real-WASM correctness only; cached artifacts, no model/worker/browser/performance run',
  command: process.argv, head: execFileSync('git', ['-C', root, 'rev-parse', 'HEAD'], { encoding: 'utf8' }).trim(),
  node: process.version, sourceInputs: {}, outputs: [], cases: [], tools: {} };
const hash = bytes => createHash('sha256').update(bytes).digest('hex');
async function input(path) { receipt.sourceInputs[path] = hash(await readFile(path)); }
async function verifyInputs() {
  for (const [path, expected] of Object.entries(receipt.sourceInputs)) assert.equal(hash(await readFile(path)), expected, `changed input ${path}`);
}
async function files(directory, depth = 0) {
  if (depth > 12) throw new Error('walk depth bound');
  const result = [];
  for (const entry of await readdir(directory, { withFileTypes: true })) {
    if (entry.isDirectory()) result.push(...await files(join(directory, entry.name), depth + 1));
    else if (entry.isFile()) result.push(join(directory, entry.name));
    else throw new Error('unsupported input/output link');
    if (result.length > 10000) throw new Error('walk count bound');
  }
  return result;
}
const origin = 'https://vm-fixture.invalid';
const native = WebAssembly;
function makeContext(label, assets, mode = 'valid') {
  const result = { label, requests: [], calls: [], modules: [], timers: [], cloneCount: 0, namespace: null };
  const transportFailure = new TypeError('Failed to fetch');
  let compileFailure, offlineAfterPublicInit = false;
  const moduleIds = new WeakMap(); let nextId = 0;
  const moduleId = module => { if (!moduleIds.has(module)) moduleIds.set(module, ++nextId); return moduleIds.get(module); };
  const observedWasm = Object.create(native);
  observedWasm.compileStreaming = async response => {
    result.calls.push({ name: 'compileStreaming' });
    try { return await native.compileStreaming(response); }
    catch (error) { compileFailure = error; throw error; }
  };
  observedWasm.compile = async bytes => { result.calls.push({ name: 'compile' }); return native.compile(bytes); };
  observedWasm.instantiate = async (value, imports) => {
    const isModule = value instanceof native.Module;
    result.calls.push({ name: 'instantiate', inputIsModule: isModule, moduleId: isModule ? moduleId(value) : null });
    if (isModule) result.modules.push(value);
    const instantiated = await native.instantiate(value, imports);
    return instantiated;
  };
  observedWasm.instantiateStreaming = async (response, imports) => {
    result.calls.push({ name: 'instantiateStreaming' });
    const instantiated = await native.instantiateStreaming(response, imports);
    return instantiated;
  };
  const context = vm.createContext({ window: {}, URL, Response, Request, TextEncoder, TextDecoder,
    console, Error, TypeError, crypto: globalThis.crypto,
    setTimeout: (callback, delay, ...args) => { result.timers.push(delay); return setTimeout(callback, delay, ...args); },
    clearTimeout, performance, WebAssembly: observedWasm,
    fetch: async value => {
      const url = String(value), parsed = new URL(url);
      assert.equal(parsed.origin, origin); const asset = assets.get(parsed.pathname);
      if (!asset) throw new Error(`unqualified request URL ${url}`);
      assert.ok(url.endsWith('.wasm'));
      const bytes = mode === 'invalid' ? Buffer.from([0, 1, 2]) : asset.bytes;
      result.requests.push({ url, bytes: bytes.length, sha256: hash(bytes), mode });
      if (result.requests.length > 10) throw new Error('request bound');
      if (offlineAfterPublicInit) throw transportFailure;
      if (mode === 'persistent' || (mode === 'transient' && result.requests.length === 1)) throw transportFailure;
      const response = new Response(bytes, { headers: { 'Content-Type': mode === 'mime' ? 'text/plain' : 'application/wasm' } });
      const originalClone = response.clone;
      response.clone = function (...args) { result.cloneCount++; return Reflect.apply(originalClone, this, args); };
      return response;
    } });
  const modules = new Map();
  async function load(url) {
    if (modules.has(url)) return modules.get(url);
    const parsed = new URL(url); assert.equal(parsed.origin, origin);
    const asset = assets.get(parsed.pathname); if (!asset || !url.endsWith('.js')) throw new Error(`unqualified JS ${url}`);
    const module = new vm.SourceTextModule(asset.bytes.toString('utf8'), { context, identifier: url,
      initializeImportMeta(meta) { meta.url = url; },
      importModuleDynamically() { throw new Error('unexpected dynamic import / Node branch'); } });
    modules.set(url, module);
    await module.link((specifier, referencing) => load(new URL(specifier, referencing.identifier).href));
    return module;
  }
  return { result, transportFailure, offline() { offlineAfterPublicInit = true; result.offlineAfterPublicInit = true; }, get compileFailure() { return compileFailure; }, async entry(name) {
    const selected = [...assets.entries()].filter(([path]) => new RegExp(`/${name}-[^/]+\\.js$`).test(path));
    assert.equal(selected.length, 1, 'unique emitted entry');
    const module = await load(origin + selected[0][0]); await module.evaluate({ timeout: 30000 });
    return module.namespace;
  } };
}
try {
  assert.equal(receipt.head, process.env.IFC_LITE_PROOF_HEAD, 'final immutable candidate head');
  assert.equal(execFileSync('git', ['-C', root, 'status', '--porcelain'], { encoding: 'utf8' }), '', 'clean source worktree');
  assert.equal(hash(await readFile(join(root, 'packages/wasm/pkg/ifc-lite.js'))), '4719403c55b6061b7ff3ba260ae45783c4db846cb70ccd70ac51d5b03d87373d', 'actual generated JS');
  assert.equal(hash(await readFile(join(root, 'packages/wasm/pkg/ifc-lite_bg.wasm'))), '7d63d9bc94333f10c4044eac3f70bd86bf361b98659ff5e6cb1161def46f597b', 'current final qualified WASM bytes');
  const require = createRequire(join(root, 'apps/viewer/package.json'));
  const tool = async name => {
    const file = require.resolve(name); receipt.tools[name] = { file, sha256: hash(await readFile(file)) };
    const imported = await import(pathToFileURL(file).href);
    if (name === 'vite') return imported;
    if (typeof imported.default === 'function') return imported.default;
    if (typeof imported.default?.default === 'function') return imported.default.default;
    throw new Error(`unsupported plugin import ${name}`);
  };
  const vite = await tool('vite'), wasm = await tool('vite-plugin-wasm'), topLevelAwait = await tool('vite-plugin-top-level-await');
  receipt.viteVersion = vite.version;
  for (const name of ['geometry', 'data', 'encoding', 'wasm-lifecycle']) {
    for (const path of await files(join(root, 'packages', name, 'src'))) await input(path);
  }
  for (const name of ['ifc-lite.js', 'ifc-lite_bg.wasm', 'ifc-lite.d.ts']) await input(join(root, 'packages/wasm/pkg', name));
  for (const name of ['bridge-entry.mjs', 'glue-entry.mjs', 'proof.mjs']) await input(join(packet, name));
  await writeFile(join(packet, 'input-freeze.json'), JSON.stringify(receipt, null, 2));
  await vite.build({ configFile: false, root: packet, publicDir: false, plugins: [wasm(), topLevelAwait()],
    resolve: { alias: [ { find: '@ifc-lite/wasm', replacement: join(root, 'packages/wasm/pkg/ifc-lite.js') },
      ...['data', 'encoding', 'wasm-lifecycle'].map(name => ({ find: `@ifc-lite/${name}`, replacement: join(root, 'packages', name, 'src/index.ts') })) ] },
    build: { target: 'esnext', outDir: dist, emptyOutDir: false,
      rollupOptions: { preserveEntrySignatures: 'strict', input: { bridge: join(packet, 'bridge-entry.mjs'), glue: join(packet, 'glue-entry.mjs') } } } });
  const assets = new Map(); let outputBytes = 0;
  for (const path of await files(dist)) {
    const bytes = await readFile(path); outputBytes += bytes.length;
    if (assets.size >= 512 || outputBytes > 64 * 1024 ** 2) throw new Error('emitted inventory bound');
    const name = '/' + relative(dist, path), sha256 = hash(bytes);
    assets.set(name, { bytes, sha256 }); receipt.outputs.push({ path: name, bytes: bytes.length, sha256 });
  }
  const wasmOutputs = receipt.outputs.filter(asset => asset.path.endsWith('.wasm'));
  assert.equal(wasmOutputs.length, 1); assert.equal(wasmOutputs[0].sha256, receipt.sourceInputs[join(root, 'packages/wasm/pkg/ifc-lite_bg.wasm')]);
  const control = makeContext('ordinary-generated-glue', assets), ordinary = await control.entry('glue');
  await ordinary.init(); const api = new ordinary.IfcAPI(); api.free();
  assert.equal(control.result.requests.length, 1); assert.equal(control.result.calls.filter(call => call.name === 'instantiateStreaming').length, 1);
  control.result.namespace = 'actual default loader/IfcAPI'; receipt.cases.push(control.result);
  for (const warmMode of ['async', 'sync']) {
    const warmed = makeContext(`public-glue-${warmMode}-then-offline-bridge`, assets);
    const publicGlue = await warmed.entry('glue');
    if (warmMode === 'async') await publicGlue.init();
    else publicGlue.initActualSync(await native.compile(assets.get(wasmOutputs[0].path).bytes));
    const earlierApi = new publicGlue.IfcAPI(); earlierApi.free();
    const expectedRequests = warmMode === 'async' ? 1 : 0;
    assert.equal(warmed.result.requests.length, expectedRequests);
    warmed.offline();
    const actual = await warmed.entry('bridge'), originals = new Map();
    for (const name of ['setMergeLayers', 'setComputeGeometryHashes', 'setTessellationQuality', 'setSkipSmallCuts', 'free']) {
      const descriptor = Object.getOwnPropertyDescriptor(actual.IfcAPI.prototype, name);
      assert.equal(typeof descriptor?.value, 'function'); originals.set(name, descriptor);
      Object.defineProperty(actual.IfcAPI.prototype, name, { ...descriptor, value: function (...args) {
        warmed.result.calls.push({ name, args }); return Reflect.apply(descriptor.value, this, args);
      } });
    }
    const bridge = new actual.IfcLiteBridge();
    try {
      bridge.setMergeLayers(true); bridge.setComputeGeometryHashes(0.25);
      bridge.setTessellationQuality('high'); bridge.setSkipSmallCuts(true);
      await bridge.init();
      assert.equal(bridge.isInitialized(), true);
      assert.equal(warmed.result.requests.length, expectedRequests, 'warm public engine must not acquire a new asset');
      assert.equal(warmed.result.calls.filter(x => x.name === 'compileStreaming' || x.name === 'compile').length, 0);
      assert.deepEqual(warmed.result.timers, []);
      assert.deepEqual(warmed.result.calls.filter(x => x.name.startsWith('set')).map(x => ({ name:x.name,args:x.args })),
        [{ name:'setMergeLayers',args:[true] }, { name:'setComputeGeometryHashes',args:[0.25] },
         { name:'setTessellationQuality',args:['high'] }, { name:'setSkipSmallCuts',args:[true] }]);
    } finally {
      bridge.dispose();
      for (const [name, descriptor] of originals) Object.defineProperty(actual.IfcAPI.prototype, name, descriptor);
    }
    assert.equal(warmed.result.calls.filter(x => x.name === 'free').length, 1);
    warmed.result.namespace = 'actual public default/initSync glue then real Bridge, memo never populated';
    receipt.cases.push(warmed.result);
  }
  for (const mode of ['valid', 'mime', 'transient', 'persistent', 'invalid']) {
  const main = makeContext(`actual-bundled-bridge-${mode}`, assets, mode), bridgeExports = await main.entry('bridge');
  const originals = new Map();
  for (const name of ['setMergeLayers', 'setComputeGeometryHashes', 'setTessellationQuality', 'setSkipSmallCuts', 'free']) {
    const descriptor = Object.getOwnPropertyDescriptor(bridgeExports.IfcAPI.prototype, name);
    assert.equal(typeof descriptor?.value, 'function'); originals.set(name, descriptor);
    Object.defineProperty(bridgeExports.IfcAPI.prototype, name, { ...descriptor, value: function (...args) {
      main.result.calls.push({ name, args }); return Reflect.apply(descriptor.value, this, args);
    } });
  }
  const bridge = new bridgeExports.IfcLiteBridge();
  bridge.setMergeLayers(true); bridge.setComputeGeometryHashes(0.25); bridge.setTessellationQuality('high'); bridge.setSkipSmallCuts(true);
  assert.equal(main.result.requests.length, 0);
  let error;
  try { await bridge.init(); } catch (failure) { error = failure; }
  if (mode === 'invalid' || mode === 'persistent') {
    assert.equal(bridge.isInitialized(), false);
    assert.equal(main.result.calls.filter(call => call.name.startsWith('set') || call.name.startsWith('instantiate')).length, 0);
    if (mode === 'invalid') {
      assert.ok(error instanceof native.CompileError); assert.equal(error, main.compileFailure);
      assert.equal(main.result.requests.length, 1); assert.deepEqual(main.result.timers, []);
    } else {
      assert.ok(error instanceof Error); assert.equal(error.cause, main.transportFailure);
      assert.equal(main.result.requests.length, 2); assert.deepEqual(main.result.timers, [300]);
    }
    main.result.failure = { name: error.name, message: error.message, cause: error.cause?.message,
      originalIdentityVerified: mode === 'invalid' ? error === main.compileFailure : error.cause === main.transportFailure };
    bridge.dispose(); assert.equal(main.result.calls.filter(call => call.name === 'free').length, 0);
  } else {
    if (error) throw error;
    assert.equal(bridge.isInitialized(), true);
    const expectedRequests = mode === 'transient' ? 2 : 1;
    assert.equal(main.result.requests.length, expectedRequests);
    assert.equal(main.result.requests.at(-1).url, control.result.requests[0].url);
    assert.equal(main.result.calls.filter(call => call.name === 'compileStreaming').length, 1);
    assert.equal(main.result.calls.filter(call => call.name === 'instantiateStreaming').length, 0);
    assert.equal(main.result.modules.length, 1);
    const module = await bridgeExports.compileSharedWasmModule();
    assert.equal(module, main.result.modules[0]); assert.equal(main.result.requests.length, expectedRequests);
    assert.deepEqual(main.result.timers, mode === 'transient' ? [300] : []);
    assert.deepEqual(main.result.calls.filter(call => call.name.startsWith('set')).map(call => ({ name: call.name, args: call.args })),
      [{ name: 'setMergeLayers', args: [true] }, { name: 'setComputeGeometryHashes', args: [0.25] },
        { name: 'setTessellationQuality', args: ['high'] }, { name: 'setSkipSmallCuts', args: [true] }]);
    bridge.dispose(); assert.equal(main.result.calls.at(-1).name, 'free');
    main.result.moduleIdentityVerified = true;
  }
  assert.equal(main.result.cloneCount, 0);
  for (const [name, descriptor] of originals) Object.defineProperty(bridgeExports.IfcAPI.prototype, name, descriptor);
  main.result.namespace = 'actual Bridge and canonical default pool memo acquisition'; receipt.cases.push(main.result);
  }
  for (const result of receipt.cases) delete result.modules;
  await verifyInputs();
  for (const asset of receipt.outputs) assert.equal(hash(await readFile(join(dist, asset.path.slice(1)))), asset.sha256);
  assert.equal(execFileSync('git', ['-C', root, 'rev-parse', 'HEAD'], { encoding: 'utf8' }).trim(), receipt.head);
  assert.equal(execFileSync('git', ['-C', root, 'status', '--porcelain'], { encoding: 'utf8' }), '');
  receipt.finalInvariance = 'complete'; receipt.status = 'complete-vite-glue-vm-correctness';
} catch (error) { receipt.status = 'refused'; receipt.reason = String(error); receipt.stack = error.stack; process.exitCode = 1; }
finally { await writeFile(join(packet, 'receipt.json'), JSON.stringify(receipt, null, 2)); }
console.log(JSON.stringify({ status: receipt.status, reason: receipt.reason, sourceFiles: Object.keys(receipt.sourceInputs).length,
  emittedFiles: receipt.outputs.length, cases: receipt.cases.map(item => ({ label: item.label, requests: item.requests, calls: item.calls })) }, null, 2));
