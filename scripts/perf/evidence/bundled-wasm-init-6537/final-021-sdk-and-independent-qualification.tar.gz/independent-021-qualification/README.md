# Final corrected-source SDK qualification

Run [37155827255](https://github.com/LTplus-AG/ifc-lite/actions/runs/37155827255), attempt 1, completed SUCCESS at 2026-10-03T22:14:30Z. Controller `4d47506a23e304ed4b772f7890e27e37843e8914`; BASE `c61932d4a9d85efe1b0f817a5274a115f0571ee3`; CAND `02112298d6cc690cda6fa3db712b524abc0f4712`.

All 56 samples/28 pairs remain, with two preceding A/A controls and five alternating A/B pairs per family. All eight A/A controls pass (largest absolute difference 8.688%). All produced flat/instanced CPU-channel identities, counts, coordinate information and full unnormalized diagnostics agree within each family. Default runtime reports two workers IDs0/1 on four cores with SAB/COI and no overrides. Cold processor.init, canonical processParallel drain, retention and dispose are timed; hashing follows the timer. No renderer, GPU, full metadata or faithful-IFC identity is implied.

The independently adapted retained-receipt/asset audit passes 1508 checks. Full tracked source hashes are independently verified from immutable Git objects: 13271 controller,13501 BASE,13506 CAND files. Full Git and declared-closure audit passes59242 checks. All762 normalized installed dependency entries agree. Every declared tool/package closure file has a frozen hash, and producing/root task receipts, transform identity and final freeze are consistent. Remote installed tool/sysroot/cargo-registry paths are producer receipts, not independently rehashed after runner teardown; original closure-completeness limitations remain.

All168 raw CPU intervals pass: minimum monotonic duration1,000,061,771ns, maximum busy5.013%. Initial available memory15,479,267,328B; minimum sampled live availability12,612,157,440B; maximum sampled owned RSS3,756,318,720B (not physical peak). Cleanup witnesses597 owned processes,0remaining/0zombies; both servers close with0sockets/faults; final input verification completes. No rerun, replacement, pooling, trimming or normalization occurred.

Candidate-minus-baseline paired elapsed deltas; negative means less elapsed:

| Family | All five paired deltas (%) | Paired median (%) | Paired range (%) | BASE AB median/range (ms) | CAND AB median/range (ms) |
| --- | --- | --- | --- | --- | --- |
| house | -18.333, -19.709, -10.625, -6.297, -8.934 | -10.625 | [-19.709, -6.297] | 496.660 / [475.155, 572.905] | 443.420 / [409.060, 465.385] |
| csg | +0.251, -0.238, +0.136, -0.929, +0.692 | +0.136 | [-0.929, +0.692] | 4376.225 / [4335.595, 4390.815] | 4365.590 / [4330.195, 4400.740] |
| heavy-csg | -1.823, -3.101, -2.756, -1.660, -3.851 | -2.756 | [-3.851, -1.660] | 4414.575 / [4376.450, 4445.540] | 4295.210 / [4274.360, 4314.205] |
| architecture | +0.152, -1.639, -1.163, -3.616, -2.020 | -1.639 | [-3.616, +0.152] | 3652.410 / [3631.660, 3740.830] | 3606.115 / [3592.550, 3637.195] |

Haus and Holter are faster in all five pairs; CSG is mixed near zero, and architecture contains one slower pair. These are observed SDK results, not a universal benefit. Haus's high572.905ms baseline remains paired with459.990ms candidate; architecture's3740.830ms baseline remains too. Their arithmetic effects are visible; no physical cause or statistical-outlier classification is inferred.

Every BASE sample captures two WASM requests/responses/finished; every CAND captures one. These browser counts are during the SDK geometry-and-posthash phase; immutable-origin runner refetches are outside them. Counts do not prove wire bytes or isolate compilation time.

Both arms genuinely build six fresh serial root Turbo tasks before any model. Engine hashes are BASE `8bece54c2d089bbec7ff0ce6fc00aee96edc7bdefd70eea60b5ccb7f8b1046c9`, CAND `0830c2d293f1d215138d0553e3d00718ffba75c860daab27ba72dc080ed25c73`. Each equals its same-arm historical9d artifact, but BASE versus CAND code/data differ:2369 of7723 indexed function-body hashes differ. Captured Rust/config hashes agree. Retained binary source paths establish a present build-path confound, not that it explains every byte or elapsed difference. No isolated-JavaScript timing causality is claimed.

Raw output arrays are not uploaded: CPU digests are observed post-timing witnesses, not independently regenerated meshes. Separate corrected-source V6 actual-generated-glue proof covers cold/warm async/initSync, MIME, retry, persistent/fatal causes and API config/free; this SDK cohort does not substitute for those controls. Historical9d audits remain unchanged.

Files: `qualification.json` holds every numeric/identity gate and statistic; `git-and-closure-attachment.json` records full tracked Git checks and declared closure pins; `wasm-section-comparison.json` retains complete section/body byte records; `wasm-fetches.json` retains each actual request timeline; `artifact-hashes.json` hashes every uploaded member. The NEW raw packet is `/tmp/6232-takeover/6537-browser-init-sdk-remote-v3/` with run metadata, job log, original artifact ZIP and complete extracted250members. Official uploaded ZIP digest matches `2ec85963c5c69773a014c6f4325cfde0c5c9c5cfe9f43b4b7b21ab78cc134810` and every member byte agrees with the downloaded files.

The first adapted audit stopped on a schema assumption (slot is in sample id, not a separate field); `audit-initial-schema.stderr` preserves it. Corrected adapter verifies exact ordered ids/families/pairs/kinds/arms. This was an audit failure, not a model/run refusal. Some earlier status API requests timed out; their raw observations remain. All read commands were bounded; no source edits, build, browser/model run, rerun, push or merge occurred.
