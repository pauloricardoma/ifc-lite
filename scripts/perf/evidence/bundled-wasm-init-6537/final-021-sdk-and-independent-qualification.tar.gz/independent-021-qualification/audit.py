from pathlib import Path
import json,hashlib,statistics,re,datetime
src=Path('/tmp/6232-takeover/6537-browser-init-sdk-remote-v3/artifacts/sdk-worker-37155827255-1')
out=Path(__file__).resolve().parent
read=lambda p:json.loads(p.read_text())
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
r=read(src/'report.json');p=read(src/'provenance.json');start=read(src/'build-start.json')
checks=[]
def check(ok,label): checks.append({'label':label,'passed':bool(ok)})
remote=read(Path('/tmp/6232-takeover/6537-browser-init-sdk-remote-v3/run.json'))
check(remote['status']=='completed' and remote['conclusion']=='success' and remote['headSha']=='4d47506a23e304ed4b772f7890e27e37843e8914','actual terminal workflow controller SUCCESS')
check(r['status']=='complete-56-sample-hosted-SDK-cohort' and len(r['samples'])==56 and len(r['pairs'])==28,'finite terminal56samples28pairs')
plannedSamples=[];plannedPairs=[]
for family in ['house','csg','heavy-csg','architecture']:
 for pair in range(7):
  kind='AA' if pair<2 else 'AB'
  order=['base','base'] if pair<2 else (['candidate','base'] if pair%2 else ['base','candidate'])
  plannedPairs.append({'family':family,'index':pair,'kind':kind})
  for slot,arm in enumerate(order):plannedSamples.append({'id':f'{family}-{pair}-{slot}-{arm}','family':family,'pair':pair,'kind':kind,'arm':arm})
check([{key:s[key] for key in plannedSamples[0]} for s in r['samples']]==plannedSamples,'exact complete global fixed sample schedule')
check([{key:q[key] for key in plannedPairs[0]} for q in r['pairs']]==plannedPairs,'exact complete global fixed pair schedule')
expected={'base':'c61932d4a9d85efe1b0f817a5274a115f0571ee3','candidate':'02112298d6cc690cda6fa3db712b524abc0f4712'}
check(p['revisions']==start['revisions']==expected,'literal immutable subjects')
check(p['sources']==start['sources'],'source snapshots identical prebuild and final provenance')
check(len(p['sources'])==3 and [x['head'] for x in p['sources']]==[p['harnessHead'],expected['base'],expected['candidate']],'three exact source snapshot heads')
check(all(p['frozenFiles'].get(k)==v for k,v in start['frozenFiles'].items()),'prebuild tool/input pins preserved through final provenance')
builds={}
for arm,head in expected.items():
 b=read(src/f'{arm}-source-build.json'); raw=(src/f'{arm}-source-build.log').read_text()
 check(b['status']=='complete-source-build' and b['exit']==0 and b['revision']==head and b==p['builds'][arm]['sourceBuild'],'actual producing receipt complete and matches frozen build')
 check(sha(src/f'{arm}-source-build.log')==b['logSha256'],'actual build log SHA '+arm)
 check(b['cleanup']['status']=='complete' and not b['cleanup']['remaining'] and b['logFlush']['status']=='complete','build cleanup/flush '+arm)
 groups=re.findall(r'^::group::([^\n]+):build\n(.*?)^::endgroup::$',raw,re.M|re.S)
 check(len(groups)==6 and len(set(x[0] for x in groups))==6 and all(len(re.findall(r'^cache (?:bypass, force executing|miss, executing) [a-f0-9]+$',body,re.M))==1 for name,body in groups),'all six closed unique actual fresh groups '+arm)
 check(all(any(name=='@ifc-lite/'+need for name,body in groups) for need in ['geometry','data','encoding','wasm-lifecycle','wasm']) and any(name=='@ifc-lite/wasm' and re.search(r'^✨ Build complete!$',body,re.M) for name,body in groups),'mandatory SDK owners and actual WASM completion '+arm)
 check(re.search(r'Tasks:\s+6 successful,\s+6 total',raw) and re.search(r'Cached:\s+0 cached,\s+6 total',raw),'actual task aggregate6fresh '+arm)
 check(b['transformBefore']==b['transformAfter'],'actual transform prepost exact '+arm)
 check(b['command']==['pnpm','turbo','build','--force','--filter=@ifc-lite/geometry','--concurrency=1','--env-mode=loose'],'actual root build command '+arm)
 check(b['startedUTC']>=start['environment'].get('irrelevant','') and datetime.datetime.fromisoformat(b['startedUTC'].replace('Z','+00:00')).timestamp()*1000>=start['timestampMs'],'build starts after source freeze '+arm)
 for a in p['builds'][arm]['assets']:
  f=src/(arm+'-endpoint')/a['path'];check(f.stat().st_size==a['size'] and sha(f)==a['sha256'],'all emitted asset bytes '+arm+'/'+a['path'])
 wasm=[a for a in p['builds'][arm]['assets'] if a['path'].endswith('.wasm')]
 check(len(wasm)==1 and wasm[0]['sha256']==b['wasmSha256']==p['builds'][arm]['wasmSha256'] and wasm[0]['size']==b['wasmBytes'],'produced-to-served WASM exact '+arm)
 for name in [f'{arm}-source-build.json',f'{arm}-source-build.log']:
  pin=next(v for k,v in p['frozenFiles'].items() if k.endswith('/'+name));check(pin==sha(src/name),'frozen producing receipt/log '+name)
 builds[arm]={key:b[key] for key in ['revision','status','startedUTC','endedUTC','logSha256','wasmSha256','wasmBytes','taskOutcomes','cleanup','logFlush']}
check(builds['base']['endedUTC']<builds['candidate']['startedUTC']<min(s['preparedUTC'] for s in r['samples']),'serial builds complete before any model prepare')
check(r['initialResource']['availableBytes']>=8*1024**3,'initial8GiB reserve')
check(r['finalInputVerification']=='complete' and r['ownedCleanup']['status']=='complete' and not r['ownedCleanup']['remaining'] and r['ownedCleanup']['zombies']==0,'final frozen input and owned cleanup receipt')
check(len(r['serverCleanup'])==2 and all(c['status']=='complete' and c['remainingSockets']==0 and not c['serverFault'] for c in r['serverCleanup']),'both servers closed with zero sockets/faults')
check(len(r['resourceSamples'])<=250000 and all(x['bytes']<=5*1024**3 and x['availableBytes']>=4*1024**3 for x in r['resourceSamples']),'all sampled5GiBownedRSS/4GiBlive bounds')
intervals=[];aa=[];stats={}
for family in ['house','csg','heavy-csg','architecture']:
 samples=[s for s in r['samples'] if s['family']==family];pairs=[q for q in r['pairs'] if q['family']==family]
 check(len(samples)==14 and len(pairs)==7 and [q['kind'] for q in pairs]==['AA','AA']+['AB']*5 and [q['index'] for q in pairs]==list(range(7)),'fixed2AAthen5AB '+family)
 witness=samples[0]
 check(all(s['receipt']['identity']==witness['receipt']['identity'] and s['receipt']['complete']['diagnostics']==witness['receipt']['complete']['diagnostics'] for s in samples),'unnormalized full diagnostics and CPU identity14rows '+family)
 check(all(s['receipt']['complete']['totalMeshes']==witness['receipt']['complete']['totalMeshes'] for s in samples),'complete mesh counts14rows '+family)
 check(all(s['receipt']['complete']['coordinateInfo']==witness['receipt']['complete']['coordinateInfo'] for s in samples),'complete coordinate frame14rows '+family)
 check(all(s['runtime']==witness['runtime'] and s['workerIds']==witness['workerIds'] and s['workerCount']==witness['workerCount'] for s in samples),'default runtime/pool config14rows '+family)
 deltas=[];abbase=[];abcand=[]
 for index,q in enumerate(pairs):
  rows=[s for s in samples if s['pair']==index];order=['base','base'] if index<2 else (['candidate','base'] if index%2 else ['base','candidate'])
  check(q['status']=='complete' and [s['arm'] for s in rows]==order,'complete declared pair '+family+'/'+str(index))
  values=[s['receipt']['elapsedMs'] for s in rows]
  check(q['comparison']['milliseconds']==values,'actual pair elapsed receipts '+family+'/'+str(index))
  if index<2:
   d=100*(values[1]/values[0]-1);aa.append({'family':family,'pair':index,'deltaPercent':d});check(abs(d)<=10,'AA10percent '+family+'/'+str(index))
  else:
   b=next(s['receipt']['elapsedMs'] for s in rows if s['arm']=='base');c=next(s['receipt']['elapsedMs'] for s in rows if s['arm']=='candidate')
   delta=100*(c/b-1);deltas.append(delta);abbase.append(b);abcand.append(c);check(abs(q['comparison']['relativeDelta']*100-delta)<1e-10,'paired recomputed AB delta '+family+'/'+str(index))
  for stage in ['beforeCPU','afterCPU']:
   cpu=q[stage];check(not cpu['before']['active'] and not cpu['after']['active'] and len(cpu['rows'])==4,'quiet rawCPU/graph shape '+family+'/'+str(index)+'/'+stage)
   for row in cpu['rows']:
    ticks=list(map(int,row['raw'].split()[1:9]));check(sum(ticks)==int(row['total']) and ticks[3]+ticks[4]==int(row['idle']),'raw CPU tick identity')
   for k,record in enumerate(cpu['intervals']):
    lo,hi=cpu['rows'][k:k+2];ns=int(hi['monotonicNs'])-int(lo['monotonicNs']);total=int(hi['total'])-int(lo['total']);idle=int(hi['idle'])-int(lo['idle']);busy=100*(1-idle/total)
    check(ns>=1000000000 and total>0 and 0<=idle<=total and idle*10>=total*9 and record['eligible'] and str(ns)==record['elapsedNs'] and str(total)==record['totalTicks'] and str(idle)==record['idleTicks'] and abs(busy-record['cpuPercent'])<1e-10,'independent actual CPU interval gate')
    intervals.append({'family':family,'pair':index,'stage':stage,'elapsedNs':ns,'busyPercent':busy,'rawRecord':record})
 def distribution(values):
  median=statistics.median(values);return {'rawMilliseconds':values,'medianMs':median,'rangeMs':[min(values),max(values)],'rangeOverMedianPercent':100*(max(values)-min(values))/median}
 stats[family]={'pairedABPercentDeltas':deltas,'pairedABMedianPercent':statistics.median(deltas),'pairedABRangePercent':[min(deltas),max(deltas)],'ABBase':distribution(abbase),'ABCandidate':distribution(abcand),'all9Base':distribution([s['receipt']['elapsedMs'] for s in samples if s['arm']=='base']), 'identity':witness['receipt']['identity'],'diagnostics':witness['receipt']['complete']['diagnostics'],'runtime':witness['runtime'],'workerCount':witness['workerCount'],'workerIds':witness['workerIds']}
for s in r['samples']:
 check(read(src/(s['id']+'.json'))==s,'sample artifact equals report '+s['id'])
 receipt=s['receipt'];check(s['status']=='complete' and receipt['status']=='supported-output' and receipt['generatorDone'] and receipt['processorDisposed'] and receipt['eventCounts']['complete']==1 and 'skippedHungElements' not in receipt['complete'] and receipt['complete']['coordinateInfo']['boundsRecoveryFallbackCount']==0,'complete untouched stream '+s['id'])
 check(receipt['elapsedMs']>0 and receipt['elapsedMs']<=s['timeoutMs']+30000 and receipt['retainedBytes']<=2*1024**3 and receipt['bufferCount']<=500000 and receipt['events']<=250000 and receipt['hashMs']<=120000,'sample time/retention/hash bounds '+s['id'])
 check(s['runtime']['sab'] and s['runtime']['crossOriginIsolated'] and not s['runtime']['overrides'] and s['workerCount']>=2 and s['workerIds']==list(range(s['workerCount'])) and sorted(x['workerIndex'] for x in receipt['workerMemory'])==s['workerIds'],'actual unmodified default pool census '+s['id'])
 check(s['teardown']=='complete' and s['exit']['code']==0 and s['cleanup']['status']=='complete' and not s['cleanup']['remaining'] and s['cleanup']['zombies']==0 and s['logFlush']['status']=='complete' and s['pipeTailCertified'] and not s['errors'],'sample exit/cleanup/flush/errors '+s['id'])
 check(s['preparedUTC']<s['drainedUTC'] and sha(src/(s['id']+'.json.pre-teardown.json'))==s['preTeardown']['sha256'],'preteardown capture hash/time '+s['id'])
 assets={a['path']:a for a in p['builds'][s['arm']]['assets']}
 check(len(s['responseIdentity'])==3 and all(assets[x['path']]['sha256']==x['sha256'] and assets[x['path']]['size']==x['bytes'] and x['requestFinishedCount']>=1 for x in s['responseIdentity']),'observed URL plus origin-refetch identity3 '+s['id'])
 check(all(x['status']==200 for x in s['responses']),'observed network statuses '+s['id'])
for arm in ['base','candidate']:
 served=read(src/f'{arm}.served-assets.json');assets={x['path']:x for x in p['builds'][arm]['assets']}
 check(all(x['status']==200 and x['sha256']==assets[x['path']]['sha256'] for x in served),'all frozen-origin served responses '+arm)
check(len(intervals)==168,'exact168 independent CPU intervals')
check(p['harnessHead']=='4d47506a23e304ed4b772f7890e27e37843e8914','literal frozen controller')
for key in ['automation','compiler','bindgen','transform','pnpmSelection','closures','environment']:
 check(p[key]==start[key], 'prebuild/final closed tool/source metadata '+key)
fetches=[]
for sample in r['samples']:
 inp=read(src/(sample['id']+'.input.json')); pre=read(src/(sample['id']+'.json.pre-teardown.json'))
 check(all(inp['sample'][key]==sample[key] for key in inp['sample']), 'literal sample input '+sample['id'])
 check(inp['assets']==p['builds'][sample['arm']]['assets'], 'sample frozen assets '+sample['id'])
 fixture=next(item for item in p['fixtures'] if item['family']==sample['family'])
 check(all(sample[key]==fixture[key] for key in ['path','bytes','sha256','timeoutMs']), 'pinned public fixture '+sample['id'])
 check(pre['status']=='pending-cleanup' and not pre['errors'] and pre['logs']==sample['logs'] and pre['responses']==sample['responses'], 'actual before-close complete snapshot '+sample['id'])
 check(sample['preparedUTC'] < sample['drainedUTC'] < pre['capturedUTC'], 'prepare/drain/preclose boundaries '+sample['id'])
 origin=inp['origin']
 asset=next(item for item in inp['assets'] if item['path'].endswith('.wasm')); url=origin+'/'+asset['path']
 req=[item for item in sample['requests'] if item['url']==url]
 res=[item for item in sample['responses'] if item['url']==url]
 done=[item for item in sample['requestFinished'] if item['url']==url]
 observed=next(item for item in sample['responseIdentity'] if item['path']==asset['path'])
 expectedCount=2 if sample['arm']=='base' else 1
 check(len(req)==len(res)==len(done)==observed['requestFinishedCount']==expectedCount,'exact per-sample wasm requests/responses/finished '+sample['id'])
 check(all(item['phase']=='geometry-and-posthash' for item in req+res+done),'WASM fetches occur within SDK run capture phase '+sample['id'])
 check(all(item['at']>=int(datetime.datetime.fromisoformat(sample['preparedUTC'].replace('Z','+00:00')).timestamp()*1000)-1 for item in req+res+done),'no WASM fetch during prepare/load '+sample['id'])
 fetches.append({'id':sample['id'],'arm':sample['arm'],'requests':req,'responses':res,'finished':done,'frozenAssetBytes':asset['size'],'frozenAssetSHA256':asset['sha256'], 'counts':{'requests':len(req),'responses':len(res),'finished':len(done)}})
check(len({(s['initialOwnedSnapshot']['members'][0]['pid'],s['initialOwnedSnapshot']['members'][0]['startTime']) for s in r['samples']})==56,'56 unique actual owned sample process identities')
check(all(s['runtime']['hardwareConcurrency']>=2 and s['workerCount']>=2 and not s['runtime']['overrides'] for s in r['samples']),'all56 actual positive default pool/runtime; no fixed-worker override claim')
(out/'wasm-fetches.json').write_text(json.dumps({'scope':'Browser captured SDK-run geometry-and-posthash phase includes cold processor.init+default processParallel and post-timing CPU hash. Origin refetch is performed in runner after drain and is outside browser event records. Fetch counts are not independent main-init/geometry subphase durations or physical wire-byte measurements.','rows':fetches},indent=2)+'\n')


def relativeSnapshot(source):
 return {path.removeprefix(source['directory']+'/'):digest for path,digest in source['files'].items()}
sourceBase,sourceCandidate=map(relativeSnapshot,p['sources'][1:])
sourceKeys=set(sourceBase)|set(sourceCandidate)
sourceEquality={'sourceFileChanges':[path for path in sorted(sourceKeys) if sourceBase.get(path)!=sourceCandidate.get(path)],
 'rustSourceFiles':len([path for path in sourceBase if path.startswith('rust/')]),
 'rustSourceEqual':all(sourceBase.get(path)==sourceCandidate.get(path) for path in sourceKeys if path.startswith('rust/')),
 'cargoAndConfigEqual':all(sourceBase.get(path)==sourceCandidate.get(path) for path in sourceKeys if path in ['Cargo.toml','Cargo.lock','rust-toolchain.toml','.cargo/config.toml']),
 'wasmHashes':{arm:p['builds'][arm]['wasmSha256'] for arm in ['base','candidate']},
 'scope':'Captured source snapshot equality; emitted WASM code/data differ despite unchanged Rust/config source. Cause not established by this artifact audit; outputs compared via observed CPU-channel digest only.'}
(out/'rust-source-and-wasm-scope.json').write_text(json.dumps(sourceEquality,indent=2)+'\n')
result={'status':'PASS_RETAINED_RECEIPT_AND_ARTIFACT_AUDIT' if all(c['passed'] for c in checks) else 'AUDIT_FINDINGS','artifactDirectory':str(src),'capturedUTC':datetime.datetime.now(datetime.timezone.utc).isoformat(),'subjects':expected,'harnessHead':p['harnessHead'],'builds':builds,'checks':checks,'failedChecks':[c for c in checks if not c['passed']],'sampleCount':56,'pairCount':28,'AAControls':aa,'statistics':stats,'CPU':{'count':len(intervals),'minElapsedNs':min(x['elapsedNs'] for x in intervals),'maxBusyPercent':max(x['busyPercent'] for x in intervals),'intervals':intervals},'resources':{'sampleCount':len(r['resourceSamples']),'initialAvailableBytes':r['initialResource']['availableBytes'],'minLiveAvailableBytes':min(x['availableBytes'] for x in r['resourceSamples']),'maxSampledOwnedRSSBytes':max(x['bytes'] for x in r['resourceSamples']),'maxRetainedBytes':max(s['receipt']['retainedBytes'] for s in r['samples'])},'cleanup':{'owned':r['ownedCleanup'],'servers':r['serverCleanup'],'finalInputVerification':r['finalInputVerification']},'wasmArtifactIdentityLimitation':sourceEquality, 'candidateScope':'Corrected 02112298 SDK success-path cohort; separate V6 real generated-glue proof covers cold/warm/retry/failure behavior. SDK produced CPU channels only, not full-viewer fidelity.', 'limits':'Audit recomputes artifact hashes, full unnormalized diagnostic/identity receipt equality, numeric gates and statistics. Remote source/tool final verification is a retained runtime receipt; those remote paths cannot be rehashed after runner teardown. Raw geometry arrays are not archived, so output SHA is compared as observed post-timing CPU-channel identity, not independently rehashed. No native/full-viewer/GPU/full metadata/faithful-IFC/physical peak/universal claim. No dropped samples or prior refusals pooled.'}
(out/'qualification.json').write_text(json.dumps(result,indent=2)+'\n')
manifest={str(f.relative_to(src)):{'bytes':f.stat().st_size,'sha256':sha(f)} for f in sorted(src.rglob('*')) if f.is_file()}
(out/'artifact-hashes.json').write_text(json.dumps(manifest,indent=2)+'\n')
print(json.dumps({'status':result['status'],'checks':len(checks),'failedChecks':result['failedChecks'],'CPU':{k:v for k,v in result['CPU'].items() if k!='intervals'},'resources':result['resources'],'statistics':{family:{k:v for k,v in data.items() if k not in ['diagnostics','identity','runtime']} for family,data in stats.items()},'qualificationSHA256':sha(out/'qualification.json'),'artifactManifestSHA256':sha(out/'artifact-hashes.json')},indent=2))
