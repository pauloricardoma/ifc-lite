from pathlib import Path, PurePosixPath
import json, subprocess, hashlib, posixpath
out=Path(__file__).resolve().parent
src=Path('/tmp/6232-takeover/6537-browser-init-sdk-remote-v3/artifacts/sdk-worker-37155827255-1')
repo='/home/louistrue/wt/6537-browser-init-failure-semantics-session6503'
provenance=json.loads((src/'provenance.json').read_text())
sha=lambda b:hashlib.sha256(b).hexdigest()
checks=[]
def check(ok,label):checks.append({'label':label,'passed':bool(ok)})
def git(*args):return subprocess.check_output(['git','-C',repo,*args],timeout=30)
all_trees=[]; all_blobs=set()
for snapshot in provenance['sources']:
 check(git('rev-parse',snapshot['head']+'^{tree}').decode().strip()==snapshot['tree'],'exact source tree '+snapshot['head'])
 tree={}
 for row in git('ls-tree','-r','-z',snapshot['head']).split(b'\0'):
  if not row:continue
  metadata,name=row.split(b'\t',1);mode,kind,blob=metadata.decode().split()
  if kind!='blob':raise ValueError('unsupported Git entry')
  tree[name.decode()]={'mode':mode,'blob':blob}; all_blobs.add(blob)
 all_trees.append((snapshot,tree))
# Read immutable object bytes once; no checkout mutation, build, model or remote filesystem access.
raw=subprocess.run(['git','-C',repo,'cat-file','--batch'],input=('\n'.join(sorted(all_blobs))+'\n').encode(),stdout=subprocess.PIPE,check=True,timeout=30).stdout
cursor=0; digests={}; links={}
while cursor<len(raw):
 end=raw.index(b'\n',cursor); blob,kind,size=raw[cursor:end].decode().split();size=int(size);cursor=end+1
 if kind!='blob':raise ValueError('missing/nonblob object')
 data=raw[cursor:cursor+size];cursor+=size
 if raw[cursor:cursor+1]!=b'\n':raise ValueError('invalid Git object frame')
 cursor+=1
 check(hashlib.sha1(b'blob '+str(size).encode()+b'\0'+data).hexdigest()==blob,'Git blob identity '+blob)
 digests[blob]=sha(data)
 if len(data)<4096:links[blob]=data
counts=[]
for snapshot,tree in all_trees:
 relative={path.removeprefix(snapshot['directory']+'/'):digest for path,digest in snapshot['files'].items()}
 check(set(relative)==set(tree),'complete tracked source census '+snapshot['head'])
 for name,row in tree.items():
  expected=digests[row['blob']]
  if row['mode']=='120000':
   target=links[row['blob']].decode();check(snapshot['links'].get(snapshot['directory']+'/'+name)==target,'Git source link '+snapshot['head']+'/'+name)
   resolved=name
   for depth in range(16):
    entry=tree[resolved]
    if entry['mode']!='120000':expected=digests[entry['blob']];break
    resolved=posixpath.normpath(posixpath.join(posixpath.dirname(resolved),links[entry['blob']].decode()))
    if resolved.startswith('../') or resolved.startswith('/'):raise ValueError('external source symlink cannot independently qualify')
   else:raise ValueError('source symlink depth bound')
  check(relative.get(name)==expected,'full Git source SHA '+snapshot['head']+'/'+name)
 counts.append({'head':snapshot['head'],'files':len(tree),'links':sum(row['mode']=='120000' for row in tree.values())})
check(provenance['closures']['base']['normalized']==provenance['closures']['candidate']['normalized'],'all normalized installed dependency closure entries equal')
for label, closure in [('automation', provenance['automation']), ('compiler', provenance['compiler']), ('bindgen', provenance['bindgen']), ('pnpmSelection', provenance['pnpmSelection']), *[(arm+'-installed', provenance['closures'][arm]) for arm in ['base','candidate']]]:
 for file, digest in closure.get('files',{}).items():
  check(provenance['frozenFiles'].get(file)==digest,'declared closure file pinned '+label+'/'+file)
check(provenance['transform']['sha256']==provenance['frozenFiles'].get(provenance['transform']['executable']),'actual producing wasm-bindgen executable pinned')
for key in ['automation','compiler','bindgen','transform','pnpmSelection']:
 check(provenance[key]==json.loads((src/'build-start.json').read_text())[key],'producer pre/post '+key)
attachment={'status':'PASS_FULL_GIT_SOURCE_AND_RETAINED_CLOSURE_AUDIT' if all(c['passed'] for c in checks) else 'AUDIT_FINDINGS','sources':counts,'uniqueGitBlobs':len(all_blobs),'checks':checks,'failedChecks':[c for c in checks if not c['passed']],'scope':'All tracked source files independently rehashed from immutable Git objects, including symlink targets; installed closure equality and pre/post tool metadata checked. Remote installed files/compiler/sysroot/cargo-registry paths cannot be rehashed after runner teardown; closure completeness retains producer-declared limitations.'}
(out/'git-and-closure-attachment.json').write_text(json.dumps(attachment,indent=2)+'\n')

def unsigned(data,at):
 value=0
 for i in range(5):
  byte=data[at];at+=1;value|=(byte&127)<<(7*i)
  if not byte&128:return value,at
 raise ValueError('invalid varuint32')
def sections(data):
 if data[:8]!=b'\0asm\x01\0\0\0':raise ValueError('WASM header')
 at=8;result=[];bodies=[]
 while at<len(data):
  sid=data[at];at+=1;n,at=unsigned(data,at);payload=data[at:at+n]
  if len(payload)!=n:raise ValueError('truncated section')
  result.append({'id':sid,'offset':at,'bytes':n,'sha256':sha(payload)})
  if sid==10:
   count,k=unsigned(payload,0)
   for index in range(count):
    length,k=unsigned(payload,k);body=payload[k:k+length]
    if len(body)!=length:raise ValueError('truncated body')
    bodies.append({'bodyIndex':index,'bytes':length,'sha256':sha(body)});k+=length
   if k!=len(payload):raise ValueError('code section census mismatch')
  at+=n
 return result,bodies
engines={}
for arm in ['base','candidate']:
 assets=provenance['builds'][arm]['assets'];asset=next(a for a in assets if a['path'].endswith('.wasm'))
 data=(src/(arm+'-endpoint')/asset['path']).read_bytes()
 if sha(data)!=asset['sha256'] or len(data)!=asset['size']:raise ValueError('WASM asset mismatch')
 sec,bodies=sections(data)
 paths=sorted(set(s.decode('ascii') for s in __import__('re').findall(rb'/home/runner/[^\x00-\x20\x7f-\xff]{1,400}\.rs',data)))
 engines[arm]={'sha256':sha(data),'bytes':len(data),'sections':sec,'functionBodies':bodies,'absoluteRustPaths':paths}
a=engines['base']['functionBodies'];b=engines['candidate']['functionBodies']
comparison={'scope':'Binary section/body byte comparison only, not disassembly, semantic equivalence or causal attribution. Absolute source paths establish a present build-path difference, not the cause of every changed byte or elapsed delta.','engines':engines,'functionBodyCounts':[len(a),len(b)],'differentBodyHashesAtSameIndex':sum(x['sha256']!=y['sha256'] for x,y in zip(a,b)),'sameBinaryBytes':engines['base']['sha256']==engines['candidate']['sha256']}
(out/'wasm-section-comparison.json').write_text(json.dumps(comparison,indent=2)+'\n')
print(json.dumps({'status':attachment['status'],'checks':len(checks),'sourceCounts':counts,'failedChecks':attachment['failedChecks'],'closureEntries':len(provenance['closures']['base']['normalized']),'wasmHashes':{k:v['sha256'] for k,v in engines.items()},'sameWASM':comparison['sameBinaryBytes'],'differentBodyHashes':comparison['differentBodyHashesAtSameIndex'],'bodyCounts':comparison['functionBodyCounts']},indent=2))
