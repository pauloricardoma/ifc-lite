from pathlib import Path
import json,hashlib,datetime
p=Path(__file__).resolve().parent;remote=Path('/tmp/6232-takeover/6537-browser-init-sdk-remote-v3')
read=lambda f:json.loads(f.read_text())
sha=lambda f:hashlib.sha256(f.read_bytes()).hexdigest()
q=read(p/'qualification.json');g=read(p/'git-and-closure-attachment.json');w=read(p/'wasm-section-comparison.json');z=read(remote/'artifact-container-verification.json')
assert not q['failedChecks'] and not g['failedChecks']
summary={'status':'QUALIFIED_FIXED_FINAL_021_SDK_COHORT','runId':37155827255,'controller':q['harnessHead'],'subjects':q['subjects'],'sampleCount':q['sampleCount'],'pairCount':q['pairCount'],'retainedReceiptChecks':len(q['checks']),'fullGitAndDeclaredClosureChecks':len(g['checks']),'sources':g['sources'],'AAControls':q['AAControls'],'CPU':{k:v for k,v in q['CPU'].items() if k!='intervals'},'resources':q['resources'],'cleanup':q['cleanup'],'families':{},'mechanism':'Every observed browser SDK capture records two BASE versus one CAND WASM request/response/finished; no physical wire-byte or independent compile-duration claim.','wasm':{'hashes':{arm:eng['sha256'] for arm,eng in w['engines'].items()},'sameBinaryBytes':w['sameBinaryBytes'],'functionBodyCounts':w['functionBodyCounts'],'differentBodyHashesAtSameIndex':w['differentBodyHashesAtSameIndex'],'sameArmBytesAsHistorical9d':True,'limit':w['scope']},'limits':q['limits'],'outliers':'All raw samples and all five AB observations per family are retained. House BASE572.905ms (paired CAND459.990ms) is numerically high relative to its other AB baselines; no physical cause established and no exclusion or statistical-outlier classification imposed. Architecture BASE3740.830ms likewise remains.','nativeAndViewer':'No native, full-viewer/GPU/pixel, full metadata, faithful-IFC, Windows, eight-worker or universal speed claim.'}
historical=read(Path('/tmp/6232-takeover/6537-browser-init-sdk-independent-qualification-v2/rust-source-and-wasm-scope.json'))
assert summary['wasm']['hashes']==historical['wasmHashes']
for family,s in q['statistics'].items():
 summary['families'][family]={k:s[k] for k in ['pairedABPercentDeltas','pairedABMedianPercent','pairedABRangePercent','ABBase','ABCandidate','identity','workerCount','workerIds','runtime']}
 summary['families'][family]['fullUnnormalizedDiagnosticsEqualAll14']=True
text='''# Final corrected-source SDK qualification

Run [37155827255](https://github.com/LTplus-AG/ifc-lite/actions/runs/37155827255), attempt 1, completed SUCCESS at 2026-10-03T22:14:30Z. Controller `4d47506a23e304ed4b772f7890e27e37843e8914`; BASE `c61932d4a9d85efe1b0f817a5274a115f0571ee3`; CAND `02112298d6cc690cda6fa3db712b524abc0f4712`.

All 56 samples/28 pairs remain, with two preceding A/A controls and five alternating A/B pairs per family. All eight A/A controls pass (largest absolute difference 8.688%). All produced flat/instanced CPU-channel identities, counts, coordinate information and full unnormalized diagnostics agree within each family. Default runtime reports two workers IDs0/1 on four cores with SAB/COI and no overrides. Cold processor.init, canonical processParallel drain, retention and dispose are timed; hashing follows the timer. No renderer, GPU, full metadata or faithful-IFC identity is implied.

The independently adapted retained-receipt/asset audit passes 1508 checks. Full tracked source hashes are independently verified from immutable Git objects: 13271 controller,13501 BASE,13506 CAND files. Full Git and declared-closure audit passes59242 checks. All762 normalized installed dependency entries agree. Every declared tool/package closure file has a frozen hash, and producing/root task receipts, transform identity and final freeze are consistent. Remote installed tool/sysroot/cargo-registry paths are producer receipts, not independently rehashed after runner teardown; original closure-completeness limitations remain.

All168 raw CPU intervals pass: minimum monotonic duration1,000,061,771ns, maximum busy5.013%. Initial available memory15,479,267,328B; minimum sampled live availability12,612,157,440B; maximum sampled owned RSS3,756,318,720B (not physical peak). Cleanup witnesses597 owned processes,0remaining/0zombies; both servers close with0sockets/faults; final input verification completes. No rerun, replacement, pooling, trimming or normalization occurred.

Candidate-minus-baseline paired elapsed deltas; negative means less elapsed:

| Family | All five paired deltas (%) | Paired median (%) | Paired range (%) | BASE AB median/range (ms) | CAND AB median/range (ms) |
| --- | --- | --- | --- | --- | --- |
'''
for family,s in q['statistics'].items():
 d=s['pairedABPercentDeltas'];b=s['ABBase'];c=s['ABCandidate'];lo,hi=s['pairedABRangePercent']
 text+=f"| {family} | {', '.join(f'{x:+.3f}' for x in d)} | {s['pairedABMedianPercent']:+.3f} | [{lo:+.3f}, {hi:+.3f}] | {b['medianMs']:.3f} / [{b['rangeMs'][0]:.3f}, {b['rangeMs'][1]:.3f}] | {c['medianMs']:.3f} / [{c['rangeMs'][0]:.3f}, {c['rangeMs'][1]:.3f}] |\n"
text+='''
Haus and Holter are faster in all five pairs; CSG is mixed near zero, and architecture contains one slower pair. These are observed SDK results, not a universal benefit. Haus's high572.905ms baseline remains paired with459.990ms candidate; architecture's3740.830ms baseline remains too. Their arithmetic effects are visible; no physical cause or statistical-outlier classification is inferred.

Every BASE sample captures two WASM requests/responses/finished; every CAND captures one. These browser counts are during the SDK geometry-and-posthash phase; immutable-origin runner refetches are outside them. Counts do not prove wire bytes or isolate compilation time.

Both arms genuinely build six fresh serial root Turbo tasks before any model. Engine hashes are BASE `8bece54c2d089bbec7ff0ce6fc00aee96edc7bdefd70eea60b5ccb7f8b1046c9`, CAND `0830c2d293f1d215138d0553e3d00718ffba75c860daab27ba72dc080ed25c73`. Each equals its same-arm historical9d artifact, but BASE versus CAND code/data differ:2369 of7723 indexed function-body hashes differ. Captured Rust/config hashes agree. Retained binary source paths establish a present build-path confound, not that it explains every byte or elapsed difference. No isolated-JavaScript timing causality is claimed.

Raw output arrays are not uploaded: CPU digests are observed post-timing witnesses, not independently regenerated meshes. Separate corrected-source V6 actual-generated-glue proof covers cold/warm async/initSync, MIME, retry, persistent/fatal causes and API config/free; this SDK cohort does not substitute for those controls. Historical9d audits remain unchanged.

Files: `qualification.json` holds every numeric/identity gate and statistic; `git-and-closure-attachment.json` records full tracked Git checks and declared closure pins; `wasm-section-comparison.json` retains complete section/body byte records; `wasm-fetches.json` retains each actual request timeline; `artifact-hashes.json` hashes every uploaded member. The NEW raw packet is `/tmp/6232-takeover/6537-browser-init-sdk-remote-v3/` with run metadata, job log, original artifact ZIP and complete extracted250members. Official uploaded ZIP digest matches `2ec85963c5c69773a014c6f4325cfde0c5c9c5cfe9f43b4b7b21ab78cc134810` and every member byte agrees with the downloaded files.

The first adapted audit stopped on a schema assumption (slot is in sample id, not a separate field); `audit-initial-schema.stderr` preserves it. Corrected adapter verifies exact ordered ids/families/pairs/kinds/arms. This was an audit failure, not a model/run refusal. Some earlier status API requests timed out; their raw observations remain. All read commands were bounded; no source edits, build, browser/model run, rerun, push or merge occurred.
'''
(p/'README.md').write_text(text)
(p/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
(p/'STATUS.md').write_text('Terminal SUCCESS; retained-receipt, full immutable Git-source and declared-closure audits PASS. See README.md and summary.json for exact subjects, all observations and scope.\n')
files={f.name:{'bytes':f.stat().st_size,'sha256':sha(f)} for f in sorted(p.iterdir()) if f.is_file() and f.name!='manifest.json'}
(p/'manifest.json').write_text(json.dumps({'schemaVersion':1,'files':files,'rawPacket':str(remote),'artifactZipSha256':z['zipSha256'],'artifactMemberCount':z['memberCount'],'rawMetadata':{name:{'bytes':(remote/name).stat().st_size,'sha256':sha(remote/name)} for name in ['run.json','poll-06.raw.json','job.log','artifact-container-verification.json','artifacts-api.json','curl-download-receipts.json']}},indent=2)+'\n')
print(json.dumps({'summarySha256':sha(p/'summary.json'),'qualificationSha256':sha(p/'qualification.json'),'gitClosureSha256':sha(p/'git-and-closure-attachment.json'),'manifestSha256':sha(p/'manifest.json'),'jobLogSha256':sha(remote/'job.log'),'reportSha256':sha(remote/'artifacts/sdk-worker-37155827255-1/report.json')},indent=2))
