Hosted Linux default SDK produced CPU channels only

Status: complete-56-sample-hosted-SDK-cohort; retained 56/56 samples.



No full viewer/GPU/pixel/metadata/faithful IFC, native-speed, physical peak or universal speed claim. Complete raw diagnostics retain cache/upper-bound census limitations.

{
  "house": {
    "status": "complete-14-sample-family",
    "pairedDeltas": [
      -0.18332551384063833,
      -0.1970920135101487,
      -0.10624953962387651,
      -0.06297064390130314,
      -0.08933705742169928
    ]
  },
  "csg": {
    "status": "complete-14-sample-family",
    "pairedDeltas": [
      0.0025115525722982923,
      -0.0023787472468629334,
      0.0013561916949096364,
      -0.009288708360501774,
      0.00691831225007844
    ]
  },
  "heavy-csg": {
    "status": "complete-14-sample-family",
    "pairedDeltas": [
      -0.018231671788839554,
      -0.031010654977639218,
      -0.02756324221469475,
      -0.01660231044170901,
      -0.038506008268896386
    ]
  },
  "architecture": {
    "status": "complete-14-sample-family",
    "pairedDeltas": [
      0.0015240964186944428,
      -0.016389178651994962,
      -0.011627938846784258,
      -0.03616443409615566,
      -0.020195457375822623
    ]
  }
}
