export { default as init, IfcAPI } from '@ifc-lite/wasm';
