Hosted Linux default SDK produced CPU channels only

Status: complete-56-sample-hosted-SDK-cohort; retained 56/56 samples.



No full viewer/GPU/pixel/metadata/faithful IFC, native-speed, physical peak or universal speed claim. Complete raw diagnostics retain cache/upper-bound census limitations.

{
  "house": {
    "status": "complete-14-sample-family",
    "pairedDeltas": [
      -0.06170913255064159,
      -0.05674938176848532,
      -0.05863168255762874,
      -0.05006776087904552,
      -0.07373966467599691
    ]
  },
  "csg": {
    "status": "complete-14-sample-family",
    "pairedDeltas": [
      -0.0045565514906058535,
      -0.00148272814951389,
      -0.04536530957586671,
      0.008261110416179163,
      0.0029182538792398294
    ]
  },
  "heavy-csg": {
    "status": "complete-14-sample-family",
    "pairedDeltas": [
      0.015277544836753698,
      0.026099387950457853,
      0.05510689092257004,
      0.00886494396223747,
      -0.0007430165133536226
    ]
  },
  "architecture": {
    "status": "complete-14-sample-family",
    "pairedDeltas": [
      -0.0849393588361359,
      -0.06554610076888057,
      -0.04016920963194137,
      -0.029786929891891578,
      -0.004860060928897014
    ]
  }
}
