# Independent hosted cold SDK qualification

Run37149697842/attempt1: controller4d47506a23e304ed4b772f7890e27e37843e8914; BASEc61932d4a9d85efe1b0f817a5274a115f0571ee3; CANDfcdc972d7df8f94651924c5879d0c2582b99c3ef. This original success-path candidate is distinct from the revised failure-semantics source, which this run does not qualify.

Artifact/receipt audit PASS1505checks, none failed. Both literal subjects were freshly built through six actual forced root build tasks, locked provenance and producing WASM completion; source/tool/closure pins agree before/final build, stored emitted assets/log/receipt SHA256s rehash correctly. Remote tool/source paths cannot be rehashed after runner disposal; source/compiler closure still has the protocol's declared limitations.

56 fresh Chrome samples/28 fixed pairs retained: two AA and five alternating AB pairs per Haus/ISSUE129/Holter/architecture. Actual runtime4cores/default2workers with SAB/COI and no overrides; all56 unique owned sample identities. All family CPU-channel output digests/counts/full unnormalized diagnostics match14rows; existing kernel diagnostics are preserved, not dropped. Preclose and postcleanup artifacts, zero errors, owned/servers/log drains and final input verification all pass.168 independent CPU intervals pass unchanged gates, max1.50percent; all8AA controls pass, maxabsolute3.198percent. Sampled owned RSS is not physical peak.

Every base sample records exactly2 WASM browser requests/responses/request-finished, candidate exactly1, with matched frozen asset identities. All occur in geometry-and-posthash capture phase; fixture upload/hash is outside that phase. Runner-origin identity refetch is after drain and outside browser counts. This is observed fetch count, not physical network bytes or isolated compile/geometry duration. Timer source includes processor.init, canonical default processParallel, retention and disposal; output hashing is afterward. No stage speed attribution is inferred.

Paired AB medians candidate versus base: Haus−5.863percent, ISSUE129−0.148percent, Holter+1.528percent, architecture−4.017percent. qualification.json retains every raw elapsed time, each paired delta/range, all AA controls and distribution. Holter reaches+5.511percent; architecture gains diminish across ordered pairs. No pairs/outliers/failed predecessors are pooled or discarded. Verdict is mixed; no universal win or solved geometry regression claim.

Produced WASM hashes differ between arms, including code/data section hashes, despite captured Rust/Cargo/config source equality. Each binary is freshly built and served exactly as frozen. Difference cause is unestablished here; do not claim WASM byte identity or isolate a kernel-only improvement from this endpoint result.

No model generation, production edits, builds, browser runs, dispatches, retries or threshold changes occurred during this audit. Python audit adapts the retained previous v5 independent audit; artifacts remain immutable.
