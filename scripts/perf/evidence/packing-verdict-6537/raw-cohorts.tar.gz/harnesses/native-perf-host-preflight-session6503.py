import json,os,sys,time
from pathlib import Path
needles=('turbo run','turbo/bin/turbo','pnpm typecheck','pnpm test','pnpm build','vite/bin/vite','vitest','rustc','cargo test','cargo clippy','wasm-pack','tsc --','typescript/bin/tsc','tsx --test','node --test')
def snapshot():
 result={}
 for p in Path('/proc').iterdir():
  if not p.name.isdigit(): continue
  try:
   args=[x.decode(errors='replace') for x in (p/'cmdline').read_bytes().split(b'\0') if x]
   if not args or Path(args[0]).name in ('bash','sh','python3','python','timeout'): continue
   cmd=' '.join(args)
   if any(n in cmd for n in needles):
    stat=(p/'stat').read_text().rsplit(')',1)[1].split()
    result[int(p.name)]={'pid':int(p.name),'cmd':cmd[:700],'ticks':int(stat[11])+int(stat[12]),'devServer':('vite/bin/vite' in cmd and ' build' not in cmd)}
  except (FileNotFoundError,ProcessLookupError,PermissionError): continue
 return result
start=snapshot(); time.sleep(1); end=snapshot(); active=[]; idle=[]
for pid,row in end.items():
 row['cpuSecondsObserved']=(row['ticks']-start.get(pid,row)['ticks'])/os.sysconf('SC_CLK_TCK'); del row['ticks']
 if row['devServer'] and pid in start and row['cpuSecondsObserved']<0.05: idle.append(row)
 else: active.append(row)
row={'capturedAt':time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime()),'loadavg':Path('/proc/loadavg').read_text().strip(),'activeGraphs':active,'observedIdleDevServers':idle,'scope':'Observable Linux build/test graphs and one-second dev-server CPU; idle dev servers disclosed, not proof of full Windows/host background inactivity'}
print(json.dumps(row,indent=2));sys.exit(1 if active else 0)
